﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quadcopter : Air
{
    [Header("Quadcopter Module")]
    public bool m_QuadcopterClassInitialized = false;
    public bool m_QuadcopterClassStarted = false;

    public float m_MaxForwardSpeedInKnots = 40;
    public float m_MaxSidewaySpeedInKnots = 5;
    private float m_PrevMaxForwardSpeedInKnots;
    private float m_PrevMaxSidewaySpeedInKnots;

    public DroneMovement m_MovementScript;
    public DronePropelers m_Propellers;

    public int m_SpeedMode = 1;
    public float m_HyperspeedMultiplier = 10;
    public float m_SlowSpeedMultiplier = 0.25f;

    public float m_SpeedModifier;

    public float m_NormalForwardForce;
    public float m_NormalSidewaysForce;
    public float m_NormalUpForce;
    public float m_NormalDownForce;

    public float m_SuperForwardForce;
    public float m_SuperSidewaysForce;
    public float m_SuperUpForce;
    public float m_SuperDownForce;

    public float m_HyperForwardForce;
    public float m_HyperSidewaysForce;
    public float m_HyperUpForce;
    public float m_HyperDownForce;

    public float m_SlowForwardForce;
    public float m_SlowSidewaysForce;
    public float m_SlowUpForce;
    public float m_SlowDownForce;

    public float m_WantedForwardTilt;
    public float m_WantedSidewaysTilt;
    public float m_OriginalWantedForwardTilt;
    public float m_OriginalWantedSidewaysTilt;

    public float m_CurrentForwardForce;
    public float m_CurrentSidewaysForce;
    public float m_CurrentUpForce;
    public float m_CurrentDownForce;
    public float m_CurrentMaxForwardSpeed;
    public float m_CurrentMaxSideSpeed;

    public float m_AccelerationDropoff;

    public float m_MaxHeight = 304f;

    public bool m_WaitingForDetonation = false;

    public EntityControlType m_PreviousControlType;

    public bool m_LaserFired;

    public float m_DistanceAtWhichToDropToTarget = 75;

    public bool m_IsOnGround;
    public Transform m_ObjectLandedOn;
    public float m_OriginalPropellerIdleSpeed;
    public Vector3 m_RotationOfTheGround;

    public override bool getInitialized()
    {
        return m_QuadcopterClassInitialized;
    }
    public Quadcopter()
    {

    }

    ~Quadcopter()
    {

    }

    public override bool ExternalStart()
    {
        return StartQuadcopterClass();
    }

    public bool StartQuadcopterClass()
    {
        if (!SimulatorSettings.getInitialized()) return false;

        m_EntityInitialized = false;
        m_EntityStarted = true;

        StartEntityClass();

        if (m_EntityInitialized)
        {
            m_QuadcopterClassStarted = true;
            m_QuadcopterClassInitialized = false;

            InitializeQuadcopterClass();

            if (m_QuadcopterClassInitialized)
            {
                //if (SimulatorSettings.getDebugMode()) Debug.Log("[" + GetType() + "] " + gameObject.name + " Initialized successfully.");
                return true;
            }
            else
            {
                if (SimulatorSettings.getDebugMode()) Debug.Log("[" + GetType() + "] " + gameObject.name + " Failed to initialize.");
                return false;
            }
        }

        return false;
    }

    void InitializeQuadcopterClass()
    {
        if (m_MovementScript == null)
        {
            m_MovementScript = gameObject.GetComponent<DroneMovement>();
        }

        if (m_MovementScript != null)
        {
            m_PrevMaxForwardSpeedInKnots = m_MaxForwardSpeedInKnots;
            m_PrevMaxSidewaySpeedInKnots = m_MaxSidewaySpeedInKnots;

            setMaxForwardSpeed(m_MaxForwardSpeedInKnots);
            setMaxSidewaySpeed(m_MaxSidewaySpeedInKnots);

            m_MovementScript.wantedForwardTilt = m_WantedForwardTilt;
            m_MovementScript.wantedSideTilt = m_WantedSidewaysTilt;

            m_OriginalWantedForwardTilt = m_WantedForwardTilt;
            m_OriginalWantedSidewaysTilt = m_WantedSidewaysTilt;

            m_NormalForwardForce = SimulatorSettings.getInputManager().m_QuadForwardForce;
            m_NormalSidewaysForce = SimulatorSettings.getInputManager().m_QuadSidewardForce;
            m_NormalUpForce = SimulatorSettings.getInputManager().m_QuadUpwardForce;
            m_NormalDownForce = SimulatorSettings.getInputManager().m_QuadDownwardForce;

            m_MovementScript.movementForwardSpeed = m_NormalForwardForce;
            m_MovementScript.sideMovementAmount = m_NormalSidewaysForce;
            m_MovementScript.upForce = m_NormalUpForce;
            m_MovementScript.forceDownHover = m_NormalDownForce;

            m_SuperForwardForce = m_NormalForwardForce * (m_HyperspeedMultiplier / 2);
            m_SuperSidewaysForce = m_NormalSidewaysForce * (m_HyperspeedMultiplier / 2);
            m_SuperUpForce = m_NormalUpForce * (m_HyperspeedMultiplier / 2);
            m_SuperDownForce = m_NormalDownForce * (m_HyperspeedMultiplier / 2);

            m_HyperForwardForce = m_NormalForwardForce * m_HyperspeedMultiplier;
            m_HyperSidewaysForce = m_NormalSidewaysForce * m_HyperspeedMultiplier;
            m_HyperUpForce = m_NormalUpForce * m_HyperspeedMultiplier;
            m_HyperDownForce = m_NormalDownForce * m_HyperspeedMultiplier;
            //Debug.Log( gameObject.name + " - Movment Script initialized.");

            m_SlowForwardForce = m_NormalForwardForce * m_SlowSpeedMultiplier;
            m_SlowSidewaysForce = m_NormalSidewaysForce * m_SlowSpeedMultiplier;
            m_SlowUpForce = m_NormalUpForce * m_SlowSpeedMultiplier;
            m_SlowDownForce = m_NormalDownForce * m_SlowSpeedMultiplier;

            m_MovementScript.enabled = true;
            m_MovementScript.ExternalStart();
            m_MovementScript.setControlEnabled(true);

            if (m_EntitySMMTTID == 1002)
            {
                m_MovementScript.enabled = false;
            }

            //m_SpeedMode = 1;

            if(m_EntityID == 0) toggleSpeedMode(m_SpeedMode, false);

            //if (m_ControlType == EntityControlType.PLAYER)
            //{
            //    m_MovementScript.setControlEnabled(true);
            //}
            //else
            //{
            //    m_MovementScript.setControlEnabled(false);
            //}

            m_PreviousControlType = m_ControlType;

            if(m_EntityID == 0)
            {
                SetRotation(SimulatorSettings.getInitialCameraRotation());
            }

            m_QuadcopterClassInitialized = true;
        }

        if(m_Propellers == null)
        {
            m_Propellers = this.GetComponent<DronePropelers>();
        }

        m_OriginalPropellerIdleSpeed = m_Propellers.idleRotationSpeed;
    }

    void Update()
    {
        if (m_QuadcopterClassInitialized && m_EntityInitialized)
        {
            CheckIfValuesChanged();

            if (m_IsOnGround)
            {
                m_DesiredHeading = transform.rotation.eulerAngles.y;
                m_MovementScript.ResetDroneObjectRotation(m_DesiredHeading);
            }

            m_CurrentForwardForce = m_MovementScript.movementForwardSpeed;
            m_CurrentSidewaysForce = m_MovementScript.sideMovementAmount;
            m_CurrentUpForce = m_MovementScript.upForce;
            m_CurrentDownForce = m_MovementScript.forceDownHover;
            m_CurrentMaxForwardSpeed = m_MovementScript.maxForwardSpeed;
            m_CurrentMaxSideSpeed = m_MovementScript.maxSidewaySpeed;

            if (m_IsFollowingAnotherEntity)
            {
                m_MovementScript.wantedForwardTilt = 0;
                m_MovementScript.wantedSideTilt = 0;
            }
            else
            {
                m_MovementScript.wantedForwardTilt = m_OriginalWantedForwardTilt;
                m_MovementScript.wantedSideTilt = m_OriginalWantedSidewaysTilt;
            }

            //if (m_EntityState == EntityState.N81DEMOAQUAD_ARRIVED_AT_SHIP)
            //{
            //    if (m_EntityDestroyed) return;

            //    Debug.Log(gameObject.name + " has arrived.");
            //    DetonateEntity();
            //    return;
            //}
            //else if (m_EntityState == EntityState.OBJECT_DISABLED)
            //{
            //    if (m_EntityDestroyed) return;

            //    if (!m_WaitingForDetonation)
            //    {
            //        Debug.Log("Got Effector Complete message. Detonating.");
            //        //Detonate();

            //        if (m_Navigator != null) m_Navigator.m_AcceptNewUpdates = false;
            //        m_Navigator.RemoveMostRecentUpdate();

            //        //IEnumerator coroutine = WaitAndDisable(SimulatorSettings.getAnimationManager().m_StateReactionDelay);
            //        //StartCoroutine(coroutine);
            //        //m_WaitingForDetonation = true;                    

            //        DisableEntity();

            //        return;
            //    }
            //}

            Update_EntityClass();

            //Debug.Log("m_LTriggerInput: " + m_LTriggerInput + " - m_RTriggerInput: " + m_RTriggerInput);

            if(m_ControlType == EntityControlType.PLAYER)
            {
                if (transform.position.y >= m_MaxHeight)
                {
                    //transform.position = new Vector3(transform.position.x, m_MaxHeight, transform.position.y);
                    m_RigidBody.velocity = Vector3.zero;
                }

                if (m_LVerticalInput > 0)
                {
                    m_MovementScript.customFeed_forward = m_LVerticalInput;
                    m_MovementScript.customFeed_backward = 0;
                }
                else if (m_LVerticalInput < 0)
                {
                    m_MovementScript.customFeed_forward = 0;
                    m_MovementScript.customFeed_backward = -1 * m_LVerticalInput;
                }
                else
                {
                    m_MovementScript.customFeed_forward = 0;
                    m_MovementScript.customFeed_backward = 0;
                }


                if (m_LHorizontalInput > 0)
                {
                    m_MovementScript.customFeed_rightward = m_LHorizontalInput;
                    m_MovementScript.customFeed_leftward = 0;
                }
                else if (m_LHorizontalInput < 0)
                {
                    m_MovementScript.customFeed_rightward = 0;
                    m_MovementScript.customFeed_leftward = -1 * m_LHorizontalInput;
                }
                else
                {
                    m_MovementScript.customFeed_rightward = 0;
                    m_MovementScript.customFeed_leftward = 0;
                }

                if (m_InputAltitude > 0)
                {
                    if (m_IsOnGround)
                    {
                        MovementEnabled(true);
                        //m_MovementScript.enabled = true;
                        //m_RigidBody.useGravity = true;
                        //m_RigidBody.detectCollisions = true;
                        //m_RigidBody.isKinematic = false;
                    }

                    m_MovementScript.customFeed_upward = m_InputAltitude;
                    m_MovementScript.customFeed_downward = 0;
                }
                else if (m_InputAltitude < 0)
                {
                    m_MovementScript.customFeed_upward = 0;
                    m_MovementScript.customFeed_downward = -1 * m_InputAltitude;
                }
                else
                {
                    m_MovementScript.customFeed_upward = 0;
                    m_MovementScript.customFeed_downward = 0;
                }

                if (m_InputRudder < 0)
                {
                    m_MovementScript.customFeed_rotateLeft = -1 * m_InputRudder;
                    m_MovementScript.customFeed_rotateRight = 0;
                }
                else if (m_InputRudder > 0)
                {
                    m_MovementScript.customFeed_rotateLeft = 0;
                    m_MovementScript.customFeed_rotateRight = m_InputRudder;
                }
                else
                {
                    m_MovementScript.customFeed_rotateLeft = 0;
                    m_MovementScript.customFeed_rotateRight = 0;
                }
            }

            m_MovementScript.slowDownTime = m_AccelerationDropoff;

            if (m_ControlType != EntityControlType.PLAYER)
            {
                if (m_CurrentHeading != m_DesiredHeading)
                {
                    //transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_TurningSpeed);
                    SetRotation(Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_TurningSpeed));
                }

                if (m_Target)
                {
                    if(!m_Target.m_QueuedForDestruction)
                    {
                        m_DistanceToTargetID = Common.GetDistanceIgnoringY(transform.position, SimulatorSettings.getEntityList().m_Entities[m_TargetID].transform.position);

                        if (m_DistanceToTargetID < m_DistanceAtWhichToDropToTarget)
                        {
                            m_DesiredAltitude = Mathf.Lerp(transform.position.y, m_Target.transform.position.y, 1 - (m_DistanceToTargetID / m_DistanceAtWhichToDropToTarget));
                        }
                    }
                }
            }
            UpdateUniqueBehaviors();

            if (m_EntityState == EntityState.OBJECT_DISABLED)
            {
                if (gameObject.transform.position.y < m_HeightOfWater)
                {
                    if (m_ParticleList.ContainsKey("Smoke"))
                    {
                        Debug.Log("Orphaning Smoke on ID: " + m_EntityID);
                        m_ParticleList["Smoke"].transform.SetParent(SimulatorSettings.getAnimationManager().transform);
                    }

                    SimulatorSettings.getEntityList().removeEntity(m_EntityID);
                }
            }

        }
        else if (m_EntityStarted)
        {
            InitializeQuadcopterClass();
        }

    }

    public override void InternalApplyPositionUpdate()
    {
        if (m_MovementEnabled)
        {
            if (m_WaypointModule.m_NumberOfPositionWaypoints == 0) m_LerpedPosition = Vector3.Lerp(transform.position, m_CurrentXYZDestination, Time.deltaTime * m_ScriptControllerForwardSpeed);
            else m_LerpedPosition = Vector3.MoveTowards(transform.position, m_CurrentXYZDestination, Time.deltaTime * m_ScriptControllerForwardSpeed);

            if ((transform.position.x == m_CurrentXYZDestination.x) && (transform.position.z == m_CurrentXYZDestination.z))
            {
                m_CurrentXYZRotationTarget = transform.rotation.eulerAngles;
            }

            m_MovementScript.customFeed_forward = 1;

            this.SetPosition(m_LerpedPosition);
        }
    }

    public override void InternalApplyRotationUpdate()
    {
        if (m_MovementEnabled)
        {
            Vector3 l_NewRotation = Vector3.Lerp(transform.rotation.eulerAngles, m_CurrentXYZRotationTarget, Time.deltaTime * m_TurningSpeed);
            m_DesiredPitch = l_NewRotation.x;
            m_DesiredHeading = l_NewRotation.y;
            m_DesiredRoll = l_NewRotation.z;

            SetRotation(l_NewRotation);
        }
    }

    IEnumerator WaitAndDisable(float a_WaitTime)
    {
        yield return new WaitForSeconds(a_WaitTime);
        Debug.Log("Waited " + a_WaitTime + " to detonate.");
        DisableEntity();
    }

    void CheckIfValuesChanged()
    {
        if (m_ControlType != m_PreviousControlType) // Activate drone
        {
            //if (m_ControlType == EntityControlType.PLAYER)
            //{
            //    m_MovementScript.setControlEnabled(true);
            //}
            //else
            //{
            //    m_MovementScript.setControlEnabled(false);
            //}


            m_PreviousControlType = m_ControlType;
        }

        if (m_MaxForwardSpeedInKnots != m_PrevMaxForwardSpeedInKnots)
        {
            setMaxForwardSpeed(m_MaxForwardSpeedInKnots);
        }

        if (m_MaxSidewaySpeedInKnots != m_PrevMaxSidewaySpeedInKnots)
        {
            setMaxSidewaySpeed(m_MaxSidewaySpeedInKnots);
        }
    }

    void setMaxForwardSpeed(float a_Speed)
    {
        m_MovementScript.setMaxSpeed(a_Speed);
        m_PrevMaxForwardSpeedInKnots = m_MaxForwardSpeedInKnots;
    }

    void setMaxSidewaySpeed(float a_Speed)
    {
        m_MovementScript.setMaxSideSpeed(a_Speed);
        m_PrevMaxSidewaySpeedInKnots = m_MaxSidewaySpeedInKnots;
    }

    public void toggleSpeedMode()
    {
        int l_Mode = 0;

        if (m_SpeedMode == 0)
        {
            l_Mode = 1;
        }
        else if (m_SpeedMode == 1)
        {
            l_Mode = 2;
        }
        else if (m_SpeedMode == 2)
        {
            l_Mode = 3;
        }
        else if (m_SpeedMode == 3)
        {
            l_Mode = 0;
        }

        toggleSpeedMode(l_Mode);
    }

    public void toggleSpeedMode(int a_SpeedMode, bool a_Notify = true)
    {
        m_SpeedMode = a_SpeedMode;

        if (m_SpeedMode == 0)
        {
            if(a_Notify) SimulatorSettings.getUIManager().CreateNotification("Speed Mode: Slow", 5);
            Debug.Log("Speed Mode: Slow");
            m_MovementScript.setMovementForces(m_SlowForwardForce, m_SlowSidewaysForce, m_SlowUpForce, m_SlowDownForce);
            m_MaxSpeed = m_OriginalMaxSpeed / 2;
            m_RigidBody.drag = 0;
        }
        else if (m_SpeedMode == 1)
        {
            if (a_Notify) SimulatorSettings.getUIManager().CreateNotification("Speed Mode: Normal", 5);
            Debug.Log("Speed Mode: Normal");
            m_MovementScript.setMovementForces(m_NormalForwardForce, m_NormalSidewaysForce, m_NormalUpForce, m_NormalDownForce);
            m_MaxSpeed = m_OriginalMaxSpeed;
            m_RigidBody.drag = 0;
        }
        else if (m_SpeedMode == 2)
        {
            if (a_Notify) SimulatorSettings.getUIManager().CreateNotification("Speed Mode: Super", 5);
            Debug.Log("Speed Mode: Super");
            m_MovementScript.setMovementForces(m_SuperForwardForce, m_SuperSidewaysForce, m_SuperUpForce, m_SuperDownForce);
            m_MaxSpeed = m_OriginalMaxSpeed * m_HyperspeedMultiplier * 1.15f;
            m_RigidBody.drag = 3;
        }
        else if (m_SpeedMode == 3)
        {
            if (a_Notify) SimulatorSettings.getUIManager().CreateNotification("Speed Mode: Hyper", 5);
            Debug.Log("Speed Mode: Hyper");
            m_MovementScript.setMovementForces(m_HyperForwardForce, m_HyperSidewaysForce, m_HyperUpForce, m_HyperDownForce);
            m_MaxSpeed = m_OriginalMaxSpeed * m_HyperspeedMultiplier * 1.75f;
            m_RigidBody.drag = 5;
        }
    }

    public override void setHeading(float a_Heading, float a_TurningSpeed = -1)
    {
        Debug.Log("Quadcopter::setHeading" + a_Heading);
        m_DesiredHeading = a_Heading;

        m_MovementScript.enabled = false;

        transform.rotation = Quaternion.Euler(transform.rotation.x, a_Heading, transform.rotation.z);

        m_MovementScript.currentYRotation = a_Heading;

        m_MovementScript.enabled = true;

        if (a_TurningSpeed != -1)
        {
            m_TurningSpeed = a_TurningSpeed;
        }
    }

    public override void DetonateEntity()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("Quadcopter::DetonateEntity()");
        Instantiate(SimulatorSettings.getAnimationManager().getPrefabObject("Explosion"), transform.position, transform.rotation);

        //Collider[] l_HitColliders = Physics.OverlapSphere(transform.position, 30);

        //foreach (Collider l_Collider in l_HitColliders)
        //{
        //    if (l_Collider.transform.parent != null)
        //    {
        //        EntityControlObjects l_ControlObjs = l_Collider.transform.parent.GetComponent<EntityControlObjects>();

        //        if (l_ControlObjs != null)
        //        {
        //            Entity l_Entity = l_ControlObjs.getEntity();

        //            //Debug.Log("Quadcopter::DetonateEntity() hit entity: " + l_Entity.m_EntityName);

        //            if (l_Entity != null)
        //            {
        //                if(l_Entity.m_EntityID != m_EntityID)
        //                {
        //                    if (typeof(Surface).IsAssignableFrom(l_Entity.GetType()))
        //                    {
        //                        if (l_ControlObjs != null)
        //                        {
        //                            if (SimulatorSettings.getDebugMode()) Debug.Log("Quadcopter::DetonateEntity() hit surface entity: " + l_Entity.m_EntityName);
        //                            l_Entity.removeHullPoint();
        //                        }
        //                    }
        //                    if (typeof(Air).IsAssignableFrom(l_Entity.GetType()))
        //                    {
        //                        if (l_ControlObjs != null)
        //                        {
        //                            //if (SimulatorSettings.getDebugMode()) Debug.Log("Quadcopter::DetonateEntity() hit air entity: " + l_Entity.m_EntityName);
        //                            //l_Entity.removeHullPoint();
        //                            Quadcopter l_Copter = l_Entity.GetComponent<Quadcopter>();

        //                            if(l_Copter)
        //                            {
        //                                l_Copter.DisableEntity();
        //                                if (SimulatorSettings.getDebugMode())
        //                                {
        //                                    //if (l_Copter.m_RigidBody.isKinematic) Debug.Log("Target Rigidbody State was kinematic");
        //                                    //else Debug.Log("Target Rigidbody State was NOT kinematic");
        //                                }
        //                                l_Copter.m_RigidBody.AddRelativeTorque(200, 0, 0, ForceMode.VelocityChange);
        //                                l_Copter.m_RigidBody.AddExplosionForce(250, l_Copter.transform.position - l_Copter.transform.forward, 5, -1, ForceMode.Force);
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                Debug.Log("Quadcopter::DetonateEntity() hit non-entity type object: " + l_Collider.gameObject.name);
        //            }
        //        }

        //    }
        //    else
        //    {
        //        Debug.Log("Quadcopter::DetonateEntity() hit non-entity type object: " + l_Collider.gameObject.name);
        //    }
        //}

        

        SimulatorSettings.getEntityList().removeEntity(m_EntityID);

        //addSmoke();

        if (m_ParticleList.ContainsKey("Smoke")) m_ParticleList["Smoke"].transform.SetParent(SimulatorSettings.getAnimationManager().transform);

        m_MovementScript.enabled = false;
        m_RigidBody.useGravity = true;
        m_RigidBody.isKinematic = false;

        m_MovementEnabled = false;
        m_EntityDestroyed = true;
    }

    public override void DisableEntity()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("Quadcopter::DisableEntity()");
        Instantiate(SimulatorSettings.getAnimationManager().getPrefabObject("Explosion"), transform.position, transform.rotation);

        //SimulatorSettings.getEntityList().removeEntity(m_EntityID);

        addSmoke();

        m_MovementScript.enabled = false;
        m_RigidBody.useGravity = true;
        m_RigidBody.isKinematic = false;

        m_MovementEnabled = false;
        m_EntityDestroyed = true;
    }

    public override void On_DEFAULT_POSUPDATE()
    {

    }

    public override void OnState_DETECTION()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_COMPLETE()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_LAUNCHING()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_MISSED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_ACTUATED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_CLASSIFIED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_DETECTED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_NEUTRALIZED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_N81DEMOAQUAD_ARRIVED_AT_SHIP()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        if (m_EntityDestroyed) return;

        DetonateEntity();
        return;
    }

    public override void OnState_DEFAULT_POSUPDATE()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_OBJECT_DISABLED()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        if (m_EntityDestroyed) return;

        m_AcceptNewUpdates = false;
        //m_Navigator.RemoveMostRecentUpdate();

        DisableEntity();
    }

    public override void OnState_SYSTEM_TURNED_ON()
    {
        if (SimulatorSettings.getDebugMode()) Debug.Log("[Quad] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public void UpdateUniqueBehaviors()
    {
        if (m_EntitySMMTTID == 1054) // 4x Swarm Drone
        {
            SwarmDroneBehaviors();
        }
        else if (m_EntitySMMTTID == 1004)
        {
            QuadcopterDroneBehaviors();
        }
        if (m_EntitySMMTTID == 1002)
        {
            GroundLaunchedDroneBehaviors();
        }
        else if (m_EntitySMMTTID == 1005)
        {
            EffectorDroneBehaviors();
        }
        else if (m_EntitySMMTTID == 1006)
        {
            ShipLaserDroneBehaviors();
        }
        else if (m_EntitySMMTTID == 1007)
        {
            LaserDroneBehaviors();
        }
    }

    void QuadcopterDroneBehaviors()
    {
        if (m_ControlType == EntityControlType.NETWORK)
        {
            if (m_EntityState == EntityState.DETECTION)
            {
                if (m_EntitiesBroadcastingTo.Count == 0)
                {
                    bool l_RedboxExists = SimulatorSettings.getEntityList().vehicleTypeExistsInList(217);
                    bool l_RedBuoyExists = SimulatorSettings.getEntityList().vehicleTypeExistsInList(106);

                    if ((l_RedboxExists) || (l_RedBuoyExists))
                    {
                        Entity l_Target;

                        if (l_RedboxExists && !l_RedBuoyExists)
                        {
                            l_Target = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 217);
                        }
                        else if (!l_RedboxExists && l_RedBuoyExists)
                        {
                            l_Target = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 106);
                        }
                        else
                        {
                            Entity l_RedBox = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 217);
                            Entity l_RedBuoy = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 106);

                            if (GetDistanceIgnoringY(transform.position, l_RedBox.transform.position) < GetDistanceIgnoringY(transform.position, l_RedBuoy.transform.position))
                            {
                                l_Target = l_RedBox;
                            }
                            else if (GetDistanceIgnoringY(transform.position, l_RedBox.transform.position) > GetDistanceIgnoringY(transform.position, l_RedBuoy.transform.position))
                            {
                                l_Target = l_RedBuoy;
                            }
                            else
                            {
                                l_Target = l_RedBox;
                            }
                        }

                        SimulatorSettings.getAnimationManager().createNewCommunicationAnimation(m_EntityID, l_Target.m_EntityID, 0.0f, Color.white, new Color(1.0f, 0.0f, 0, 1), SignalEffect.SignalType.AIR);
                    }
                }
            }

            if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
            {
                DetonateEntity();
                //Entity l_Target = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 1005);

                //if (l_Target != null)
                //{
                //    SimulatorSettings.getAnimationManager().createLaserAnimation(m_EntityID, l_Target.m_EntityID, 3.0f);

                //    m_EntityState = EntityState.DEFAULT_POSUPDATE;

                //    if (m_EntityDestroyed) return;

                //    DetonateEntity();
                //}
                //else
                //{
                //    Debug.Log("Could not find type " + 1005 + " to shoot laser at.");
                //}
            }
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        switch(m_ControlType)
        {
            case EntityControlType.NETWORK:
                NetworkCollisionEnter(collision);
                break;
            case EntityControlType.PLAYER:
                PlayerCollisionEnter(collision);
                break;
            default:
                break;
        }



    }

    void OnCollisionExit(Collision collision)
    {
        switch (m_ControlType)
        {
            case EntityControlType.NETWORK:
                PlayerCollisionEnter(collision);
                break;
            case EntityControlType.PLAYER:
                PlayerCollisionExit(collision);
                break;
            default:
                break;
        }
    }

    void NetworkCollisionEnter(Collision collision)
    {
        if (m_EntityDestroyed)
        {
            if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Terrain"))
            {
                DetonateEntity();
            }
        }
    }

    void PlayerCollisionEnter(Collision collision)
    {
        if (!m_IsOnGround)
        {
            if (CheckIfGrounded(collision))
            {
                m_IsOnGround = true;

                m_RigidBody.velocity = Vector3.zero;
                m_RigidBody.angularVelocity = Vector3.zero;
                MovementEnabled(false);
                m_Propellers.idleRotationSpeed = 0;
                SetRotation(m_RotationOfTheGround);

                if (m_ObjectLandedOn.GetComponent<Entity>())
                {
                    Debug.Log(m_EntityName + " landed on: " + m_ObjectLandedOn.GetComponent<Entity>().m_EntityName);
                    transform.SetParent(m_ObjectLandedOn.GetComponent<Entity>().m_AirVehicleAttachPoint);

                    //m_RigidBody.useGravity = false;
                    ////m_RigidBody.detectCollisions = false;
                    //m_MovementScript.enabled = false;
                    //m_RigidBody.isKinematic = true;

                    //if(m_ControlType == EntityControlType.NETWORK)
                    //{
                    //    if(m_WaypointModule)
                    //    {
                    //        if(m_WaypointModule.m_Landing)
                    //        {
                    //            m_WaypointModule.Landed();
                    //        }
                    //    }
                    //}
                }
                else
                {
                    Debug.Log(m_EntityName + " landed on: " + collision.gameObject.name);
                }
            }
            else
            {
                Debug.Log(m_EntityName + " collided with: " + collision.gameObject.name);
            }
        }
    }

    void PlayerCollisionExit(Collision collision)
    {
        if (m_IsOnGround)
        {
            if (CheckIfGrounded(collision))
            {

            }
            else
            {
                m_IsOnGround = false;
                Debug.Log(m_EntityName + " took off from: " + collision.gameObject.name);
                //DettachFromParent();
                transform.SetParent(null);
                m_IsFalling = false;

                MovementEnabled(true);

                //m_MovementScript.enabled = true;
                m_Propellers.idleRotationSpeed = m_OriginalPropellerIdleSpeed;

                if (m_ControlType == EntityControlType.WAYPOINT)
                {
                    m_RigidBody.useGravity = false;
                    m_RigidBody.isKinematic = true;
                }
            }
        }
    }

    //public bool CheckIfGrounded(Collision collision)
    //{
    //    RaycastHit MyRayHit;

    //    MyRayHit = SimulatorSettings.getPhysicsManager().GetEntityHitFromPoint(transform.position, -Vector3.up * 10);

    //    if(MyRayHit.collider != null)
    //    {
    //        Debug.Log(collision.collider.gameObject.name);

    //        Debug.DrawLine(transform.position, MyRayHit.point, Color.green, 10);


    //    }
    //    else
    //    {
    //        Debug.DrawRay(transform.position, -Vector3.up * 10, Color.red, 10);
    //    }




    //    return false;
    //}

    public bool CheckIfGrounded(Collision collision)
    {
        RaycastHit MyRayHit;

        GameObject ObjectHit = this.gameObject;

        //for (int i = 0; i < collision.contacts.Length; i++)
        if(collision.contactCount > 0)
        {

            MyRayHit = SimulatorSettings.getPhysicsManager().GetEntityHitFromPoint(transform.position, -Vector3.up * 10);

            if (MyRayHit.collider != null)  
            {
                //Debug.Log("Collider " + collision.contacts[0].thisCollider.name + " hit Collider " + collision.collider.name);

                if (collision.collider.CompareTag("AirVehicleLandingPad") || collision.collider.gameObject.layer == LayerMask.NameToLayer("Terrain"))
                {
                    //Debug.Log(m_EntityName + " grounded on: " + MyRayHit.collider.gameObject.name);
                    m_ObjectLandedOn = collision.gameObject.transform;
                    m_RotationOfTheGround = MyRayHit.normal;
                    m_RotationOfTheGround.y = transform.rotation.y;

                    return true;
                }
                else
                {
                    //Debug.Log("Not a landable surface");
                }
            }
            else
            {
                //Debug.Log(m_EntityName + " struck something but did not land on it");
            }

            return false;
        }



        return false;
    }

    //public bool CheckIfGrounded(Collision collision)
    //{
    //    RaycastHit MyRayHit;

    //    GameObject ObjectHit = this.gameObject;
    //    m_CollisionPoints.Clear();

    //    for (int i = 0; i < collision.contacts.Length; i++)
    //    {
    //        MyRayHit = SimulatorSettings.getPhysicsManager().GetEntityHitFromPoint(transform.position, -Vector3.up * 10);
    //        Debug.DrawRay(transform.position, -Vector3.up * 10, Color.red, 10);

    //        if (MyRayHit.collider != null)
    //        {
    //            if (MyRayHit.collider != null)
    //            {

    //                Vector3 localPoint = MyRayHit.transform.InverseTransformPoint(MyRayHit.point);
    //                Vector3 localDir = localPoint.normalized;

    //                float upDot = Vector3.Dot(localDir, Vector3.up);
    //                float fwdDot = Vector3.Dot(localDir, Vector3.forward);
    //                float rightDot = Vector3.Dot(localDir, Vector3.right);

    //                float upPower = Mathf.Abs(upDot);
    //                float fwdPower = Mathf.Abs(fwdDot);
    //                float rightPower = Mathf.Abs(rightDot);

    //                m_CollisionPoints.Add(MyRayHit.point);

    //                if ((upPower > fwdPower) && (upPower > rightPower))
    //                {
    //                    if (upPower >= 0)
    //                    {
    //                        Debug.Log("Collision point is below collider.");

    //                        Debug.Log(m_EntityName + " grounded on: " + MyRayHit.collider.gameObject.name);
    //                        m_ObjectLandedOn = collision.gameObject.transform;
    //                        m_RotationOfTheGround = MyRayHit.normal;
    //                        m_RotationOfTheGround.y = transform.rotation.y;

    //                        return true;
    //                    }
    //                    else
    //                    {
    //                        Debug.Log("Collision point is above collider.");
    //                    }
    //                }
    //                else if (fwdPower > rightPower)
    //                {
    //                    if (fwdPower > 0)
    //                    {
    //                        Debug.Log("Collision point is in front of the collider.");
    //                    }
    //                    else
    //                    {
    //                        Debug.Log("Collision point is in behind of the collider.");
    //                    }
    //                }
    //                else
    //                {
    //                    if (rightPower > 0)
    //                    {
    //                        Debug.Log("Collision point is to the right of the collider.");
    //                    }
    //                    else
    //                    {
    //                        Debug.Log("Collision point is to the left of the collider.");
    //                    }
    //                }

    //            }
    //        }
    //        else
    //        {
    //            Debug.Log(m_EntityName + " struck something but did not land on it");
    //        }
    //    }



    //    return false;
    //}

    void EffectorDroneBehaviors()
    {
        if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
        {
            if (m_EntityDestroyed || m_CurrentHullPoints <= 0) return;

            DisableEntity();
        }

        if (m_EntityState == EntityState.EFFECTOR_MISSED)
        {
            if (m_EntityDestroyed) return;

            DisableEntity();
        }
    }

    void ShipLaserDroneBehaviors()
    {
        if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
        {
            if (m_EntityDestroyed || m_CurrentHullPoints <= 0) return;

            Entity l_Entity = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 94);

            if(l_Entity)
            {
                SimulatorSettings.getAnimationManager().createLaserAnimation(l_Entity.m_EntityID, m_EntityID, 2f);
                DisableEntity();

                m_RigidBody.AddRelativeTorque(200, 0, 0, ForceMode.VelocityChange);
                m_RigidBody.AddExplosionForce(250, transform.position - transform.forward, 5, -1, ForceMode.Force);
            }
            else
            {
                DisableEntity();
            }
        }

        if (m_EntityState == EntityState.EFFECTOR_MISSED)
        {
            if (m_EntityDestroyed) return;

            DisableEntity();
        }
    }

    void LaserDroneBehaviors()
    {
        if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
        {
            if (m_EntityDestroyed || m_CurrentHullPoints <= 0 || m_LaserFired) return;

            if(m_TargetID >= 0)
            {
                SimulatorSettings.getAnimationManager().createLaserAnimation(m_EntityID, m_TargetID, 2);

                Quadcopter l_Copter = SimulatorSettings.getEntityList().getEntityByVIBEID(m_TargetID).GetComponent<Quadcopter>();

                if (l_Copter)
                {
                    l_Copter.m_RigidBody.AddRelativeTorque(200, 0, 0, ForceMode.VelocityChange);
                    l_Copter.m_RigidBody.AddExplosionForce(250, l_Copter.transform.position - l_Copter.transform.forward, 5, -1, ForceMode.Force);
                }

                m_LaserFired = true;
            }
        }

        if (m_EntityState == EntityState.EFFECTOR_MISSED)
        {
            if (m_EntityDestroyed) return;

            DisableEntity();
        }
    }

    void SwarmDroneBehaviors()
    {
        if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
        {
                Entity l_Target = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTID(this, 107);

                if (l_Target != null)
                {
                    SimulatorSettings.getAnimationManager().createLaserAnimation(m_EntityID, l_Target.m_EntityID, 3.0f);

                    m_EntityState = EntityState.DEFAULT_POSUPDATE;
                }
                else
                {
                    Debug.Log("Could not find type " + 107 + " to shoot laser at.");
                }
            
        }


    }

    void GroundLaunchedDroneBehaviors()
    {
        //Debug.Log(m_RigidBody.velocity.y);
        //if(m_RigidBody.velocity.y < -10.0f)
        if ((m_RigidBody.velocity.y < -10.0f) && (transform.position.y <= 30))
        {
            if (m_MovementScript)
            {
                m_MovementScript.enabled = true;
            }
        }
    }

    public override void SetRotation(Vector3 a_Rotation, bool a_UpdateDesiredValues = true)
    {
        SetRotation(Quaternion.Euler(a_Rotation));
    }

    public override void SetRotation(Quaternion a_Rotation, bool a_UpdateDesiredValues = true)
    {
        //Debug.Log("[QUAD] SetRotation(" + a_Rotation + ")");
        m_MovementScript.ResetDroneObjectRotation(a_Rotation.eulerAngles.y);
        m_CurrentHeading = transform.rotation.eulerAngles.y;
    }

    public void toggleViewBob()
    {
        if (m_CameraAttachPoint.parent == m_ControlObjects.transform)
        {
            Transform l_Transform = m_ModelLoader.m_Model.transform.Find("AnimatedGO");

            if (l_Transform)
            {
                m_CameraAttachPoint.SetParent(l_Transform);
            }
        }
        else
        {
            m_CameraAttachPoint.SetParent(m_ControlObjects.transform);
        }
    }

    public void InitialPlacement(Vector3 a_Position)
    {
        InitialPlacement(a_Position, Vector3.zero);
    }

    public override void InitialPlacement(Vector3 a_Position, Vector3 a_Rotation)
    {
        //if (SimulatorSettings.getDebugMode()) Debug.Log("Quadcopter Initial Placement (ID: " + m_EntityID + ")");
        Vector3 l_FinalPosition = a_Position;
        Vector3 l_FinalRotation = a_Rotation;

        if (m_EntitySMMTTID == 1002) // Ground Launched Quadcopter
        {
            Artillery l_Launcher = SimulatorSettings.getEntityList().getClosestEntityOfSMMTTIDIgnoringY(this, 3251) as Artillery;

            if (l_Launcher != null)
            {
                l_FinalPosition = l_Launcher.m_LaunchPoint.transform.position;
                l_FinalRotation = l_Launcher.m_LaunchPoint.transform.rotation.eulerAngles;
            }

            MovementEnabled(true);

            if (m_MovementScript)
            {
                m_MovementScript.enabled = false;
            }

            m_RigidBody.AddForce(l_Launcher.m_LaunchPoint.transform.forward * l_Launcher.m_LaunchForce);
            Debug.Log("Added force of: " + l_Launcher.m_LaunchForce);
        }


        SetPosition(l_FinalPosition);
        SetRotation(l_FinalRotation);

        if (m_EntitySMMTTID == 1054) // 4x Quad
        {
            Vector3 l_Offset1 = new Vector3(2.5f, 0, -2.5f);
            Vector3 l_Offset2 = new Vector3(-2.5f, 0, -2.5f);
            Vector3 l_Offset3 = new Vector3(0, 0, -2.5f);

            Entity l_Follower1 = SimulatorSettings.getEntityList().createAndAddEntity(1, 1004, transform.InverseTransformPoint(l_Offset1));
            Entity l_Follower2 = SimulatorSettings.getEntityList().createAndAddEntity(1, 1004, transform.InverseTransformPoint(l_Offset2));
            Entity l_Follower3 = SimulatorSettings.getEntityList().createAndAddEntity(1, 1004, transform.InverseTransformPoint(l_Offset3));

            SimulatorSettings.getAnimationManager().AddEntityFollower(l_Follower1, this, l_Offset1);
            SimulatorSettings.getAnimationManager().AddEntityFollower(l_Follower2, this, l_Offset2);
            SimulatorSettings.getAnimationManager().AddEntityFollower(l_Follower3, this, l_Offset3);
        }
        else
        {

        }

    }

    public override void ExecuteSpecialAction_1()
    {
        //Debug.Log("[Quad] Execute Special Action 1");

        m_Weapon.Trigger();
    }

    public override void StopSpecialAction_1()
    {
        //Debug.Log("[Quad] Stop Special Action 1");

        m_Weapon.StopExtend();
    }

    public override void ExecuteSpecialAction_2()
    {
        //Debug.Log("[Quad] Execute Special Action 2");

        m_Weapon.Reset();
    }

    public override void StopSpecialAction_2()
    {
        //Debug.Log("[Entity] Stop Special Action 2");


    }

    public override void ExecuteSpecialAction_3()
    {
        //Debug.Log("[Quad] Execute Special Action 3");

        m_Weapon.StartExtend();
    }

    public override void StopSpecialAction_3()
    {
        //Debug.Log("[Quad] Stop Special Action 3");

        m_Weapon.StopExtend();
    }

    public override void ExecuteSpecialAction_4()
    {
        //Debug.Log("[Quad] Execute Special Action 4");

        m_Weapon.StartRetract();
    }

    public override void StopSpecialAction_4()
    {
        //Debug.Log("[Quad] Stop Special Action 4");

        m_Weapon.StopRetract();
    }

    public override void FireWeapon()
    {

    }

    void IncreaseSpeed()
    {
        m_SpeedModifier += 1;

        if (m_SpeedModifier == 0) m_SpeedModifier = 1;
        
        m_MovementScript.movementForwardSpeed = m_NormalForwardForce * m_SpeedModifier;
        m_MovementScript.sideMovementAmount = m_NormalSidewaysForce * m_SpeedModifier;
        m_MovementScript.upForce = m_NormalUpForce * m_SpeedModifier;
        m_MovementScript.forceDownHover = m_NormalDownForce * m_SpeedModifier;

        m_MaxSpeed = m_OriginalMaxSpeed * m_SpeedModifier;
    }

    void DecreaseSpeed()
    {
        m_SpeedModifier -= 1;

        if (m_SpeedModifier <= 0) m_SpeedModifier = 1;

        m_MovementScript.movementForwardSpeed = m_NormalForwardForce * m_SpeedModifier;
        m_MovementScript.sideMovementAmount = m_NormalSidewaysForce * m_SpeedModifier;
        m_MovementScript.upForce = m_NormalUpForce * m_SpeedModifier;
        m_MovementScript.forceDownHover = m_NormalDownForce * m_SpeedModifier;

        m_MaxSpeed = m_OriginalMaxSpeed * m_SpeedModifier;
    }

    public override void MovementEnabled(bool a_Bool)
    {
        //Debug.Log(m_EntityName + " Movement has been " + a_Bool);
        m_MovementEnabled = a_Bool;
        m_MovementScript.enabled = a_Bool;
        m_RigidBody.useGravity = a_Bool;
        m_RigidBody.isKinematic = !a_Bool;
        //m_RigidBody.detectCollisions = a_Bool;
        if (m_TargetZone)
        {
            //Debug.Log("Target Zone Collider Enabled: " + a_Bool);
            m_TargetZone.m_MeshCollider.enabled = a_Bool;
        }
        //else Debug.Log("Target Zone link doesn't exist");

        if(a_Bool)
        {
            if (m_Transform.parent != null)
            {
                m_Transform.SetParent(null);
            }
        }
    }
}

