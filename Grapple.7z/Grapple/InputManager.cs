﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerMapping
{
    // General Controller Information read in from a config file
    public string ControllerName;
    public int NumberOfButtons;
    public int NumberOfAxes;
    public Dictionary<string, int> AxisMap;
    public Dictionary<string, int> ButtonMap;
    public Dictionary<string, int> DPadMap;

    // Instance Information, specific to each controller
    public int ControllerID;
    public Dictionary<int, int> ButtonData;
    public Dictionary<int, double> AxisData;
    public Dictionary<int, int> DPadData;

    public ControllerMapping()
    {
        ControllerName = "Blank";
        NumberOfButtons = 0;
        NumberOfAxes = 0;
        AxisMap = new Dictionary<string, int>();
        ButtonMap = new Dictionary<string, int>();
        DPadMap = new Dictionary<string, int>();

        ControllerID = 0;
        ButtonData = new Dictionary<int, int>();
        AxisData = new Dictionary<int, double>();
        DPadData = new Dictionary<int, int>();
    }
};

public class ControllerSourceInformation
{
    // Source Information, specific to each sender
    public int SourceVIBEJoystickID;
    
    public string SourceJoystickName;
    public string SourceAddress;
    public int SourceJoystickIndex;

    public Entity ConnectedObjectController;
    
    public ControllerSourceInformation()
    {
        SourceVIBEJoystickID = 0;
        SourceJoystickName = "Blank Controller";
        SourceAddress = "0.0.0.0";
        SourceJoystickIndex = 0;
    }
}

public class InputManager : MonoBehaviour {

    // General map of button configurations for each controller type
    Dictionary<string, ControllerMapping> m_ControllerTypes = new Dictionary<string, ControllerMapping>();

    // Map of active controllers
    Dictionary<int, ControllerMapping> m_Controllers = new Dictionary<int, ControllerMapping>();

    List<string> m_ControllerTypesDisplay = new List<string>();

    Dictionary<string, int> m_ControllerSourceNames = new Dictionary<string, int>();
    Dictionary<int, ControllerSourceInformation> m_ControllerSources = new Dictionary<int,ControllerSourceInformation>();

    public List<string> m_ConfiguredControllerTypes;
    public List<string> m_ConnectedControllersDisplayList;
    public int m_NumberOfControllerTypes;
    public int m_NumberOfControllerSources;
    public JoystickInputMode m_JoystickInputMode;

    public Entity m_CurrentActiveEntity;
    public Entity m_PreviousActiveEntity;

    public KeyboardInputManager m_KeyboardInputManager;

    public float m_Val;
    public float m_Tolerance;

    public Director m_Director;

    public List<KeyCode> m_ValidKeyboardShortcutKeys = new List<KeyCode>();
    public List<KeyCode> m_ValidKeyboardControllerKeys = new List<KeyCode>();

    public Dictionary<string, KeyCode> m_KeyboardControllerMap;
    public Dictionary<KeyCode, string> m_ReversedKeyboardControllerMap;

    public bool m_DebugTestKey = false;
    public KeyCode m_TestKey = KeyCode.UpArrow;

    public float m_QuadForwardForce;
    public float m_QuadSidewardForce;
    public float m_QuadUpwardForce;
    public float m_QuadDownwardForce;

    public bool consoleMode;

    public string[] m_CommandLineArgsString;

    public bool m_ResetSceneTrigger1;
    public bool m_ResetSceneTrigger2;

    public bool m_PrintInput;
    bool m_Initialized;

    public bool m_ShiftPressed;
    public bool m_CtrlPressed;

    public Vector3 m_MousePosition;

    public LayerMask m_LayerMask;

    public float m_RaycastLength;
    public LayerMask m_SelectionLayerMask;
    public LayerMask m_EntityLayerMask;
    public LayerMask m_TerrainLayerMask;

    public bool m_KeyboardInputActive;
    public bool m_MouseInputActive;

    public PhysicsManager m_PhysicsManager;

    // Temp Variables

    RaycastHit m_TempHit;
    float m_TempWidth;

    public bool SimStart()
    {
        //Debug.Log("SimStart: " + gameObject.name);
        m_Initialized = false;
        Start();
        //return m_Initialized;
        return true;
    }

	void Start ()
    {
        if(!m_Initialized)
        {
            
        }
	}

    public void PostStart()
    {
        //Debug.Log(gameObject.name + "::PostStart()");
        m_NumberOfControllerSources = 0;
        m_NumberOfControllerTypes = 0;
        m_JoystickInputMode = SimulatorSettings.getJoystickInputMode();

        m_CurrentActiveEntity = SimulatorSettings.getActiveEntity();
        m_PreviousActiveEntity = m_CurrentActiveEntity;

        m_ConfiguredControllerTypes = new List<string>();
        m_ConnectedControllersDisplayList = new List<string>();

        if (m_Director == null)
        {
            m_Director = SimulatorSettings.getDirector();
        }

        if(m_PhysicsManager == null)
        {
            m_PhysicsManager = SimulatorSettings.getPhysicsManager();
        }

        consoleMode = false;

        m_KeyboardControllerMap = SimulatorSettings.getConfigManager().m_KeyboardControllerControls;
        m_ReversedKeyboardControllerMap = new Dictionary<KeyCode,string>();

        m_ValidKeyboardShortcutKeys.Clear();

        foreach (KeyValuePair<string, KeyCode> l_Entry in m_KeyboardControllerMap)
        {
            m_ValidKeyboardShortcutKeys.Add(l_Entry.Value);
            m_ReversedKeyboardControllerMap.Add(l_Entry.Value, l_Entry.Key);
        }
        
        if (m_PrintInput)
        {
            foreach (KeyValuePair<string, KeyCode> attachStat in m_KeyboardControllerMap)
            {
                Debug.Log("Key: " + attachStat.Key + " - Value: " + attachStat.Value);
            }
        }
        m_Initialized = true;
    }

	void Update()
    {
        if (!m_Initialized) return;

        m_CurrentActiveEntity = SimulatorSettings.getActiveEntity();
        CheckTargetEntity();

        if ((Input.GetKey(KeyCode.LeftShift)) || (Input.GetKey(KeyCode.RightShift)))
        {
            m_ShiftPressed = true;
        }
        else
        {
            m_ShiftPressed = false;
        }

        if((Input.GetKey(KeyCode.LeftControl)) || (Input.GetKey(KeyCode.RightControl)))
        {
            m_CtrlPressed = true;
        }
        else
        {
            m_CtrlPressed = false;
        }

        if(m_KeyboardInputActive) HandleKeyboardInput();
        if(m_MouseInputActive) HandleMouseInput();
   
        //switch (m_JoystickInputMode)
        //{
        //    case JoystickInputMode.KEYBOARD:
        //        if(!consoleMode) HandleKeyboardControllerInput();
        //        break;
        //    case JoystickInputMode.UNITYINPUTMANAGER:
        //        HandleUnityManagerInput();
        //        break;
        //    default:
        //        break;
        //}
	}

    public void CheckTargetEntity()
    {
        if (m_CurrentActiveEntity != m_PreviousActiveEntity)
        {
            // If the Target Entity changed

            m_PreviousActiveEntity = m_CurrentActiveEntity;
        }

        
    }

    public void PrintCommandlineArgs()
    {
        Debug.Log("Command Line Args: ");
        for (int i = 0; i < m_CommandLineArgsString.Length; i++)
        {
            string l_Arg = m_CommandLineArgsString[i];

            Debug.Log("         [" + i + "] " + l_Arg);
        }
    }

    public void HandleKeyboardInput()
    {
        if (Input.GetKeyDown(KeyCode.BackQuote))
        {
            if (consoleMode)
            {
                consoleMode = false;
                //director.enableVehicleControl();
            }
            else
            {
                consoleMode = true;
                CMD.setScrollPosition(0);

                //director.disableVehicleControl();
            }

            SimulatorSettings.getUIManager().CheckIfMenusClosed();

            CMD.ToggleWindows(consoleMode);

        }

        if (!consoleMode)
        {
            foreach (KeyCode l_Key in m_ValidKeyboardShortcutKeys)
            {
                if (Input.GetKeyUp(l_Key))
                {
                    //Debug.Log("Key Up");
                    ExecuteControllerEvent(GetEventFromKey(l_Key), 0);
                }
                else if (Input.GetKeyDown(l_Key))
                {
                    ExecuteControllerEvent(GetEventFromKey(l_Key), 1);
                }
            }

            //if (Input.anyKeyDown)
            //{
            //    foreach (KeyCode l_Key in m_ValidKeyboardShortcutKeys)
            //    {
            //        if (Input.GetKeyDown(l_Key))
            //        {
            //            ExecuteControllerEvent(GetEventFromKey(l_Key), 1);
            //        }
            //        else if (Input.GetKeyUp(l_Key))
            //        {
            //            ExecuteControllerEvent(GetEventFromKey(l_Key), 0);
            //        }
            //    }
            //}
            //else
            //{
            //    foreach (KeyCode l_Key in m_ValidKeyboardShortcutKeys)
            //    {
            //        if (Input.GetKeyUp(l_Key))
            //        {
            //            ExecuteControllerEvent(GetEventFromKey(l_Key), 0);
            //        }
            //    }
            //}

            if (m_JoystickInputMode == JoystickInputMode.KEYBOARD)
            {
                HandleKeyboardControllerInput();
            }
        }
    }

    public void HandleKeyboardControllerInput()
    {
        if (GetKey("Forward_Positive"))
        {
            ExecuteControllerEvent("Forward", 1);
        }
        else if (GetKey("Forward_Negative"))
        {
            ExecuteControllerEvent("Forward", -1);
        }
        else
        {
            ExecuteControllerEvent("Forward", 0);
        }

        if (GetKey("Rudder_Positive"))
        {
            ExecuteControllerEvent("Rudder", 1);
        }
        else if (GetKey("Rudder_Negative"))
        {
            ExecuteControllerEvent("Rudder", -1);
        }
        else
        {
            ExecuteControllerEvent("Rudder", 0);
        }

        if (GetKey("Sideways_Positive"))
        {
            ExecuteControllerEvent("Sideways", 1);
        }
        else if (GetKey("Sideways_Negative"))
        {
            ExecuteControllerEvent("Sideways", -1);
        }
        else
        {
            ExecuteControllerEvent("Sideways", 0);
        }

        if (GetKey("ViewRotationVertical_Positive"))
        {
            ExecuteControllerEvent("ViewRotationVertical", 1);
        }
        else if (GetKey("ViewRotationVertical_Negative"))
        {
            ExecuteControllerEvent("ViewRotationVertical", -1);
        }
        else
        {
            ExecuteControllerEvent("ViewRotationVertical", 0);
        }

        if (GetKey("ViewRotationHorizontal_Positive"))
        {
            ExecuteControllerEvent("ViewRotationHorizontal", 1);
        }
        else if (GetKey("ViewRotationHorizontal_Negative"))
        {
            ExecuteControllerEvent("ViewRotationHorizontal", -1);
        }
        else
        {
            ExecuteControllerEvent("ViewRotationHorizontal", 0);
        }

        if (GetKey("Altitude_Positive"))
        {
            ExecuteControllerEvent("Altitude", 1);
        }
        else if (GetKey("Altitude_Negative"))
        {
            ExecuteControllerEvent("Altitude", -1);
        }
        else
        {
            ExecuteControllerEvent("Altitude", 0);
        }

        if (m_DebugTestKey) TestKey();
    }

    void TestKey()
    {
        if (Input.GetKeyDown(m_TestKey))
        {
            Debug.Log("Test Key down.");
        }
        else if (Input.GetKeyUp(m_TestKey))
        {
            Debug.Log("Test Up up.");
        }
        else if (Input.GetKey(m_TestKey))
        {
            Debug.Log("Test Key pressed.");
        }
    }

    public void HandleUnityManagerInput()
    {
        m_Val = Input.GetAxisRaw("Vertical");
        if ((m_Val > m_Tolerance) || (m_Val < -m_Tolerance))
        {
            ExecuteControllerEvent("Forward", m_Val);
        }
        else ExecuteControllerEvent("Forward", 0);

        m_Val = Input.GetAxisRaw("Horizontal");
        if ((m_Val > m_Tolerance) || (m_Val < -m_Tolerance))
        {
            ExecuteControllerEvent("Horizontal", m_Val);
        }
        else ExecuteControllerEvent("Horizontal", 0);

        m_Val = Input.GetAxisRaw("Vertical_Right");
        if (((m_Val) > m_Tolerance) || (m_Val < -m_Tolerance))
        {
            ExecuteControllerEvent("Altitude", m_Val);
        }
        else ExecuteControllerEvent("Altitude", 0);

        m_Val = Input.GetAxisRaw("Horizontal_Right");
        if (((m_Val) > m_Tolerance) || (m_Val < -m_Tolerance))
        {
            ExecuteControllerEvent("Rudder", m_Val);
        }
        else ExecuteControllerEvent("Rudder", 0);

        if (Input.GetKeyDown("joystick 1 button " + 4))
        {
            ExecuteControllerEvent("RotateCameraLeft", 1);
        }
        if (Input.GetKeyUp("joystick 1 button " + 4))
        {
            ExecuteControllerEvent("RotateCameraLeft", 0);
        }
        
        if (Input.GetKeyDown("joystick 1 button " + 5))
        {
            ExecuteControllerEvent("RotateCameraRight", 1);
        }
        if (Input.GetKeyUp("joystick 1 button " + 5))
        {
            ExecuteControllerEvent("RotateCameraRight", 0);
        }

        if (Input.GetKeyDown("joystick 1 button " + 6))
        {
            ExecuteControllerEvent("RotateCameraUp", 1);
        }
        if (Input.GetKeyUp("joystick 1 button " + 6))
        {
            ExecuteControllerEvent("RotateCameraUp", 0);
        }

        if (Input.GetKeyDown("joystick 1 button " + 7))
        {
            ExecuteControllerEvent("RotateCameraDown", 1);
        }
        if (Input.GetKeyUp("joystick 1 button " + 7))
        {
            ExecuteControllerEvent("RotateCameraDown", 0);
        }
    }


    public bool HandleNetworkControllerInput(Entity a_Entity, string a_Event, float a_Value)
    {
        return ExecuteControllerEvent(a_Entity, a_Event, a_Value);
    }

    public bool ExecuteControllerEvent(string a_Event, float a_Value)
    {
        return ExecuteControllerEvent(m_CurrentActiveEntity, a_Event, a_Value);
    }

    public bool ExecuteControllerEvent(Entity a_Entity, string a_Event, float a_Value)
    {
        //Debug.Log("Executing Controller Event::" + a_Event + " on Entity(" + a_Entity.m_EntityID + ") - Value: " + a_Value);

        bool l_KnownType = false;

        if (a_Entity == null)
        {
            //Debug.Log("Controller " + m_InputManager.getControllerSource(l_JoystickName).SourceVIBEJoystickID + "]: " + l_JoystickName + " exists in the list, but it has no assigned object. Skipping Message Number: " + i + ".");
            //Debug.Log("Entity: " + a_Entity + " - Event: " + a_Event + " - Value:" + a_Value);
        }
        else
        {
            //Debug.Log("Entity: " + a_Entity + " - Event: " + a_Event + " - Value:" + a_Value);

            if (a_Event.Contains("-Inverted"))
            {
                a_Value *= -1;
                a_Event = a_Event.Substring(0, a_Event.Length - 9);
            }
            if (a_Event.Contains("-Throttle"))
            {
                a_Value *= -1;
                a_Value += 1;
                a_Value /= 2;
                a_Event = a_Event.Substring(0, a_Event.Length - 9);
            }

            //System Commands
            if (a_Event.Equals("MoveCameraBack"))
            {
                if(a_Value == 1)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraBack = true;
                }
                else if(a_Value == 0)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraBack = false;
                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("MoveCameraForward"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraForward = true;
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraForward = false;
                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("MoveCameraUp"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraUp = true;
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraUp = false;
                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("MoveCameraDown"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraDown = true;
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraDown = false;
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ResetView"))
            {
                if (a_Value == 1)
                {
                    if (m_ShiftPressed)
                    {
                        SimulatorSettings.getConfigManager().ReloadScenario();
                    }
                    else
                    {
                        SimulatorSettings.getDirector().resetCameraView();
                    }
                }
                else if (a_Value == 0)
                {

                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("Zoom"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.zoom();
                }
                else if (a_Value == 0)
                {

                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("FireEffectorAtTarget"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().fireEffectorFromScreen();
                }
                else if (a_Value == 0)
                {

                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("FireEffector"))
            {
                if (a_Value == 1)
                {
                    //SimulatorSettings.getDirector().fireEffectorFromScreen();
                    Entity l_Entity = SimulatorSettings.getDirector().getCurrentEntity();

                    l_Entity.setState(EntityState.EFFECTOR_LAUNCHING);
                    l_Entity.setState(EntityState.DEFAULT_POSUPDATE);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("RangeCheck"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.rangeCheck(100000);
                }
                else if (a_Value == 0)
                {

                }
                
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateCameraNeutral"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationHorizontal = 0;
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationVertical = 0;
            }
            if (a_Event.Equals("RotateCameraLeft"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationHorizontal = -a_Value;
                
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateCameraRight"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationHorizontal = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateCameraDown"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationVertical = -a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateCameraUp"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_CameraRotationVertical = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToNextVehicle"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().switchToNextVehicle();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToPreviousVehicle"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().switchToPreviousVehicle();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("CameraRotation-Vertical"))
            {
                SimulatorSettings.getDirector().setVerticalRotation(a_Value);
                l_KnownType = true;
            }
            if (a_Event.Equals("CameraRotation-Horizontal"))
            {
                SimulatorSettings.getDirector().setHorizontalRotation(a_Value);
                l_KnownType = true;
            }
            if (a_Event.Equals("Neutral"))
            {
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraUp = false;
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraDown = false;
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraBack = false;
                SimulatorSettings.getDirector().getCurrentCameraObject().GetComponent<ViewSettings>().m_MoveCameraForward = false;
                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToOrigin"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(0);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint1"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(1);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint2"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(2);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint3"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(3);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint4"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(4);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint5"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(5);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint6"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(6);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint7"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(7);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint8"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(8);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("MoveToWaypoint9"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().moveCameraToCameraWaypoint(9);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity0"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 0)
                    {
                        if(SimulatorSettings.getDirector().getCurrentEntity().m_EntityID == 0)
                        {
                            if(SimulatorSettings.getDirector().getCurrentEntity().m_IsFollowingAnotherEntity)
                            {
                                SimulatorSettings.getAnimationManager().RemoveAllEntityFollowers();
                            }
                        }
                        else
                        {
                            SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[0]);
                        }
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity1"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 1)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[1]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity2"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 2)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[2]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity3"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 3)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[3]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity4"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 4)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[4]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity5"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 5)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[5]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity6"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 6)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[6]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity7"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 7)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[7]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity8"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 8)
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[8]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToEntity9"))
            {
                if (a_Value == 1)
                {
                    if ((SimulatorSettings.getDirector().m_KeySwitchEntities.Count > 9))
                    {
                        SimulatorSettings.getDirector().switchtoVehicleByID(SimulatorSettings.getDirector().m_KeySwitchEntities[9]);
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("RotateAroundObject"))
            {
                if (a_Value == 1)
                {
                    m_Director.toggleRotateAroundObject();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleOcean"))
            {
                if (a_Value == 1)
                {
                    //CMD.ExecuteCommand("toggleOcean");
                    if(m_ShiftPressed)
                    {
                        SimulatorSettings.getEnvironmentManager().toggleOceanTransparency();
                    }
                    else
                    {
                        SimulatorSettings.getEnvironmentManager().toggleOcean();
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleHUD"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().toggleHUD();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleUnderwaterContourLines"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getEnvironmentManager().ToggleUnderwaterContourLines();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("RangeCheck"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.rangeCheck(1000000);
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleEntityTrails"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getEntityList().ToggleEntityTrails();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("TogglePostProcessing"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().togglePostProcessing();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ResetScene1"))
            {
                if (a_Value == 1)
                {
                    m_ResetSceneTrigger1 = true;
                }
                else if (a_Value == 0)
                {
                    m_ResetSceneTrigger1 = false;
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ResetScene2"))
            {
                if (a_Value == 1)
                {
                    m_ResetSceneTrigger2 = true;
                }
                else if (a_Value == 0)
                {
                    m_ResetSceneTrigger2 = false;
                }

                l_KnownType = true;

                if (m_ResetSceneTrigger1 && m_ResetSceneTrigger2)
                {
                    Debug.Log("Reset Scene.");
                    Application.LoadLevel(0);
                }
            }
            if (a_Event.Equals("ResetScene"))
            {
                Debug.Log("Reset Scene.");
                Application.LoadLevel(0);

                l_KnownType = true;
            }
            if (a_Event.Equals("ControllerMode"))
            {
                if (a_Value == 1)
                {
                    JoystickInputMode l_Previous = SimulatorSettings.getInputManager().getInputMode();

                    if (SimulatorSettings.getInputManager().getInputMode() == JoystickInputMode.NSI)
                        SimulatorSettings.getInputManager().changeInputMode(JoystickInputMode.KEYBOARD);

                    else if (SimulatorSettings.getInputManager().getInputMode() == JoystickInputMode.KEYBOARD)
                        SimulatorSettings.getInputManager().changeInputMode(JoystickInputMode.NSI);

                    Debug.Log("Joystick Input Mode was " + l_Previous + " is now " + SimulatorSettings.getInputManager().getInputMode());
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleSignals"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getAnimationManager().toggleSignalEffect();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("JumpToTarget"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.TeleportCameraDroneToTarget();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchToTargetVehicle"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.SwitchToTargetVehicle();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SwitchCameraSpeed"))
            {
                if (a_Value == 1)
                {
                    if (SimulatorSettings.getActiveEntity().m_EntityType.Equals("QUADCOPTER"))
                    {
                        Quadcopter l_QController = SimulatorSettings.getActiveEntity() as Quadcopter;
                        l_QController.toggleSpeedMode();
                    }
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleRangeLaser"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.toggleRangeLaser();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleTargetMode"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().m_ViewSettings.m_TargetMode = !SimulatorSettings.getDirector().m_ViewSettings.m_TargetMode;
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleLaserEffects"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getAnimationManager().toggleLaserEffect();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleMouseCrosshairMode"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().getHUD().toggleMouseCrosshairMode();
                }
                else if (a_Value == 0)
                {

                }

                l_KnownType = true;
            }

            if (a_Event.Equals("ExecuteSpecialAction_1"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_1();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_1();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ExecuteSpecialAction_2"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_2();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_2();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ExecuteSpecialAction_3"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_3();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_3();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ExecuteSpecialAction_4"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_4();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_4();
                }

                l_KnownType = true;
            }
            //if (a_Event.Equals("ToggleOcean"))
            //{
            //    if (a_Value == 1)
            //    {

            //    }
            //    else if (a_Value == 0)
            //    {

            //    }

            //    l_KnownType = true;
            //}



            //Entity-Based Commands
            if (a_Event.Equals("Forward"))
            {
                if(a_Entity.m_EntityGear == EntityGear.FORWARD)
                {
                    a_Entity.m_LVerticalInput = a_Value;
                }
                else
                {
                    a_Entity.m_LVerticalInput = -a_Value;
                }
                l_KnownType = true;
            }
            if (a_Event.Equals("Sideways"))
            {
                a_Entity.m_LHorizontalInput = a_Value;
                l_KnownType = true;
            }
            //if (a_Event.Equals("R-Vertical"))
            //{
            //    a_Entity.m_RVerticalInput = a_Value;
            //    l_KnownType = true;
            //}
            //if (a_Event.Equals("R-Horizontal"))
            //{
            //    a_Entity.m_RHorizontalInput = a_Value;
            //    l_KnownType = true;
            //}
            if (a_Event.Equals("Rudder"))
            {
                a_Entity.m_InputRudder = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("Turret_Horizontal"))
            {
                a_Entity.m_RHorizontalInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("Turret_Vertical"))
            {
                a_Entity.m_RVerticalInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("TurretRight"))
            {
                if (a_Value == 1)
                {
                    a_Entity.m_RHorizontalInput = 1;
                }
                else
                {
                    a_Entity.m_RHorizontalInput = 0;
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("GearSwitch"))
            {
                if (a_Value == 1)
                {
                    a_Entity.m_EntityGear = EntityGear.REVERSE;
                }
                else
                {
                    a_Entity.m_EntityGear = EntityGear.FORWARD;
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("Altitude"))
            {
                a_Entity.m_InputAltitude = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("Altitude-Inverted"))
            {
                a_Entity.m_InputAltitude = a_Value * -1;
                l_KnownType = true;
            }
            if (a_Event.Equals("AltitudeDecrease"))
            {
                a_Entity.m_LBumperInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("AltitudeIncrease"))
            {
                a_Entity.m_RBumperInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateLeft"))
            {
                a_Entity.m_LTriggerInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RotateRight"))
            {
                a_Entity.m_RTriggerInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("AltitudeDecrease"))
            {
                a_Entity.m_LBumperInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("AltitudeIncrease"))
            {
                a_Entity.m_RBumperInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RudderLeft"))
            {
                a_Entity.m_InputRudder = -a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("RudderRight"))
            {
                a_Entity.m_InputRudder = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("TriggerLeft"))
            {
                a_Entity.m_LTriggerInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("TriggerRight"))
            {
                a_Entity.m_RTriggerInput = a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("LaunchTriggerOne"))
            {
                a_Entity.m_LStickButton = (int)a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("LaunchTriggerTwo"))
            {
                a_Entity.m_RStickButton = (int)a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("FireLaserAtScreenTarget"))
            {
                if (a_Value == 0)
                {
                    SimulatorSettings.getAnimationManager().removeLaserAnimation(a_Entity.m_EntityID);
                }
                if (a_Value == 1)
                {
                    SimulatorSettings.getAnimationManager().FireLaserAtScreenTarget(a_Entity);
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("FireLaserAtClosestTarget"))
            {
                if (a_Value == 0)
                {
                    SimulatorSettings.getAnimationManager().removeLaserAnimation(a_Entity.m_EntityID);
                }
                if (a_Value == 1)
                {
                    SimulatorSettings.getAnimationManager().FireLaserAtClosestTarget(a_Entity);
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("VisionMode"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getDirector().NextVisionMode();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("Fire"))
            {
                a_Entity.m_InputPrimaryTrigger = (int)a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("TriggerSpecialAnimation"))
            {
                a_Entity.m_InputSpecialAnimation = (int)a_Value;
                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleHelpMenu"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().toggleHelpMenu();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleFeatureMenu"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().toggleFeatureMenu();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleTacticalMenu"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().toggleTacticalMenu();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleRuntimeInspector"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().toggleRuntimeEditorMenu();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleCameraInfo"))
            {
                if (a_Value == 1)
                {
                    //SimulatorSettings.getConsoleCommands().cmd_toggleCameraInfo();
                    SimulatorSettings.getUIManager().toggleCameraInfo();
                }

                l_KnownType = true;
            }
            if(a_Event.Equals("ExitMenus"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getUIManager().ExitCurrentMenu();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SpecialAction_1"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_1();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_1();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SpecialAction_2"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_2();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_2();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SpecialAction_3"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_3();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_3();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("SpecialAction_4"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getActiveEntity().ExecuteSpecialAction_4();
                }
                else if (a_Value == 0)
                {
                    SimulatorSettings.getActiveEntity().StopSpecialAction_4();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("ToggleToggleTacticalFeatures"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getEnvironmentManager().ToggleTacticalFeatures();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("BreakFollow"))
            {
                if (a_Value == 1)
                {
                    SimulatorSettings.getAnimationManager().RemoveAllEntityFollowers();
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("nextCloudCover"))
            {
                if (a_Value == 1)
                {
                    if(m_ShiftPressed)
                    {
                        if (m_CtrlPressed)
                        {
                            SimulatorSettings.getTimeManager().AdvanceTimeOfDay(1);
                        }
                        else
                        {
                            SimulatorSettings.getTimeManager().AdvanceTimeOfDay(0.1f);
                        }
                    }
                    else
                    {
                        SimulatorSettings.getEnvironmentManager().nextWeatherID();
                    }
                }

                l_KnownType = true;
            }
            if (a_Event.Equals("previousCloudCover"))
            {
                if (a_Value == 1)
                {
                    if (m_ShiftPressed)
                    {
                        if (m_CtrlPressed)
                        {
                            SimulatorSettings.getTimeManager().AdvanceTimeOfDay(-1);
                        }
                        else
                        {
                            SimulatorSettings.getTimeManager().AdvanceTimeOfDay(-0.1f);
                        }
                    }
                    else
                    {
                        SimulatorSettings.getEnvironmentManager().prevWeatherID();
                    }
                }

                l_KnownType = true;
            }

            if (!l_KnownType)
            {
                if (a_Value == 1)
                {
                    if (CMD.HasCommand(a_Event))
                    {
                        CMD.ExecuteCommand(a_Event, false);
                        l_KnownType = true;
                    }
                }
            }
        }

        return l_KnownType;
    }

    public void clearMappings()
    {
        //Debug.Log("InputManager::clearMappings()");
        m_ControllerTypes.Clear();
        m_ControllerTypesDisplay.Clear();
    }

    public ControllerMapping AddControllerType(string a_ControllerName)
    {
        //Debug.Log("Adding Controller Type: " + a_ControllerName);

        ControllerMapping l_Controller = new ControllerMapping();

        l_Controller.ControllerName = a_ControllerName;
        //l_Controller.NumberOfButtons = a_NumButtons;
        //l_Controller.NumberOfAxes = a_NumAxes;

        m_ControllerTypes.Add(a_ControllerName, l_Controller);

        m_NumberOfControllerTypes++;

        m_ConfiguredControllerTypes.Add(a_ControllerName);
        return l_Controller;
    }

    public bool AddAxisMapping(ControllerMapping a_ControllerType, string a_AxisName, int a_AxisNumber)
    {
        //Debug.Log("AddAxisMapping: -" + a_ControllerType.ControllerName + "- -" + a_AxisName + "- -" + a_AxisNumber);

        bool l_MapAdded = false;
        bool l_DataAdded = false;

        bool l_Ret = false;

        if (a_ControllerType.NumberOfAxes <= a_AxisNumber)
        {
            if (!a_ControllerType.AxisMap.ContainsKey(a_AxisName))
            {
                a_ControllerType.AxisMap.Add(a_AxisName, a_AxisNumber);
                l_MapAdded = true;
            }

            if (!a_ControllerType.AxisMap.ContainsKey(a_AxisName))
            {
                a_ControllerType.AxisData.Add(a_AxisNumber, 0.0f);
                l_DataAdded = true;
            }

            if(l_MapAdded && l_DataAdded)
            {
                l_Ret = true;
            }
        }

        m_ControllerTypesDisplay.Add(a_AxisName + " " + a_AxisNumber);

        return l_Ret;
    }

    public bool AddButtonMapping(ControllerMapping a_ControllerType, string a_ButtonName, int a_ButtonNumber)
    {
        //Debug.Log("AddButtonMapping: " + a_ControllerType.ControllerName + " " + a_ButtonName + " " + a_ButtonNumber);

        bool l_Ret = false;

//        if (a_ControllerType.NumberOfButtons < a_ButtonNumber)
        {
            a_ControllerType.ButtonMap.Add(a_ButtonName, a_ButtonNumber);
            a_ControllerType.ButtonData.Add(a_ButtonNumber, 0);
            l_Ret = true;
        }

        m_ControllerTypesDisplay.Add(a_ButtonName + " " + a_ButtonNumber);

        return l_Ret;
    }

    public bool AddDirectionalPadMapping(ControllerMapping a_ControllerType, string a_DPadName, int a_DPadNumber)
    {

        bool l_Ret = false;

        a_ControllerType.DPadMap.Add(a_DPadName, a_DPadNumber);
        a_ControllerType.DPadData.Add(a_DPadNumber, 0);
        l_Ret = true;

        m_ControllerTypesDisplay.Add(a_DPadName + " " + a_DPadNumber);

        return l_Ret;
    }

    void RemoveController(int a_ControllerID)
    {
        m_Controllers.Remove(a_ControllerID);
    }

    double GetAxis(int a_ControllerID, string a_AxisName)
    {
        double l_Value = -1.0f;

        if (m_Controllers.ContainsKey(a_ControllerID))
        {
            ControllerMapping l_Controller = m_Controllers[a_ControllerID];

            if (l_Controller.AxisMap.ContainsKey(a_AxisName))
            {
                int l_AxisNum = l_Controller.AxisMap[a_AxisName];
                l_Value = l_Controller.AxisData[l_AxisNum];
            }
        }

        return l_Value;
    }

    int GetButton(int a_ControllerID, string a_ButtonName)
    {
        int l_Value = -1;

        if (m_Controllers.ContainsKey(a_ControllerID))
        {
            ControllerMapping l_Controller = m_Controllers[a_ControllerID];

            if (l_Controller.ButtonMap.ContainsKey(a_ButtonName))
            {
                int l_ButtonNum = l_Controller.AxisMap[a_ButtonName];
                l_Value = l_Controller.ButtonData[l_ButtonNum];
            }
        }

        return l_Value;
    }

    public string getAxisNameFromNumber(string a_ControllerName, int a_Axis)
    {
        string l_Ret = "";

        if (m_ControllerTypes.ContainsKey(a_ControllerName))
        {
            ControllerMapping l_Mapping = m_ControllerTypes[a_ControllerName];            
            
            foreach (string key in l_Mapping.AxisMap.Keys)
            {
                //Debug.Log("Key (" + l_Mapping.AxisMap[key] + ") Axis (" + a_Axis + ")");
                if (l_Mapping.AxisMap[key] == a_Axis)
                {
                    l_Ret = key;
                }
            }
        }

        if (l_Ret.Equals(""))
        {
            //Debug.Log("Could not find mapping for " + a_ControllerName + " Axis " + a_Axis);
        }
        return l_Ret;
    }

    public string getButtonNameFromNumber(string a_ControllerName, int a_Button)
    {
        string l_Ret = "";

        if (m_ControllerTypes.ContainsKey(a_ControllerName))
        {
            ControllerMapping l_Mapping = m_ControllerTypes[a_ControllerName];

            foreach (string key in l_Mapping.ButtonMap.Keys)
            {
                if (l_Mapping.ButtonMap[key] == a_Button)
                {
                    l_Ret = key;
                }
            }
        }
        else
        {
            Debug.Log("InputManager::getButtonNameFromNumber(): Config File does not contain definition for controller of type: " + a_ControllerName);
        }

        return l_Ret;
    }

    public string getDPadNameFromNumber(string a_ControllerName, int a_DPad)
    {
        string l_Ret = "";

        if (m_ControllerTypes.ContainsKey(a_ControllerName))
        {
            ControllerMapping l_Mapping = m_ControllerTypes[a_ControllerName];

            foreach (string key in l_Mapping.DPadMap.Keys)
            {
                if (l_Mapping.DPadMap[key] == a_DPad)
                {
                    l_Ret = key;
                }
            }
        }
        else
        {
            Debug.Log("InputManager::getDPadNameFromNumber(): Config File does not contain definition for controller of type: " + a_ControllerName);
        }

        return l_Ret;
    }

    public ControllerSourceInformation addControllerSource(string a_ControllerInfo)
    {
        Debug.Log("Adding Controller: " + a_ControllerInfo);

        string[] items = a_ControllerInfo.Split('-');
        
        if(items.Length == 3)
        {
            ControllerSourceInformation l_Ret = new ControllerSourceInformation();

            l_Ret.SourceAddress = items[0];
            l_Ret.SourceJoystickName = items[1];
            l_Ret.SourceJoystickIndex = parseStringToInt(items[2]);

            Debug.Log("l_Ret.SourceAddress(" + l_Ret.SourceAddress + ") l_Ret.SourceJoystickName(" + l_Ret.SourceJoystickName + ") l_Ret.SourceJoystickIndex(" + l_Ret.SourceJoystickIndex + ")");

            l_Ret.SourceVIBEJoystickID = m_ControllerSources.Count;

            m_ControllerSourceNames.Add(a_ControllerInfo, m_ControllerSources.Count);
            m_ControllerSources.Add(l_Ret.SourceVIBEJoystickID, l_Ret);

            m_NumberOfControllerSources++;
            m_ConnectedControllersDisplayList.Add("Controller " + l_Ret.SourceVIBEJoystickID + ": " + a_ControllerInfo);
            return l_Ret;
        }

        return null;
    }

    public ControllerSourceInformation getControllerSource(string a_ControllerInfo)
    {
        //Debug.Log("InputManager::removeControllerSource(): " + a_ControllerInfo);

        ControllerSourceInformation l_Ret = null;

        if (m_ControllerSourceNames.ContainsKey(a_ControllerInfo))
        {
            int l_Index = m_ControllerSourceNames[a_ControllerInfo];

            if (m_ControllerSources.ContainsKey(l_Index))
            {
                l_Ret = m_ControllerSources[l_Index];
            }
            else
            {
                Debug.Log("Controller " + l_Index + " does not exist in the list.");
            }
        }
        else
        {
            Debug.Log("Controller Source " + a_ControllerInfo + " does not exist in the list.");
        }


        return l_Ret;
    }

    public void removeControllerSource(int a_ControllerID)
    {
        //Debug.Log("InputManager::removeControllerSource(): " + a_ControllerID);

        if(m_ControllerSources.ContainsKey(a_ControllerID))
        {
            m_ControllerSources.Remove(a_ControllerID);
        }
        else
        {
            Debug.Log("Controller " + a_ControllerID + " does not exist in the list.");
        }
    }

    public void assignControllerSource(int a_ControllerID, int a_Target)
    {
        //Debug.Log("InputManager::assignControllerSource(): " + a_ControllerID + " " + a_Target);

        if (m_ControllerSources.ContainsKey(a_ControllerID))
        {
            if (m_ControllerSources[a_ControllerID].ConnectedObjectController != null)
            {
                unassignControllerSource(a_ControllerID);
            }

            if (m_ControllerSources[a_ControllerID].ConnectedObjectController) m_ControllerSources[a_ControllerID].ConnectedObjectController.ClearInputs();

            Entity l_Controller = SimulatorSettings.getEntityList().getEntityByVIBEID(a_Target).GetComponent<Entity>();
            m_ControllerSources[a_ControllerID].ConnectedObjectController = l_Controller;
            l_Controller.switchEntityControl(EntityControlType.PLAYER);
            
            m_ConnectedControllersDisplayList.Add("Controller: " + a_ControllerID + " is now attached to ID: " + a_Target);
            l_Controller.m_JoystickID = a_ControllerID;
            l_Controller.m_JoystickName = m_ControllerSources[a_ControllerID].SourceJoystickName;
            l_Controller.m_ControllerAssigned = true;

            Debug.Log("Assigning Controller " + a_ControllerID + "(" + m_ControllerSources[a_ControllerID].SourceJoystickName + ") to ID " + l_Controller.m_EntityID + " (" + l_Controller.name + ")");
        }
        else
        {
            Debug.Log("ControllerSources does not contain '" + a_ControllerID + "'");
        }
    }

    public void unassignControllerSource(int a_ControllerID)
    {
        if (m_ControllerSources.ContainsKey(a_ControllerID))
        {
            if (m_ControllerSources[a_ControllerID].ConnectedObjectController != null)
            {
                if (m_ControllerSources[a_ControllerID].ConnectedObjectController.m_ControlType == EntityControlType.PLAYER)
                {
                    Debug.Log("Controller " + a_ControllerID + " is connected to something else. Removing.");
                    m_ControllerSources[a_ControllerID].ConnectedObjectController.switchEntityControl(EntityControlType.NONE);
                    m_ControllerSources[a_ControllerID].ConnectedObjectController.m_JoystickName = "";
                    m_ControllerSources[a_ControllerID].ConnectedObjectController.m_JoystickID = -1;
                }
            }
            else
            {
                Debug.Log("Controller " + a_ControllerID + " has yet to be allocated, and does not need to be unassigned.");
            }
        }
    }

    int parseStringToInt(string a_Input)
    {
        int l_Ret = -1;

        if (int.TryParse(a_Input, out l_Ret)) // Valid input, do something with it.
        {

        }
        else // Not a number, do something else with it.
        {
            l_Ret = -1;
        }

        return l_Ret;
    }

    public Entity getControlledObject(string a_ControllerInfo)
    {
        //Debug.Log("InputManager::getControlledObject(): " + a_ControllerInfo);

        Entity l_Ret = null;

        if (m_ControllerSourceNames.ContainsKey(a_ControllerInfo))
        {
            int l_Index = m_ControllerSourceNames[a_ControllerInfo];

            if (m_ControllerSources.ContainsKey(l_Index))
            {
                if (m_ControllerSources[l_Index] != null)
                {
                    if (m_ControllerSources[l_Index].ConnectedObjectController != null)
                    {
                        l_Ret = m_ControllerSources[l_Index].ConnectedObjectController;
                    }
                    else
                    {
                        Debug.Log("m_ControllerSources[l_Index].ConnectedObjectController is null");
                    }
                }
                else
                {
                    Debug.Log("m_ControllerSources[l_Index] is null");

                }
            }
            else
            {
                Debug.Log("ControllerSources does not contain '" + l_Index + "'");
            }
        }
        else
        {
            Debug.Log("ControllerInfoList does not contain '" + a_ControllerInfo + "'");
        }

        return l_Ret;
    }

    public ControllerSourceInformation getControllerSourceInfo(string a_ControllerInfo)
    {
        //Debug.Log("InputManager::getControllerSourceInfo(): " + a_ControllerInfo);

        ControllerSourceInformation l_Ret = null;

        if (m_ControllerSourceNames.ContainsKey(a_ControllerInfo))
        {
            int l_Index = m_ControllerSourceNames[a_ControllerInfo];

            if(m_ControllerSources.ContainsKey(l_Index))
            {
                l_Ret = m_ControllerSources[l_Index];
            }
            else
            {
                Debug.Log("ControllerInfoList does not contain '" + a_ControllerInfo + "'");
            }
            
        }
        else
        {
            Debug.Log("ControllerInfoList does not contain '" + a_ControllerInfo + "'");
        }

        return l_Ret;
    }

    public bool controllerExistsInList(string a_ControllerInfo)
    {
        if (m_ControllerSourceNames.ContainsKey(a_ControllerInfo))
        {
            return true;
        }

        return false;
    }

    public void printControllerMappings()
    {
        foreach (KeyValuePair<string,ControllerMapping> l_ArrayItem in m_ControllerTypes)
        {
            ControllerMapping l_Controller = l_ArrayItem.Value;

            Debug.Log(l_Controller.ControllerName + " --");

            foreach (KeyValuePair<string,int> l_Axis in l_Controller.AxisMap)
            {
                Debug.Log("     Key: " + l_Axis.Key + " - Value: " + l_Axis.Value);
            }

            foreach (KeyValuePair<string, int> l_Button in l_Controller.ButtonMap)
            {
                Debug.Log("     Key: " + l_Button.Key + " - Value: " + l_Button.Value);
            }

            foreach (KeyValuePair<string, int> l_DPad in l_Controller.DPadMap)
            {
                Debug.Log("     Key: " + l_DPad.Key + " - Value: " + l_DPad.Value);
            }
        }
    }

    public JoystickInputMode getInputMode()
    {
        return m_JoystickInputMode;
    }

    public void changeInputMode(int a_Mode)
    {
        JoystickInputMode l_Mode = JoystickInputMode.UNKNOWN;

        if (a_Mode == 1) l_Mode = JoystickInputMode.UNITYINPUTMANAGER;
        if (a_Mode == 2) l_Mode = JoystickInputMode.NSI;
        if (a_Mode == 3) l_Mode = JoystickInputMode.KEYBOARD;

        changeInputMode(l_Mode);
    }

    public void changeInputMode(JoystickInputMode a_Mode)
    {
        m_JoystickInputMode = a_Mode;
        SimulatorSettings.setJoystickInputMode(a_Mode);
    }

    public KeyCode getKeyboardKeycode(string a_Input)
    {
        KeyCode l_Ret = KeyCode.None;

        if (m_KeyboardControllerMap.ContainsKey(a_Input))
        {
            l_Ret = m_KeyboardControllerMap[a_Input];
        }

        return l_Ret;
    }

    public bool GetKey(string a_KeyName)
    {
        bool l_Ret = false;
        KeyCode l_Key = getKeyboardKeycode(a_KeyName);

        if (l_Key != KeyCode.None)
        {
            if (Input.GetKey(l_Key))
            {
                l_Ret = true;
            }
        }

        //Debug.Log("Keyname: " + a_KeyName + " returned keycode " + l_Key + " getkeydown returned " + l_Ret);
        return l_Ret;
    }

    public string GetEventFromKey(KeyCode a_Keycode)
    {
        string l_Ret = "";

        if(m_ReversedKeyboardControllerMap.ContainsKey(a_Keycode))
        {
            l_Ret = m_ReversedKeyboardControllerMap[a_Keycode];
        }

        return l_Ret;
    }

    public bool GetKeyDown(string a_KeyName)
    {
        bool l_Ret = false;
        KeyCode l_Key = getKeyboardKeycode(a_KeyName);



        if (l_Key != KeyCode.None)
        {
            if (Input.GetKeyDown(l_Key))
            {
                l_Ret = true;
            }
        }

        //Debug.Log("Keyname: " + a_KeyName + " returned keycode " + l_Key + " getkeydown returned " + l_Ret);
        return l_Ret;
    }

    public bool GetKeyUp(string a_KeyName)
    {
        bool l_Ret = false;
        KeyCode l_Key = getKeyboardKeycode(a_KeyName);



        if (l_Key != KeyCode.None)
        {
            if (Input.GetKeyUp(l_Key))
            {
                l_Ret = true;
            }
        }

        //Debug.Log("Keyname: " + a_KeyName + " returned keycode " + l_Key + " getkeydown returned " + l_Ret);
        return l_Ret;
    }

    void HandleMouseInput()
    {
        m_MousePosition = Input.mousePosition;

        if (Input.GetMouseButtonDown(0)) // Left Click
        {
            //RaycastHit m_TempHit = GetHitPointFromClick();
            //if (m_TempHit.collider != null)
            //{

            //}
        }
        else if (Input.GetMouseButtonDown(1)) // Right Click
        {
            m_TempHit = m_PhysicsManager.GetContextHitPointFromClick();
            //RaycastHit m_TempHit = GetContextHitPointFromClick();

            if (m_TempHit.collider != null)
            {
                //Debug.Log("Right clicked on object: " + m_TempHit.collider.name);

                Entity l_Entity = m_TempHit.transform.gameObject.GetComponent<Entity>();

                if (l_Entity)
                {
                    l_Entity.TriggerContextMenu(m_TempHit.point);
                }
                else
                {
                    TargetZone l_TargetZone = m_TempHit.transform.gameObject.GetComponent<TargetZone>();

                    if(l_TargetZone)
                    {
                        l_TargetZone.m_Controller.TriggerContextMenu(m_TempHit.point);
                    }
                }
            }
        }
        else if (Input.GetMouseButtonDown(2)) // Middle Click
        {

        }
    }

    public RaycastHit GetEntityHitPointFromClick(Vector3 a_MousePosition)
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        Physics.Raycast(ray, out hit, 300000, m_EntityLayerMask);

        if (hit.collider != null)
        {
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }

    //RaycastHit GetHitPointFromClick()
    //{
    //    int hoveredDisplay = Common.GetHoveredDisplay();
    //    Ray ray = SimulatorSettings.getDirector().GetMousePosScreenPointToRay();
    //    RaycastHit hit;

    //    Physics.Raycast(ray, out hit, 100000, m_LayerMask);

    //    if (hit.collider != null)
    //    {
    //        if (hit.collider.transform.name == "FakeOceanCollider")
    //        {
    //            hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
    //        }
    //    }

    //    return hit;
    //}

    public RaycastHit GetHitPointFromClick()
    {
        return GetHitPointFromClick(Input.mousePosition);
    }

    public RaycastHit GetHitPointFromClick(Vector3 a_MousePosition)
    {
        Ray ray;

        if (Application.isEditor)
        {
            ray = m_Director.GetOverlayMousePosScreenPointToRay(a_MousePosition);
        }
        else
        {
            a_MousePosition.x -= (SimulatorSettings.getDirector().m_CurrentDisplayIndex * SimulatorSettings.getDirector().windowWidth);
            ray = m_Director.GetMousePosScreenPointToRay(a_MousePosition);
        }

        //Ray ray = new Ray();
        //ray.origin = m_Director.getMainCamera().transform.position;
        //ray.direction = m_Director.getMainCamera().transform.position - Display.RelativeMouseAt(Input.mousePosition);


        RaycastHit hit;

        Physics.Raycast(ray, out hit, 100000, m_LayerMask);

        if (hit.collider != null)
        {
            //Debug.DrawRay(ray.origin, ray.direction * hit.distance, Color.red, 10);
            //Debug.DrawLine(hit.point, hit.point + new Vector3(0, 15, 0), Color.blue, 10);

            //Debug.Log("Ray: " + ray + " Hit: " + hit.point);
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }

    public RaycastHit GetHitPointFromClick(LayerMask a_Layer)
    {
        return GetHitPointFromClick(Input.mousePosition, a_Layer);
    }

    public RaycastHit GetHitPointFromClick(Vector3 a_MousePosition, LayerMask a_Layer)
    {
        Ray ray;

        if (Application.isEditor)
        {
            ray = m_Director.GetOverlayMousePosScreenPointToRay(a_MousePosition);
        }
        else
        {
            a_MousePosition.x -= (SimulatorSettings.getDirector().m_CurrentDisplayIndex * SimulatorSettings.getDirector().windowWidth);
            ray = m_Director.GetMousePosScreenPointToRay(a_MousePosition);
        }

        //Ray ray = new Ray();
        //ray.origin = m_Director.getMainCamera().transform.position;
        //ray.direction = m_Director.getMainCamera().transform.position - Display.RelativeMouseAt(Input.mousePosition);


        RaycastHit hit;

        Physics.Raycast(ray, out hit, 100000, a_Layer);

        if (hit.collider != null)
        {
            //Debug.DrawRay(ray.origin, ray.direction * hit.distance, Color.red, 10);
            //Debug.DrawLine(hit.point, hit.point + new Vector3(0, 15, 0), Color.blue, 10);

            //Debug.Log("Ray: " + ray + " Hit: " + hit.point);
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }

    public RaycastHit GetContextHitPointFromClick()
    {
        return GetContextHitPointFromClick(Input.mousePosition);
    }

    public RaycastHit GetContextHitPointFromClick(Vector3 a_MousePosition)
    {
        Ray ray;

        if (Application.isEditor)
        {
            Debug.Log("Display[" + m_Director.m_CurrentDisplayIndex + "] - System Height/Width: " + Display.displays[m_Director.m_CurrentDisplayIndex].systemHeight + "/" + +Display.displays[m_Director.m_CurrentDisplayIndex].systemWidth + " - System Height/Width:: " + Display.displays[m_Director.m_CurrentDisplayIndex].systemHeight + "/" + +Display.displays[m_Director.m_CurrentDisplayIndex].systemWidth);
            ray = m_Director.GetOverlayMousePosScreenPointToRay(a_MousePosition);
        }
        else
        {
            m_TempWidth = 0;

            for (int i = 0; i < SimulatorSettings.getDirector().m_CurrentDisplayIndex; i++)
            {
                m_TempWidth += Display.displays[m_Director.m_CurrentDisplayIndex].renderingWidth;
            }

            Debug.Log("TempWidth: " + m_TempWidth);

            a_MousePosition.x -= (SimulatorSettings.getDirector().m_CurrentDisplayIndex * SimulatorSettings.getDirector().windowWidth);
            Debug.Log("Display[" + m_Director.m_CurrentDisplayIndex + "] - System Height/Width: " + Display.displays[m_Director.m_CurrentDisplayIndex].systemHeight + "/" + Display.displays[m_Director.m_CurrentDisplayIndex].systemWidth + " - System Height/Width:: " + Display.displays[m_Director.m_CurrentDisplayIndex].systemHeight + "/" + +Display.displays[m_Director.m_CurrentDisplayIndex].systemWidth);
            ray = m_Director.GetMousePosScreenPointToRay(a_MousePosition);
        }

        //Ray ray = new Ray();
        //ray.origin = m_Director.getMainCamera().transform.position;
        //ray.direction = m_Director.getMainCamera().transform.position - Display.RelativeMouseAt(Input.mousePosition);


        RaycastHit hit;

        Physics.Raycast(ray, out hit, 100000, m_EntityLayerMask);

        if (hit.collider != null)
        {
            //Debug.DrawRay(ray.origin, ray.direction * hit.distance, Color.red, 10);
            //Debug.DrawLine(hit.point, hit.point + new Vector3(0, 15, 0), Color.blue, 10);

            //Debug.Log("Ray: " + ray + " Hit: " + hit.point);
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }

    public RaycastHit GetSelectionHitPointFromClick(Vector3 a_MousePosition)
    {
        Ray ray;

        if (Application.isEditor)
        {
            ray = m_Director.GetOverlayMousePosScreenPointToRay(a_MousePosition);
        }
        else
        {
            a_MousePosition.x -= (SimulatorSettings.getDirector().m_CurrentDisplayIndex * SimulatorSettings.getDirector().windowWidth);
            ray = m_Director.GetMousePosScreenPointToRay(a_MousePosition);
        }

        //Ray ray = new Ray();
        //ray.origin = m_Director.getMainCamera().transform.position;
        //ray.direction = m_Director.getMainCamera().transform.position - Display.RelativeMouseAt(Input.mousePosition);


        RaycastHit hit;

        Physics.Raycast(ray, out hit, m_RaycastLength, m_SelectionLayerMask);

        if (hit.collider != null)
        {
            //Debug.DrawRay(ray.origin, ray.direction * hit.distance, Color.red, 10);
            //Debug.DrawLine(hit.point, hit.point + new Vector3(0, 15, 0), Color.blue, 10);

            //Debug.Log("Ray: " + ray + " Hit: " + hit.point);
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }

    public RaycastHit GetTerrainHitPointFromClick(Vector3 a_MousePosition)
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        Physics.Raycast(ray, out hit, 300000, m_TerrainLayerMask);

        if (hit.collider != null)
        {
            if (hit.collider.transform.name == "FakeOceanCollider")
            {
                hit.point = new Vector3(hit.point.x, SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(hit.point), hit.point.z);
            }
        }

        return hit;
    }
}
