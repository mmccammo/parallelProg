﻿using System.Collections;
using System.Collections.Generic;
using System.Reflection;

using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

#if UNITY_EDITOR
using UnityEditor;
#endif

public enum EntityGear
{
    FORWARD = 0,
    REVERSE
};

public class Entity : MonoBehaviour
{
    public Entity()
    {
        //Debug.Log("[" + this.GetType().ToString() + "] Constructor called.");
    }

    ~Entity()
    {
        //Debug.Log("[" + this.GetType().ToString() + "] Destructor called.");
    }

    [System.NonSerialized]
    public float metersToKnots = 1.943844f;
    [System.NonSerialized]
    public float knotsToMeters = 0.514444f;

    [Header("Entity Initialization Status")]

    public bool m_EntityStarted = false;
    public bool m_ModelInformation_Initialized = false;
    public bool m_PositionData_Initialized = false;
    public bool m_EntityInitialized = false;

    protected int m_TimesAttemptedInitialization = 0;
    protected int m_TimesToAttemptInitialization = 5;

    public bool m_QueuedForDestruction = false;

    public bool m_IsLoaded;
    public bool m_IsFalling;
    public bool m_IsRising;
    public bool m_ConversionActive;

    [Header("Model Information")]

    public ModelLoader m_ModelLoader;
    public EntityControlObjects m_ControlObjects;

    public string m_EntityModelName;
    public int m_EntitySMMTTID;
    public string m_EntityType;
    public float m_EntityLengthInMeters = 10;
    public float m_EntityMassInTons = 10;
    public float m_MaxSpeed = 40;
    public float m_OriginalMaxSpeed = -1;
    public float m_MaxReverseSpeed = 20;
    public float m_Acceleration = 0.005F;
    public float m_TurningSpeed = 1.0f;
    public Vector3 m_ModelRotation = Vector3.zero;

    public Transform m_CenterOfMass;

    public bool m_EntityDestroyed = false;

    public int m_TotalHullPoints = 1;
    public Bounds m_ModelBounds;
    public bool m_IsTarget;
    public bool m_IsMovableObject;
    public bool m_IsDrivable;
    public bool m_IsSavedPrefab = false;
    public bool m_UsesEntityTrail = true;

    [Header("Instance Information")]

    public string m_EntityName;
    public int m_EntityID;
    public int m_XSIMID = -1;
    public string m_SourceName;
    public int m_StatusFlag;
    public bool m_UseExternalPhysics;

    public EntityState m_EntityState;
    public EntityState m_PreviousEntityState;

    public float m_CurrentHeading = 0.0f;
    public float m_DesiredHeading = 0.0f;

    public float m_CurrentPitch = 0.0f;
    public float m_DesiredPitch = 0.0f;

    public float m_CurrentRoll = 0.0f;
    public float m_DesiredRoll = 0.0f;

    public float m_CurrentSpeed = 0.0f;
    public float m_DesiredSpeed = 0.0f;


    public float m_CurrentAltitude = 0.0f;
    public float m_DesiredAltitude = 0.0f;

    public float m_DesiredDepth = 0.0f;
    public float m_CurrentDepth = 0.0f;

    [Header("Display Information")]

    protected string m_DisplayName;

    [Header("Position Data:")]

    public Vector3 currentXYZPosition;
    [System.NonSerialized]
    public Vector3 previousXYZPosition;

    public Vector2 currentGPSPosition;
    [System.NonSerialized]
    public Vector2 previousGPSPosition;

    public PrecisionGPS m_PreciseGPS;

    [System.NonSerialized]
    public Vector3 m_OriginalPosition;

    public float m_Elevation;

    [Header("Command Module")]

    public bool m_MovementEnabled = true;
    public EntityControlType m_ControlType;

    public bool m_ControllerAssigned = false;
    public string m_JoystickName;
    public int m_JoystickID;

    public float m_LVerticalInput = 0;
    public float m_LHorizontalInput = 0;
    public float m_RVerticalInput = 0;
    public float m_RHorizontalInput;
    public float m_LBumperInput = 0;
    public float m_RBumperInput = 0;
    public float m_LTriggerInput = 0;
    public float m_RTriggerInput = 0;
    public int m_InputSpecialAnimation = 0;

    public int m_LStickButton = 0;
    public int m_RStickButton = 0;

    public float m_InputAltitude = 0;
    public float m_InputRudder = 0;
    public int m_InputPrimaryTrigger = 0;

    public EntityGear m_EntityGear;
    public float m_SpeedOverride;

    [System.NonSerialized]
    public bool m_NetworkVehicleHasBeenPlaced;

    public UIManager m_UIManager;

    //

    [Header("Animation Information")]

    public bool m_Sinkable;
    public bool m_EntityIsSinking;
    public bool m_EntityStartedSinking = false;
    public bool m_EntitySunkToTheBottom;

    public Quaternion m_OriginalRotation;
    public float m_OriginalMass;
    public int m_OriginalHullPoints;
    public EntityState m_OriginalState;

    public int m_CurrentHullPoints;

    public float m_SinkingSpeed;
    protected bool m_HasSmoke;
    public Dictionary<string, ParticleSystem> m_ParticleList = new Dictionary<string, ParticleSystem>();
    public int m_ParticleListSize;

    public int m_NumberOfEntitiesBroadcastingTo;
    public int m_NumberOfEntitiesReceivingFrom;

    public Dictionary<int, Entity> m_EntitiesBroadcastingTo = new Dictionary<int, Entity>();
    public Dictionary<int, Entity> m_EntitiesReceivingFrom = new Dictionary<int, Entity>();

    public float m_ElevationChangeSpeed = 1.0f;
    public bool m_EnableElevationUpdates = false;

    public int m_NumberOfEffectorsRemaining = 0;

    public float m_HeightOfWater;
    public float m_HeightOfLand;

    [Header("Object Options")]
    public bool m_ForceRestart;
    public bool m_ForceResizeModel;
    public bool m_ForceNewAttachpoint;
    public bool m_ForceResizeCollisionDetectionBox;
    public bool m_EnableUniqueBehaviors = true;
    public bool m_DebugMode;

    public float m_TestMagnitude = 5;

    [Header("Script Links")]
    public NetworkMonitor m_NetworkMonitor;
    public TargetZone m_TargetZone;
    public SelectionBox m_SelectionBox;
    public Rigidbody m_RigidBody;

    public Transform m_CameraAttachPoint;
    public Transform m_StaticControlSystem;
    public GameObject m_LaunchPoint;
    public Transform m_EffectorTargetPoint;
    public EntityTrail m_EntityTrail;
    public Transform m_AirCommPoint;
    public Transform m_WaterCommPoint;
    public GameObject m_labelPosition;
    public Transform m_MineLaunchPoint;

    //

    [Header("Timers")]
    public float m_CurrentWorldTime;
    public float m_CurrentSimTime;
    public float m_TimeOfLastMessage;
    public float m_TimeOfLastDestinationChange;
    public float m_TimeSinceLastDestinationChange;
    public float m_TimeOfLastRotationChange;
    public float m_TimeOfSinceLastRotationChange;

    public float m_TimeSinceFirstMessageReceived;
    public float m_TimeSinceLastMessageReceived;
    public float m_TimeSinceLastFrame;

    [Header("Options and Buttons")]
    public bool m_DrawLines;
    public float m_LineDuration = 600;
    public bool m_RunOnFixedUpdate;
    public float m_NumSecondsToAverage = 1.0f;
    public float m_ArrivedAtFinalPositionTolerance = 0.05f;
    public float m_ArrivedAtFinalRotationTolerance = 0.05f;
    public float m_DistanceDifferencetoIgnore = 10.0f;
    public float m_RotationMultiplier = 0.5f;

    public XSIMUpdateMessage m_PreviousXSIMUpdate;
    public SimUpdate m_CurrentSimUpdate;
    SimUpdate m_PreviousSimUpdate;

    public List<SimUpdate> m_EntityUpdates = new List<SimUpdate>();
    public int m_NumberOfEntityUpdates;
    public List<SimUpdate> m_UpdatesToRemove = new List<SimUpdate>();

    public float m_TimeSinceMessageReceived;
    public Vector3 m_LerpedPosition;
    public float m_PCT;
    public float m_TimePreviousMessageReceived;
    public float m_TimeLastMessageReceived;

    public Vector3 m_CurrentXYZDestination;
    public Vector3 m_PreviousXYZDestination;
    public Vector3 m_CurrentXYZRotationTarget;
    public Vector3 m_PreviousXYZRotationTarget;
    public Quaternion m_CurrentQRotationTarget;
    public Quaternion m_PreviousQRotationTarget;
    public float m_DistanceToCurrentDestination;
    public Vector3 m_LookVector;

    public Quaternion m_RotationTowardsDestination;

    public bool m_PositionUpdatesStarted;
    public bool m_AcceptNewUpdates = true;

    public bool m_VisibleInScene = true;
    public bool m_PreviousVisibleInScene;

    public Vector3 m_EntityUpdatesZeroDest;
    public EntityState m_EntityUpdatesZeroState;

    public bool m_CommsActive;
    public bool m_AirCommsReady;
    public bool m_WaterCommsReady;

    public bool m_PerformingAnimation = false;
    public bool m_AnimationMode = false;

    public int m_HullnumbersFound = 0;
    public List<HullNumberSlot> m_HullNumberSlots = new List<HullNumberSlot>();
    public bool m_ApplyHullNumbers;

    public Transform m_Transform;
    public Entity m_ParentEntity;
    public Entity m_Host;

    public bool m_IsInView = false;

    public bool m_IsSelected = false;

    public bool m_WaypointsStarted = false;

    public List<ContextMenuItem> m_ContextMenuItems;     // list of items in menu

    public bool m_Paused = false;
    public float m_TimeToPause = 0;
    public float m_PausedTimer = 0;

    public bool m_HasSensors;
    public bool m_SensorsActive;
    public bool m_SensorsVisible;
    public List<GameObject> m_Sensors = new List<GameObject>();

    public GameObject m_AttachedEntitiesMarker;
    public List<Entity> m_AttachedEntities = new List<Entity>();

    public float m_ScriptControllerTurningSpeed = 15;
    public float m_ScriptControllerRiseSpeed = 15;
    public float m_ScriptControllerForwardSpeed = 10;

    public WaypointModule m_WaypointModule;

    public Transform m_AirVehicleAttachPoint;
    public Transform m_AirVehicleLoadingPoint;
    public Transform m_SurfaceVehicleAttachPoint;
    public Transform m_SurfaceVehicleLoadingPoint;
    public Transform m_WeaponAttachPoint;

    public Entity m_Target;
    public float m_DistanceToStopFromTarget;
    //public Material m_LineMaterial;

    public bool m_WasStopped;

    public contactUpdate m_SerializedEntityUpdate;
    public bool m_SerializationCreated;

    public List<GameObject> m_Loadouts;
    public int m_CurrentLoadout;
    public Entity m_ActiveSystem;
    public Sensor m_ActiveSensor;

    public Transform m_MineBase;
    public bool m_IsLaunchSystem;

    public float m_TargetHeight;

    public bool m_IsFollowingAnotherEntity;
    public bool m_IsBeingFollowed;
    public Vector3 m_FollowerOffsetVector;
    public float m_FollowSpeed;

    public bool m_Detected;
    public Dictionary<Renderer, Material> m_OriginalMaterials = new Dictionary<Renderer, Material>();

    public bool m_IsLocked;
    public Transform m_SystemLaunchPoint;

    public bool m_WasInactive;

    public int m_TargetID = -1;
    public float m_DistanceToTargetID;

    // Temp

    public bool m_TempChanged;
    public bool m_TempBoolOnce;
    public List<Vector3> m_CollisionPoints;

    public Weapon m_Weapon;

    public enum DepthMode
    {
        ALTITUDE = 0,
        DEPTH
    };

    public DepthMode m_DepthMode;

    public virtual bool getInitialized()
    {
        return m_EntityInitialized;
    }

    public bool StartEntityClass()
    {
        m_EntityInitialized = false;
        m_EntityStarted = true;

        InitializeEntityClass();

        if (m_EntityInitialized)
        {
            //Debug.Log("[Entity] " + gameObject.name + " Initialized successfully.");
        }
        else
        {
            Debug.Log("[Entity] " + gameObject.name + " Failed to initialize.");
        }

        if (m_WaypointModule == null)
        {
            if (m_ControlObjects.HasControlObject("WaypointModule"))
            {
                m_WaypointModule = m_ControlObjects.GetControlObject("WaypointModule").GetComponent<WaypointModule>();
            }
        }

        if (m_WaypointModule == null)
        {
            GameObject l_Object = new GameObject("WaypointModule");
            l_Object.transform.SetParent(m_ControlObjects.transform);
            l_Object.transform.position = transform.position;
            WaypointModule l_WaypointModule = l_Object.AddComponent<WaypointModule>();

            m_ControlObjects.AddControlObject("WaypointModule", l_Object);
            m_WaypointModule = l_WaypointModule;
        }

        if (m_WaypointModule != null)
        {
            m_WaypointModule.m_Controller = this;
            m_WaypointModule.Initialize();

            SimulatorSettings.getEntityList().GetWaypoints(m_EntityID);
        }

        m_Loadouts = new List<GameObject>();
        m_MaxSpeed = m_OriginalMaxSpeed;
        return m_EntityInitialized;
    }

    public virtual bool ExternalStart()
    {
        return StartEntityClass();
    }

    public bool InitializationChecks()
    {
        if (!SimulatorSettings.getInitialized())
        {
            Debug.Log("[ERROR] --> [Entity] " + gameObject.name + "(ID: " + m_EntityID + " - SMMTTID: " + m_EntitySMMTTID + ") Entity was unable to initialize due to the SimCORE not having finished initialization.");
            return false;
        }
        if (!gameObject.activeSelf)
        {
            m_WasInactive = true;
            SetActive(true);
            Debug.Log("[ERROR] --> [Entity] " + gameObject.name + "(ID: " + m_EntityID + " - SMMTTID: " + m_EntitySMMTTID + ") Entity was unable to initialize due to the fact the gameobject has been disabled.");
            //return false;
        }
        if (!m_EntityStarted)
        {
            Debug.Log("[ERROR] --> [Entity] " + gameObject.name + "(ID: " + m_EntityID + " - SMMTTID: " + m_EntitySMMTTID + ") Entity was unable to initialize due to the fact it hasn't received the signal to start yet.");
            return false;
        }

        if (!m_IsSavedPrefab)
        {
            if (!SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID).Valid)
            {
                Debug.Log("[ERROR] --> [Entity] " + gameObject.name + "(ID: " + m_EntityID + " - SMMTTID: " + m_EntitySMMTTID + ") Entity was unable to initialize due to an invalid SMMTTID.");
                return false;
            }
        }

        return true;
    }

    public void Pause()
    {
        if (m_Paused)
        {
            Pause(false);
        }
        else
        {
            m_EntityState = EntityState.PAUSED;
            Pause(true);
        }
    }

    public void Pause(bool a_Bool)
    {
        if (a_Bool)
        {
            m_EntityState = EntityState.PAUSED;
            m_CurrentSpeed = 0;
            m_Paused = true;
            m_TimeToPause = -1; // Pause until told otherwise
            if (!m_RigidBody.isKinematic) m_RigidBody.isKinematic = true;
        }
        else
        {
            m_Paused = false;
        }
    }

    public void Pause(int a_Time)
    {
        Pause((float)a_Time);
    }

    public void Pause(float a_Time)
    {
        m_EntityState = EntityState.PAUSED;

        m_Paused = true;
        m_PausedTimer = 0;
        m_TimeToPause = a_Time;
    }

    public void Unpause()
    {
        m_Paused = false;
    }

    public bool InitializeEntityClass()
    {
        m_TimesAttemptedInitialization++;

        if (!InitializationChecks())
        {
            return false;
        }

        // Entities have two different methods of initialization, New and Prefab.
        // -New means creating a new entity with entirely default value based on the model type (SMMTTID).
        // -Prefab means the entity is a version of an entity that has been created and saved off previous, which contains unique values and settings

        //if(SimulatorSettings.getEntityList().containsID(m_EntityID))
        //{
        //    m_EntityID = SimulatorSettings.getEntityList().getNextAvailableID(m_EntityID);
        //}

        if (!m_IsSavedPrefab)
        {
            CreateNewEntity();

            m_ModelInformation_Initialized = false;
            getModelInformation();
        }
        else
        {
            UpdatePrefabEntity();
        }

        if (!LinkAndStartControlObjects())
        {
            Debug.Log("[ERROR] --> [Entity]" + gameObject.name + ": Was unable to find/create its control objects. Initialization aborted.");
            m_EntityStarted = false;
            SetActive(false);
            return false;
        }

        if (!m_IsSavedPrefab)
        {
            resizeModel();

            if (m_IsTarget)
            {
                resizeCollisionDetectionBox();
            }
        }

        if (m_UIManager == null)
        {
            m_UIManager = SimulatorSettings.getUIManager();
        }

        // Start GPS

        m_PositionData_Initialized = false;
        startPositionData();

        // Set Initial Values

        m_SpeedOverride = 0;

        m_SinkingSpeed = SimulatorSettings.getAnimationManager().getSinkingspeed();

        m_NetworkVehicleHasBeenPlaced = false;
        m_HasSmoke = false;
        m_AirCommsReady = false;
        m_WaterCommsReady = false;

        m_RigidBody.mass = m_EntityMassInTons;

        m_OriginalMass = m_EntityMassInTons;
        m_OriginalRotation = gameObject.transform.rotation;
        m_OriginalHullPoints = m_TotalHullPoints;
        m_OriginalState = m_EntityState;

        m_CurrentHullPoints = m_TotalHullPoints;

        m_EntityState = EntityState.DEFAULT_POSUPDATE;
        m_PreviousEntityState = m_EntityState;

        m_NumberOfEntitiesBroadcastingTo = 0;
        m_NumberOfEntitiesReceivingFrom = 0;

        m_EntityUpdates = new List<SimUpdate>();
        m_UpdatesToRemove = new List<SimUpdate>();

        //m_GPSWaypoints = new List<Vector2>();

        // Prepare for Network Updates

        m_PositionUpdatesStarted = false;

        if (Application.isPlaying)
        {
            m_TimeSinceFirstMessageReceived = (float)m_NetworkMonitor.GetNSITime();
        }
        else
        {
            m_TimeSinceFirstMessageReceived = 0;
        }

        // Grab Pointer to Particle Systems

        GameObject l_ParticleSystems = m_ControlObjects.GetControlObject("ParticleSystems");

        m_ArrivedAtFinalPositionTolerance = 0.05f;

        if (l_ParticleSystems)
        {
            m_ParticleList.Clear();
            int i = 0;

            foreach (ParticleSystem l_Particle in l_ParticleSystems.transform.GetComponentsInChildren<ParticleSystem>())
            {
                //Debug.Log("Particle System Detected: " + l_Particle);
                m_ParticleList.Add(i + "_" + l_Particle.gameObject.name, l_Particle);
            }

            m_ParticleListSize = m_ParticleList.Count;
        }

        m_EntityIsSinking = false;
        m_EntitySunkToTheBottom = false;

        ApplyHullNumbers();

        setVisibleInScene(m_VisibleInScene);

        CreateContextMenu();

        if (m_XSIMID == -1)
        {
            m_XSIMID = m_EntityID;
        }

        if (m_AttachedEntitiesMarker)
        {
            m_AttachedEntities = new List<Entity>(m_AttachedEntitiesMarker.transform.GetComponentsInChildren<Entity>());
        }

        m_EntityInitialized = true;

        if (m_UseExternalPhysics)
        {
            m_RigidBody.useGravity = false;
            m_RigidBody.isKinematic = true;
        }

        if (!m_MineLaunchPoint)
        {
            if (m_ControlObjects.HasControlObject("MineLaunchPoint"))
            {
                m_MineLaunchPoint = m_ControlObjects.GetControlObject("MineLaunchPoint").transform;
            }
        }

        if (!m_MineLaunchPoint)
        {
            GameObject l_MineLaunchPoint = new GameObject("MineLaunchPoint");
            l_MineLaunchPoint.transform.SetParent(m_ControlObjects.transform);
            l_MineLaunchPoint.transform.localPosition = new Vector3(0, 0, -m_ModelBounds.extents.z + 1);

            m_MineLaunchPoint = l_MineLaunchPoint.transform;
        }

        if (Application.isPlaying)
        {
            m_OriginalMaterials.Clear();
            foreach (Renderer l_Rend in m_ModelLoader.GetComponentsInChildren<Renderer>())
            {
                m_OriginalMaterials.Add(l_Rend, l_Rend.material);
            }

            CreateSerialization();
        }

        if (m_WasInactive)
        {
            SetActive(false);
        }

        return m_EntityInitialized;
    }

    void CreateNewEntity()
    {
        m_RigidBody.useGravity = false;
        m_RigidBody.isKinematic = true;

        CreateEntityStructure();
    }

    void UpdatePrefabEntity()
    {

    }

    void CreateEntityStructure()
    {
        GameObject l_SearchItem;

        m_RigidBody = gameObject.GetComponent<Rigidbody>();

        if (!m_RigidBody)
        {
            m_RigidBody = gameObject.AddComponent<Rigidbody>();
        }

        //

        m_StaticControlSystem = gameObject.transform.Find("Static Control System");

        if (!m_StaticControlSystem)
        {
            m_StaticControlSystem = new GameObject("Static Control System").transform;
            m_StaticControlSystem.transform.SetParent(gameObject.transform);
            m_StaticControlSystem.transform.localPosition = Vector3.zero;
        }

        //

        m_ModelLoader = m_StaticControlSystem.GetComponentInChildren<ModelLoader>();

        if (!m_ModelLoader)
        {
            GameObject l_ModelLoader = new GameObject("ModelLoader");
            l_ModelLoader.transform.SetParent(m_StaticControlSystem);
            l_ModelLoader.transform.localPosition = Vector3.zero;

            m_ModelLoader = l_ModelLoader.AddComponent<ModelLoader>();
        }

        //

        m_ControlObjects = m_StaticControlSystem.GetComponentInChildren<EntityControlObjects>();

        if (!m_ControlObjects)
        {
            GameObject l_ControlObjects = new GameObject("ControlObjects");
            l_ControlObjects.transform.SetParent(m_StaticControlSystem);
            l_ControlObjects.transform.localPosition = Vector3.zero;

            m_ControlObjects = l_ControlObjects.AddComponent<EntityControlObjects>();
        }

        m_ControlObjects.GetControlObjects();

        //

        l_SearchItem = m_ControlObjects.GetControlObject("CenterOfMass");

        if (!l_SearchItem)
        {
            m_CenterOfMass = new GameObject("CenterOfMass").transform;
            m_CenterOfMass.transform.SetParent(m_ControlObjects.transform);
            m_CenterOfMass.transform.localPosition = Vector3.zero;
        }
        else
        {
            m_CenterOfMass = l_SearchItem.transform;
        }
    }

    MeshRenderer GetHullNumberSlot(int a_Digit, HullSide a_Side)
    {
        MeshRenderer l_Ret = null;

        foreach (HullNumberSlot l_HullNumberSlot in m_HullNumberSlots)
        {
            if ((l_HullNumberSlot.DigitNumber == a_Digit) && (l_HullNumberSlot.HullSide == a_Side))
            {
                return l_HullNumberSlot.MeshRenderer;
            }
        }

        return l_Ret;
    }

    void ApplyHullNumbers()
    {
        if (m_ApplyHullNumbers)
        {

            m_HullNumberSlots.Clear();
            foreach (Transform l_Child in m_ModelLoader.m_Model.transform)
            {
                if (l_Child.gameObject.name.Contains("HULLNUMBER"))
                {
                    //Debug.Log("Found hullnumber renderer: " + l_Child.gameObject.name);
                    string[] l_Tokens = l_Child.gameObject.name.Split('_');


                    if (l_Tokens.Length > 0)
                    {
                        int l_Number = Common.parseStringToInt(l_Tokens[l_Tokens.Length - 1]);

                        if (l_Number >= 0)
                        {
                            HullNumberSlot l_NewSlot = new HullNumberSlot();
                            l_NewSlot.DigitNumber = l_Number;
                            l_NewSlot.MeshRenderer = l_Child.GetComponent<MeshRenderer>();

                            if (l_Tokens[0].Equals("LEFT"))
                            {
                                l_NewSlot.HullSide = HullSide.LEFT;
                            }
                            else if (l_Tokens[0].Equals("RIGHT"))
                            {
                                l_NewSlot.HullSide = HullSide.RIGHT;
                            }
                            else
                            {
                                continue;
                            }

                            if (l_NewSlot.MeshRenderer)
                            {
                                m_HullNumberSlots.Add(l_NewSlot);
                            }
                        }
                    }
                }
            }
            List<int> digits = new List<int>();
            string l_IDString = m_EntityID.ToString();

            for (int i = 0; i < l_IDString.Length; i++)
            {
                digits.Add(Common.parseStringToInt(l_IDString.Substring(i, 1)));
            }

            if (digits.Count == 1)
            {
                int l_CurrentDigit = digits[0];

                MeshRenderer l_RightRender = GetHullNumberSlot(0, HullSide.RIGHT);
                MeshRenderer l_LeftRender = GetHullNumberSlot(3, HullSide.LEFT);

                Material l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(1, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(2, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(2, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(1, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(3, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(0, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;
            }

            if (digits.Count == 2)
            {
                int l_CurrentDigit = digits[0];

                MeshRenderer l_RightRender = GetHullNumberSlot(0, HullSide.RIGHT);
                MeshRenderer l_LeftRender = GetHullNumberSlot(2, HullSide.LEFT);

                Material l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[1];

                l_RightRender = GetHullNumberSlot(1, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(3, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(2, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(1, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(3, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(0, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;
            }

            if (digits.Count == 3)
            {
                int l_CurrentDigit = digits[0];

                MeshRenderer l_RightRender = GetHullNumberSlot(0, HullSide.RIGHT);
                MeshRenderer l_LeftRender = GetHullNumberSlot(1, HullSide.LEFT);

                Material l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[1];

                l_RightRender = GetHullNumberSlot(1, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(2, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[2];

                l_RightRender = GetHullNumberSlot(2, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(3, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = -1;

                l_RightRender = GetHullNumberSlot(3, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(0, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;
            }

            if (digits.Count == 4)
            {
                int l_CurrentDigit = digits[0];

                MeshRenderer l_RightRender = GetHullNumberSlot(0, HullSide.RIGHT);
                MeshRenderer l_LeftRender = GetHullNumberSlot(0, HullSide.LEFT);

                Material l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[1];

                l_RightRender = GetHullNumberSlot(1, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(1, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[2];

                l_RightRender = GetHullNumberSlot(2, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(2, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;

                l_CurrentDigit = digits[3];

                l_RightRender = GetHullNumberSlot(3, HullSide.RIGHT);
                l_LeftRender = GetHullNumberSlot(3, HullSide.LEFT);

                l_NewMaterial = SimulatorSettings.getAnimationManager().GetHullNumberMaterial(l_CurrentDigit);

                if (l_RightRender) l_RightRender.material = l_NewMaterial;
                if (l_LeftRender) l_LeftRender.material = l_NewMaterial;
            }

        }

    }

    void setLabelPosition()
    {
        if (m_ControlObjects != null)
        {
            if (m_ControlObjects.GetControlObject("LabelPosition") != null)
            {
                m_labelPosition = m_ControlObjects.GetControlObject("LabelPosition");
            }
            else if (m_ModelInformation_Initialized)
            {
                if (m_labelPosition == null)
                {
                    GameObject l_NewLabelPosition = new GameObject();

                    l_NewLabelPosition.name = "LabelPosition";
                    l_NewLabelPosition.transform.SetParent(m_ControlObjects.transform);
                    l_NewLabelPosition.transform.localPosition = new Vector3(0, m_ModelBounds.extents.y, 0);

                    m_labelPosition = l_NewLabelPosition;
                }
                else
                {
                    m_labelPosition.name = "LabelPosition";

                    m_labelPosition.transform.position = new Vector3(m_ModelBounds.center.x, m_ModelBounds.center.y + m_ModelBounds.extents.y + 1, m_ModelBounds.center.z);
                }
            }
        }
    }

    void AbortExecution(string a_MethodName)
    {
        Debug.Log("[ERROR] --> [Entity] " + gameObject.name + ": Execution aborted at Method: " + a_MethodName);
    }

    bool DebugErrorMissingLink(string a_ObjectName)
    {
        Debug.Log("[ERROR] --> [Entity] " + gameObject.name + ": Could not locate object: " + a_ObjectName);

        return false;
    }

    bool LinkAndStartControlObjects()
    {
        if (m_Transform == null)
        {
            m_Transform = gameObject.transform;
        }

        if (m_RigidBody == null)
        {
            m_RigidBody = gameObject.GetComponent<Rigidbody>();
        }
        if (m_RigidBody == null) return DebugErrorMissingLink(m_RigidBody.GetType().ToString());

        //

        if (m_StaticControlSystem == null)
        {
            m_StaticControlSystem = transform.Find("Static Control System");
        }
        if (m_StaticControlSystem == null) return DebugErrorMissingLink(m_StaticControlSystem.GetType().ToString());

        //

        if (m_NetworkMonitor == null)
        {
            m_NetworkMonitor = SimulatorSettings.getNetworkMonitor();
        }
        if (m_NetworkMonitor == null) return DebugErrorMissingLink(m_NetworkMonitor.GetType().ToString());

        //

        if (m_ModelLoader == null)
        {
            m_ModelLoader = gameObject.GetComponentInChildren<ModelLoader>();
        }
        if (m_ModelLoader == null) return DebugErrorMissingLink(m_ModelLoader.GetType().ToString());

        //

        if (SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID).Valid)
        {
            m_ModelRotation = SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID).Rotation;
        }

        m_ModelLoader.m_ModelName = m_EntityModelName;
        m_ModelLoader.m_Controller = this;
        m_ModelLoader.m_ModelRotation = m_ModelRotation;
        m_ModelLoader.ExternalStart();

        if (m_ControlObjects == null)
        {
            m_ControlObjects = gameObject.GetComponentInChildren<EntityControlObjects>();
        }

        if (m_ControlObjects == null) return false;

        m_ControlObjects.ExternalStart();

        m_ModelBounds = m_ModelLoader.getModelBounds();

        if (m_CameraAttachPoint == null)
        {
            //Debug.Log("m_CameraAttachPoint == null");
            getCameraAttachPoint();
        }
        //else Debug.Log("m_CameraAttachPoint != null : Pos - " + m_CameraAttachPoint.transform.localPosition);

        if (m_AirVehicleAttachPoint == null)
        {
            if (m_ControlObjects.ContainsControlObject("AirVehicleAttachPoint"))
            {
                m_AirVehicleAttachPoint = m_ControlObjects.GetControlObject("AirVehicleAttachPoint").transform;
            }
            else
            {
                m_AirVehicleAttachPoint = new GameObject("AirVehicleAttachPoint").transform;
                m_AirVehicleAttachPoint.transform.SetParent(m_ControlObjects.transform);
                m_AirVehicleAttachPoint.transform.position = transform.position;
                m_ControlObjects.AddControlObject("AirVehicleAttachPoint", m_AirVehicleAttachPoint.gameObject);
            }
        }

        if (m_AirVehicleLoadingPoint == null)
        {
            if (m_ControlObjects.ContainsControlObject("AirVehicleLoadingPoint"))
            {
                m_AirVehicleLoadingPoint = m_ControlObjects.GetControlObject("AirVehicleLoadingPoint").transform;
            }
            else
            {
                m_AirVehicleLoadingPoint = new GameObject("AirVehicleLoadingPoint").transform;
                m_AirVehicleLoadingPoint.transform.SetParent(m_ControlObjects.transform);
                m_AirVehicleLoadingPoint.transform.position = m_AirVehicleAttachPoint.position;
                m_ControlObjects.AddControlObject("AirVehicleLoadingPoint", m_AirVehicleLoadingPoint.gameObject);
            }
        }

        if (m_SurfaceVehicleAttachPoint == null)
        {
            if (m_ControlObjects.ContainsControlObject("SurfaceVehicleAttachPoint"))
            {
                m_SurfaceVehicleAttachPoint = m_ControlObjects.GetControlObject("SurfaceVehicleAttachPoint").transform;
            }
            else
            {
                m_SurfaceVehicleAttachPoint = new GameObject("SurfaceVehicleAttachPoint").transform;
                m_SurfaceVehicleAttachPoint.transform.SetParent(m_ControlObjects.transform);
                m_SurfaceVehicleAttachPoint.transform.position = transform.position;
                m_ControlObjects.AddControlObject("SurfaceVehicleAttachPoint", m_SurfaceVehicleAttachPoint.gameObject);
            }
        }

        if (m_SurfaceVehicleLoadingPoint == null)
        {
            if (m_ControlObjects.ContainsControlObject("SurfaceVehicleLoadingPoint"))
            {
                m_SurfaceVehicleLoadingPoint = m_ControlObjects.GetControlObject("SurfaceVehicleLoadingPoint").transform;
            }
            else
            {
                m_SurfaceVehicleLoadingPoint = new GameObject("SurfaceVehicleLoadingPoint").transform;
                m_SurfaceVehicleLoadingPoint.transform.SetParent(m_ControlObjects.transform);
                m_SurfaceVehicleLoadingPoint.transform.position = m_SurfaceVehicleAttachPoint.position;
                m_ControlObjects.AddControlObject("SurfaceVehicleLoadingPoint", m_SurfaceVehicleLoadingPoint.gameObject);
            }
        }

        if (m_TargetZone == null)
        {
            GameObject l_Target = m_ControlObjects.GetControlObject("TargetZone");

            if (l_Target == null) // If the previous search didn't find anything
            {
                GameObject l_TargetZoneObject = new GameObject("Target Zone");
                l_TargetZoneObject.layer = LayerMask.NameToLayer("ColliderDetection");
                l_TargetZoneObject.transform.parent = m_ControlObjects.transform;

                m_TargetZone = l_TargetZoneObject.AddComponent<TargetZone>();
                m_ControlObjects.AddControlObject("TargetZone", m_TargetZone.gameObject);
            }
            else
            {
                m_TargetZone = m_ControlObjects.GetControlObject("TargetZone").GetComponent<TargetZone>();
            }
        }

        m_TargetZone.m_Controller = this;
        m_TargetZone.m_ModelLoader = m_ModelLoader;
        m_TargetZone.ExternalStart();

        if (m_SelectionBox == null)
        {
            GameObject l_Target = m_ControlObjects.GetControlObject("SelectionBox");

            if (l_Target == null) // If the previous search didn't find anything
            {
                GameObject l_SelectionBoxObject = new GameObject("SelectionBox");
                l_SelectionBoxObject.layer = LayerMask.NameToLayer("RaycastTarget");
                l_SelectionBoxObject.transform.parent = m_ControlObjects.transform;

                m_SelectionBox = l_SelectionBoxObject.AddComponent<SelectionBox>();
                m_ControlObjects.AddControlObject("SelectionBox", l_SelectionBoxObject);
            }
            else
            {
                m_SelectionBox = m_ControlObjects.GetControlObject("SelectionBox").GetComponent<SelectionBox>();
            }
        }

        m_SelectionBox.m_Controller = this;
        m_SelectionBox.m_ModelLoader = m_ModelLoader;
        m_SelectionBox.ExternalStart();

        if (m_LaunchPoint == null)
        {
            AddEffectorLaunchPoint();
        }

        if (m_EffectorTargetPoint == null)
        {
            AddEffectorTargetPoint();
        }

        if (m_UsesEntityTrail && m_IsMovableObject)
        {
            if (m_EntityID != 0)
            {
                if (m_EntityTrail == null)
                {
                    if (m_ControlObjects.GetControlObject("EntityTrail") == null)
                    {
                        GameObject l_EntityTrail = new GameObject("EntityTrail");
                        l_EntityTrail.transform.parent = m_ControlObjects.transform;
                        m_EntityTrail = l_EntityTrail.AddComponent<EntityTrail>();
                    }
                    else
                    {
                        m_EntityTrail = m_ControlObjects.GetControlObject("EntityTrail").GetComponent<EntityTrail>();
                    }

                }

                m_EntityTrail.transform.localPosition = Vector3.zero; //new Vector3(0, m_ModelBounds.extents.y / 2, 0);
                m_EntityTrail.ExternalStart();
            }
            else
            {
                if (m_EntityTrail != null)
                {
                    m_EntityTrail.gameObject.SetActive(false);
                }
            }
        }

        setLabelPosition();

        return true;

    }

    bool getModelInformation()
    {
        bool l_Ret = false;

        if (!m_IsSavedPrefab)
        {
            ModelInformation l_ModelInfo = SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID);
            if (l_ModelInfo.Valid)
            {
                //Debug.Log("     [Entity]" + gameObject.name + " is an entity of type: " + l_ModelInfo.Type);

                if (m_EntityName.Equals(""))
                {
                    m_EntityName = l_ModelInfo.ModelName;
                }
                if (m_EntityType.Equals(""))
                {
                    m_EntityType = l_ModelInfo.Type;
                }
                if (m_EntityLengthInMeters == 0)
                {
                    m_EntityLengthInMeters = l_ModelInfo.Length;
                }
                if (m_EntityMassInTons == 0)
                {
                    m_EntityMassInTons = l_ModelInfo.Mass;
                }

                m_ModelInformation_Initialized = true;
                l_Ret = true;
            }
            else
            {
                Debug.Log("[ERROR] --> [Entity]" + gameObject.name + " 's SMMTTID of " + m_EntitySMMTTID + " was not found in the ModelManager");
            }
        }
        else
        {
            m_ModelInformation_Initialized = true;

            l_Ret = true;
        }

        if (!l_Ret) AbortExecution(MethodBase.GetCurrentMethod().Name);

        return l_Ret;
    }

    public void resizeModel()
    {

        if (m_ModelLoader != null)
        {
            m_ModelBounds = m_ModelLoader.getModelBounds();
        }

        m_ModelLoader.resizeModel();
    }

    public void resizeCollisionDetectionBox()
    {
        m_TargetZone.createModelBoxCollider();
    }

    bool startPositionData()
    {
        //Debug.Log("Entity: " + m_EntityName + " Pos: " + currentGPSPosition);

        if (m_ParentEntity)
        {
            Debug.Log(" - Has Parent: " + m_ParentEntity);
        }

        if (m_ParentEntity == null)
        {

            if (Vector3.Distance(currentGPSPosition, Vector3.zero) < 5)
            {
                currentGPSPosition = GPSEncoder.getLocalOrigin();
            }

            Vector3 l_Temp = GPSEncoder.GPSToUCS(currentGPSPosition);
            l_Temp.y = gameObject.transform.position.y;
            gameObject.transform.position = l_Temp;
        }

        currentXYZPosition = gameObject.transform.position;

        previousXYZPosition = currentXYZPosition;
        previousGPSPosition = currentGPSPosition;

        m_OriginalPosition = currentXYZPosition;

        m_Elevation = currentXYZPosition.y;

        m_PositionData_Initialized = true;

        //Debug.Log("Entity: " + m_EntityName + " Pos: " + currentGPSPosition);

        return true;
    }

    Vector2 getXZPosition()
    {
        Vector2 position = new Vector2(gameObject.transform.position.x, gameObject.transform.position.z);
        return position;
    }

    public void Update_EntityClass()
    {
        if (m_Paused)
        {
            if (m_TimeToPause > 0)
            {
                m_PausedTimer += Time.deltaTime;

                if (m_PausedTimer > m_TimeToPause)
                {
                    m_Paused = false;
                }
            }
        }

        if (m_EntityInitialized)
        {
            UpdateOptions();

            if (Application.isPlaying)
            {
                UpdateAnimations();
                UpdatePosition();
            }

            m_HullnumbersFound = m_HullNumberSlots.Count;

            updateVehicleInformation();

            if (m_PositionData_Initialized) updatePositionData();
            else startPositionData();

            if (m_VisibleInScene != m_PreviousVisibleInScene)
            {
                setVisibleInScene(m_VisibleInScene);
            }
        }
    }

    void CreateSerialization()
    {
        m_SerializedEntityUpdate = new contactUpdate();
        m_SerializedEntityUpdate.ID = m_EntityID;
        m_SerializedEntityUpdate.seciID = m_XSIMID;
        m_SerializedEntityUpdate.smmttid = m_EntitySMMTTID;

        if (m_UseExternalPhysics) m_SerializedEntityUpdate.useExternalPhysics = 1;
        else m_SerializedEntityUpdate.useExternalPhysics = 0;

        UpdateSerialization();

        m_SerializationCreated = true;
    }

    void UpdateSerialization()
    {
        m_SerializedEntityUpdate.state = (int)m_EntityState;
        m_SerializedEntityUpdate.statusFlag = (char)m_StatusFlag;

        m_SerializedEntityUpdate.lat = currentGPSPosition.x;
        m_SerializedEntityUpdate.lon = currentGPSPosition.y;
        m_SerializedEntityUpdate.altitude = m_CurrentAltitude;

        m_SerializedEntityUpdate.heading = m_CurrentHeading;
        m_SerializedEntityUpdate.pitch = m_CurrentPitch;
        m_SerializedEntityUpdate.roll = m_CurrentRoll;
    }

    void UpdateAnimations()
    {
        m_NumberOfEntitiesBroadcastingTo = m_EntitiesBroadcastingTo.Count;
        m_NumberOfEntitiesReceivingFrom = m_EntitiesReceivingFrom.Count;

        if (m_IsFollowingAnotherEntity)
        {
            if (m_LVerticalInput != 0)
            {
                if (m_LVerticalInput > 0)
                {
                    m_FollowerOffsetVector += transform.forward * Time.deltaTime * (m_MaxSpeed / 2);
                }
                else if (m_LVerticalInput < 0)
                {
                    m_FollowerOffsetVector -= transform.forward * Time.deltaTime * (m_MaxSpeed / 2);
                }
            }

            if (m_LHorizontalInput != 0)
            {
                if (m_LHorizontalInput > 0)
                {
                    m_FollowerOffsetVector += transform.right * Time.deltaTime * (m_MaxSpeed / 2);
                }
                else if (m_LHorizontalInput < 0)
                {
                    m_FollowerOffsetVector -= transform.right * Time.deltaTime * (m_MaxSpeed / 2);
                }
            }

            if (m_InputAltitude != 0)
            {
                if (m_InputAltitude > 0)
                {
                    m_FollowerOffsetVector += transform.up * Time.deltaTime * (m_MaxSpeed / 2);
                }
                else if (m_InputAltitude < 0)
                {
                    m_FollowerOffsetVector -= transform.up * Time.deltaTime * (m_MaxSpeed / 2);
                }
            }
        }
    }

    public void UpdatePosition()
    {
        switch (m_ControlType)
        {
            case EntityControlType.PLAYER:
                UpdatePosition_Player();
                break;
            case EntityControlType.SCRIPT:
                UpdatePosition_Script();
                break;
            case EntityControlType.NETWORK:
                UpdatePosition_Network();
                break;
            case EntityControlType.WAYPOINT:
                UpdatePosition_Waypoint();
                break;
            default:
                break;
        }
    }

    public virtual void UpdatePosition_Player()
    {

    }

    public virtual void UpdatePosition_Script()
    {

    }

    public virtual void UpdatePosition_Waypoint()
    {
        UpdatePosition_Network();
    }

    void UpdateNetworkTimers()
    {
        m_CurrentWorldTime = (float)m_NetworkMonitor.GetNSITime();

        if (m_EntityUpdates != null)
        {
            m_NumberOfEntityUpdates = m_EntityUpdates.Count;
        }
    }

    void InitialPositioningLoop()
    {
        if (m_EntityUpdates.Count > 1)
        {
            //Debug.Log("Entity Updates: " + m_EntityUpdates[0].GPS.lat + " - " + m_EntityUpdates[0].GPS.lon);

            m_PreviousSimUpdate = m_EntityUpdates[0];
            m_PreviousXYZDestination = transform.position;
            m_CurrentXYZDestination = GPSEncoder.DGPSToUCS(m_EntityUpdates[1].GPS.lat, m_EntityUpdates[1].GPS.lon);


            if (m_EnableElevationUpdates)
            {
                m_CurrentXYZDestination.y = Mathf.Lerp(transform.position.y, m_DesiredAltitude, m_ElevationChangeSpeed);
            }

            m_LookVector = (m_CurrentXYZDestination - m_PreviousXYZDestination).normalized;
            if (m_LookVector == Vector3.zero)
            {
                //Debug.Log(m_EntityName + " Initial Position Loop - Look Vector is zero" );
                m_PositionUpdatesStarted = false;
                return;
            }
            else
            {
                //Debug.Log(m_EntityName + " Initial Position Loop - Look Vector is not zero");
                m_RotationTowardsDestination = Quaternion.LookRotation(m_LookVector);
                SetRotation(Quaternion.Euler(transform.rotation.eulerAngles.x, m_RotationTowardsDestination.eulerAngles.y, transform.rotation.eulerAngles.z));
                m_DesiredHeading = m_RotationTowardsDestination.eulerAngles.y;

                m_OriginalRotation = transform.rotation;
                //Debug.Log("Prev: " + m_PreviousXYZDestination + " - Next: " + m_CurrentXYZDestination + " = " + (m_CurrentXYZDestination - m_PreviousXYZDestination) + " " + (m_CurrentXYZDestination - m_PreviousXYZDestination).normalized);
                //Debug.Log("Rotation was set to desired heading: " + m_DesiredHeading);
                m_PreviousXYZRotationTarget = new Vector3(0, m_DesiredHeading, 0);
                m_CurrentXYZRotationTarget = m_PreviousXYZRotationTarget;

                m_TimeOfLastDestinationChange = m_CurrentWorldTime;
                m_TimeSinceLastDestinationChange = 0;

                m_TimeOfLastRotationChange = m_CurrentWorldTime;
                m_TimeOfSinceLastRotationChange = 0;

                m_PositionUpdatesStarted = true;
            }
        }
    }

    public void UpdatePosition_Network()
    {
        //Debug.Log("         (" + m_CurrentSimTime + ") - Top of UpdatePosition_Network");

        UpdateNetworkTimers();

        if (!m_Paused)
        {
            if (!m_PositionUpdatesStarted)
            {
                InitialPositioningLoop();
                m_TempBoolOnce = true;
            }

            if (m_PositionUpdatesStarted && (m_EntityUpdates.Count > 0))
            {
                //Debug.Log("m_PositionUpdatesStarted && (m_EntityUpdates.Count > 0)");

                m_CurrentSimUpdate = m_EntityUpdates[m_EntityUpdates.Count - 1];

                if (m_TempBoolOnce)
                {
                    SetPreviousUpdate(m_CurrentSimUpdate);
                    m_TempBoolOnce = false;
                }

                if (m_ControlType == EntityControlType.NETWORK)
                {
                    if ((m_CurrentSimUpdate.GPS.lat == m_PreviousSimUpdate.GPS.lat) && (m_CurrentSimUpdate.GPS.lon == m_PreviousSimUpdate.GPS.lon) && (m_CurrentSimUpdate.GPS.alt == m_PreviousSimUpdate.GPS.alt))
                    {
                        if (!typeof(Air).IsAssignableFrom(this.GetType()))
                        {
                            //Debug.Log("[Entity] ID: " + m_EntityID + " Update was Ignored due to identical gps");
                            return;
                        }
                    }
                }

                m_CurrentSimUpdate.Position = GPSEncoder.DGPSToUCS(m_CurrentSimUpdate.GPS.lat, m_CurrentSimUpdate.GPS.lon);
                m_PreciseGPS = m_CurrentSimUpdate.GPS;

                if (Vector3.Distance(m_Transform.position, m_CurrentSimUpdate.Position) < m_NetworkMonitor.m_XYZDistToIgnore)
                {
                    //Debug.Log("Ignored due to dist ignore");
                    return;
                }

                m_CurrentSimUpdate.Position.y = (float)m_CurrentSimUpdate.GPS.alt;

                m_CurrentXYZDestination = m_CurrentSimUpdate.Position;

                // Debug.DrawLine(m_PreviousSimUpdate.Position, m_CurrentXYZDestination, Color.red, 1);

                // Debug.Log("m_CurrentSimUpdate.Position: " + m_CurrentSimUpdate.Position);

                //Debug.Log("Lat: " + m_CurrentSimUpdate.GPS.lat + " Lon: " + m_CurrentSimUpdate.GPS.lon + " Alt: " + m_CurrentSimUpdate.GPS.alt + " XYZ Position: " + m_Transform.position + " XYZ Destination: " + m_CurrentXYZDestination + " Distance: " + (m_CurrentXYZDestination - transform.position) + " XYZ Rotation: " + m_CurrentXYZRotationTarget);

                //Debug.DrawRay(m_CurrentXYZDestination, new Vector3(0, 10, 0), Color.red, 10);

                m_DistanceToCurrentDestination = GetDistanceIgnoringY(transform.position, m_CurrentXYZDestination);

                m_TimeSinceLastDestinationChange = m_CurrentWorldTime - m_TimeOfLastDestinationChange;
                m_TimeOfSinceLastRotationChange = m_CurrentWorldTime - m_TimeOfLastRotationChange;

                if (m_PreviousXYZDestination != m_CurrentXYZDestination)
                {
                    m_TimeOfLastDestinationChange = m_CurrentWorldTime;

                    m_PreviousXYZDestination = m_PreviousSimUpdate.Position;
                }

                m_CurrentXYZDestination = m_CurrentSimUpdate.Position;
                m_CurrentXYZRotationTarget = m_CurrentSimUpdate.Rotation;
                //m_CurrentQRotationTarget = Quaternion.Euler(m_CurrentSimUpdate.Rotation);

                m_PreviousSimUpdate = m_CurrentSimUpdate;

                if (m_UseExternalPhysics)
                {
                    InternalApplyExternalPhysics();
                }
                else
                {
                    if (m_EnableElevationUpdates)
                    {
                        m_CurrentXYZDestination.y = Mathf.Lerp(transform.position.y, m_DesiredAltitude, m_ElevationChangeSpeed);
                    }
                    else
                    {
                        m_CurrentXYZDestination.y = transform.position.y;
                    }

                    m_PreviousXYZRotationTarget = m_CurrentXYZRotationTarget;

                    if (m_CurrentSimUpdate.Rotation.x == Vector3.negativeInfinity.x) // No valid Pitch in update
                    {
                        //Debug.Log("1");
                        m_CurrentXYZRotationTarget.x = 0;
                    }
                    else
                    {
                        if (Common.IsValidUnsignedAngle(m_CurrentSimUpdate.Rotation.x))
                        {
                            m_CurrentXYZRotationTarget.x = m_CurrentSimUpdate.Rotation.x;
                            // Debug.Log("4");
                        }
                        else
                        {
                            // Debug.Log("5");
                            m_CurrentXYZRotationTarget.x = 0;
                        }
                    }

                    if ((m_CurrentSimUpdate.Rotation.y == Vector3.negativeInfinity.y) || (m_CurrentSimUpdate.Rotation.y == Vector3.zero.y)) // No valid Heading in update
                    {
                        //Debug.Log("2");
                        if (m_CurrentXYZDestination != transform.position)
                        {
                            // Debug.Log("3");
                            m_LookVector = (m_CurrentXYZDestination - transform.position).normalized;

                            //Debug.Log("Look Vec (" + m_LookVector + ")- m_CurrentXYZDestination: " + m_CurrentXYZDestination + " " + m_PreviousSimUpdate.Position);

                            if (m_LookVector != Vector3.zero)
                            {
                                m_CurrentXYZRotationTarget.y = Quaternion.LookRotation(m_LookVector).eulerAngles.y;
                                //Debug.Log("y = " + m_CurrentXYZRotationTarget.y);
                            }
                            else
                            {
                                //Debug.Log("7");
                                m_CurrentXYZRotationTarget.y = m_Transform.rotation.eulerAngles.y;
                            }
                        }
                        else
                        {
                            //Debug.Log("8");
                            m_CurrentXYZRotationTarget.y = m_Transform.rotation.eulerAngles.y;
                        }
                    }
                    else
                    {
                        // Debug.Log("9");
                        m_CurrentXYZRotationTarget.y = m_CurrentSimUpdate.Rotation.y;
                    }

                    if (m_CurrentXYZRotationTarget.z == Vector3.negativeInfinity.z) // No valid Roll in update
                    {
                        //Debug.Log("4");
                        m_CurrentXYZRotationTarget.z = 0;
                    }
                    else
                    {
                        if (Common.IsValidUnsignedAngle(m_CurrentSimUpdate.Rotation.z)) m_CurrentXYZRotationTarget.z = m_CurrentSimUpdate.Rotation.z;
                        else m_CurrentXYZRotationTarget.z = 0;
                    }

                    //Debug.Log(m_CurrentXYZRotationTarget);

                    ////if(m_CurrentXYZDestination != Vector3.zero) // If update has valid rotation do nothing
                    //if (m_CurrentXYZRotationTarget != Vector3.zer) // If update has valid rotation do nothing
                    //{

                    //}
                    //else // If update lacks valid rotation, calculate it
                    //{
                    //    Debug.Log("1");
                    //    if (m_CurrentXYZDestination != m_PreviousSimUpdate.Position)
                    //    {
                    //        Debug.Log("2");
                    //        m_LookVector = (m_CurrentXYZDestination - m_PreviousSimUpdate.Position).normalized;

                    //        if (m_LookVector != Vector3.zero)
                    //        {
                    //            m_CurrentXYZRotationTarget = Quaternion.LookRotation(m_LookVector).eulerAngles;
                    //        }
                    //        else
                    //        {
                    //            m_CurrentXYZRotationTarget = m_Transform.rotation.eulerAngles;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        Debug.Log("3");
                    //        m_CurrentXYZRotationTarget = m_Transform.rotation.eulerAngles;
                    //    }
                    //}

                    //   Debug.Log("Calculated Rotation: " + m_CurrentXYZRotationTarget);

                    InternalApplyPositionUpdate();
                    InternalApplyRotationUpdate();

                    // Debug.Log("m_CurrentXYZRotationTarget: " + m_CurrentXYZRotationTarget);

                    m_CurrentQRotationTarget = Quaternion.Euler(m_CurrentXYZRotationTarget);

                    if (m_PreviousQRotationTarget != m_CurrentQRotationTarget)
                    {
                        m_TimeOfLastRotationChange = m_CurrentWorldTime;

                        m_PreviousQRotationTarget = m_CurrentQRotationTarget;
                    }

                    //SetPreviousUpdate(m_CurrentSimUpdate);

                }

                if (m_PositionUpdatesStarted)
                {
                    if (m_EntityUpdates.Count > 1)
                    {
                        m_EntityUpdates.Clear();
                        m_EntityUpdates.Add(m_PreviousSimUpdate);
                    }
                    else if (m_EntityUpdates.Count == 1)
                    {
                        m_EntityUpdates.Clear();
                    }
                }
            }
        }
        else
        {
            if (m_ParentEntity != null && m_PreviousSimUpdate != null)
            {
                m_PreviousSimUpdate.Position = m_Transform.position;
            }
        }
    }

    public virtual void InternalApplyExternalPhysics()
    {
        //Debug.Log("[Entity] ExPhysics Update");
        if (m_RigidBody.useGravity) m_RigidBody.useGravity = false;
        if (m_RigidBody.isKinematic) m_RigidBody.isKinematic = true;

        //SetPosition(Vector3.Lerp(m_PreviousXYZDestination, m_CurrentXYZDestination, m_TimeSinceLastDestinationChange));

        //SetRotation(Quaternion.RotateTowards(m_PreviousQRotationTarget, m_CurrentQRotationTarget, m_TimeOfSinceLastRotationChange), true);

        if (m_ConversionActive)
        {
            Vector3 l_NewVec = m_CurrentSimUpdate.Rotation;
            l_NewVec.y = Mathf.Repeat(90 - m_CurrentSimUpdate.Rotation.y + 360, 360) + 180;
            SetRotation(l_NewVec);
        }
        else
        {
            SetRotation(m_CurrentSimUpdate.Rotation);
        }

        SetPosition(m_CurrentXYZDestination);

        if (m_EnableElevationUpdates) m_DesiredAltitude = m_CurrentSimUpdate.Position.y;
    }

    public virtual void InternalApplyPositionUpdate()
    {
        if (m_MovementEnabled)
        {
            Vector3 l_NewPosition;


            //l_NewPosition = Common.LerpIgnoringY(m_PreviousXYZDestination, m_CurrentXYZDestination, m_TimeSinceLastDestinationChange, transform.position.y);



            l_NewPosition = Common.LerpIgnoringY(m_PreviousXYZDestination, m_CurrentXYZDestination, m_TimeSinceLastDestinationChange, transform.position.y);

            if (m_EnableElevationUpdates)
            {
                l_NewPosition.y = Mathf.Lerp(transform.position.y, m_DesiredAltitude, m_ElevationChangeSpeed);
            }


            //transform.position = l_NewPosition;
            this.SetPosition(l_NewPosition);
        }
    }

    public virtual void InternalApplyRotationUpdate()
    {
        if (m_MovementEnabled)
        {
            Vector3 l_NewRotation = Vector3.Lerp(transform.rotation.eulerAngles, m_CurrentXYZRotationTarget, m_TimeSinceLastDestinationChange);
            //transform.rotation = Quaternion.Euler(l_NewRotation);
        }
    }

    public float GetDistanceIgnoringY(Vector3 a_Point1, Vector3 a_Point2)
    {
        float l_Ret = -1;

        float l_X = a_Point2.x - a_Point1.x;
        l_X = l_X * l_X;

        float l_Y = a_Point2.z - a_Point1.z;
        l_Y = l_Y * l_Y;


        l_Ret = Mathf.Sqrt(l_X + l_Y);

        return l_Ret;
    }

    public void InternalApplyStateUpdates()
    {
        if (m_EntityUpdates.Count > 1)
        {
            for (int i = 0; i < m_EntityUpdates.Count; i++)
            {
                if (m_EntityUpdates[i].Value < m_CurrentSimTime)
                {
                    setState(m_EntityUpdates[i].State);

                    if (i < (m_EntityUpdates.Count - 1))
                    {
                        m_UpdatesToRemove.Add(m_EntityUpdates[i]);
                    }
                }
            }
        }
        else if (m_EntityUpdates.Count == 1)
        {
            m_EntityUpdatesZeroDest = m_EntityUpdates[0].Position;
            m_EntityUpdatesZeroState = m_EntityUpdates[0].State;

            if (m_EntityUpdates[0].Value < m_CurrentSimTime)
            {
                if (m_DistanceToCurrentDestination < m_ArrivedAtFinalPositionTolerance)
                {

                    setState(m_EntityUpdates[0].State);

                    m_UpdatesToRemove.Add(m_EntityUpdates[0]);
                }
            }
        }

        if (m_UpdatesToRemove.Count > 0)
        {
            foreach (SimUpdate l_Update in m_UpdatesToRemove)
            {
                m_EntityUpdates.Remove(l_Update);
            }
        }

    }

    public void UpdateOptions()
    {
        if (m_ForceResizeModel)
        {
            resizeModel();
            m_ForceResizeModel = false;
        }
        if (m_ForceResizeCollisionDetectionBox)
        {
            resizeCollisionDetectionBox();
            m_ForceResizeCollisionDetectionBox = false;
        }
        if (m_ForceNewAttachpoint)
        {
            Debug.Log("FORCING NEW CAM ATTACH POINT");

            setCameraAttachPoint(null);
            getCameraAttachPoint();

            m_ForceNewAttachpoint = false;
        }
    }

    public virtual void addWaypoint(SimUpdate a_WaypointUpdate)
    {
        //m_GPSWaypoints.Add(a_WaypointUpdate);

        if (GetWaypointModule())
        {
            //Debug.Log("Adding Waypoint Module - Lat: " + a_WaypointUpdate.Position.x + " Lon: " + a_WaypointUpdate.Position.y + " Ele: " + a_WaypointUpdate.Position.z);
            m_WaypointModule.addWaypoint(a_WaypointUpdate);
            return;
        }

        //if (a_WaypointUpdate.State == EntityState.UNKNOWN)
        //{
        //    m_NumberOfPositionWaypoints++;
        //    m_DisplayWaypoints.Add(m_EntityID + " " + a_WaypointUpdate.Position.x + " " + a_WaypointUpdate.Position.y + " " + a_WaypointUpdate.Position.z + " " + a_WaypointUpdate.State);

        //    Debug.Log("Adding Waypoint - Lat: " + a_WaypointUpdate.Position.x + " Lon: " + a_WaypointUpdate.Position.y + " Ele: " + a_WaypointUpdate.Position.z);
        //}
        //else
        //{
        //    m_DisplayWaypoints.Add(m_EntityID + " " + a_WaypointUpdate.Position.x + " " + a_WaypointUpdate.Position.y + " " + a_WaypointUpdate.Position.z + " " + a_WaypointUpdate.State);

        //    Debug.Log("Adding State Waypoint - State: " + a_WaypointUpdate.State);
        //}
    }

    public bool GetWaypointModule()
    {
        if (!m_WaypointModule)
        {
            GameObject l_Obj = m_ControlObjects.GetControlObject("WaypointModule");

            if (l_Obj)
            {
                m_WaypointModule = l_Obj.GetComponent<WaypointModule>();
                return true;
            }

        }
        else return true;

        return false;
    }

    public virtual void addWaypoint(SimUpdate a_WaypointUpdate, int a_Position)
    {
        //m_GPSWaypoints.Insert(a_Position, a_WaypointUpdate);

        if (GetWaypointModule())
        {
            Debug.Log("Adding Waypoint Module - Lat: " + a_WaypointUpdate.Position.x + " Lon: " + a_WaypointUpdate.Position.y + " Ele: " + a_WaypointUpdate.Position.z);

            m_WaypointModule.addWaypoint(a_WaypointUpdate, a_Position);
            return;
        }

        //if (a_WaypointUpdate.State == EntityState.UNKNOWN)
        //{
        //    m_NumberOfPositionWaypoints++;
        //    m_DisplayWaypoints.Add(m_EntityID + " " + a_WaypointUpdate.Position.x + " " + a_WaypointUpdate.Position.y + " " + a_WaypointUpdate.Position.z + " " + a_WaypointUpdate.State);

        //    Debug.Log("Adding Waypoint - Lat: " + a_WaypointUpdate.Position.x + " Lon: " + a_WaypointUpdate.Position.y + " Ele: " + a_WaypointUpdate.Position.z);
        //}
        //else
        //{
        //    m_DisplayWaypoints.Add(m_EntityID + " " + a_WaypointUpdate.Position.x + " " + a_WaypointUpdate.Position.y + " " + a_WaypointUpdate.Position.z + " " + a_WaypointUpdate.State);

        //    Debug.Log("Adding State Waypoint - State: " + a_WaypointUpdate.State);
        //}
    }

    public void addPosition(XSIMUpdateMessage a_Update)
    {
        if (!m_EntityInitialized || !m_AcceptNewUpdates) return;

        //if (((float)a_Update.lat == m_PreviousXSIMUpdate.lat) && ((float)a_Update.lon == m_PreviousXSIMUpdate.lon) && (a_Update.altitude == m_PreviousXSIMUpdate.altitude) && ((EntityState)a_Update.state == EntityState.DEFAULT_POSUPDATE)) // Ignore duplicate messages. MWSE sends these continously when paused
        //{
        //    return;
        //}

        //Debug.Log("addPosition Heading: " + a_Update.heading);

        SimUpdate l_NewUpdate = new SimUpdate();

        //if(m_EnableElevationUpdates)
        //{
        //    a_Update.depth = Mathf.Lerp((float)a_Update.depth, m_DesiredAltitude, m_ElevationChangeSpeed);
        //}

        l_NewUpdate.GPS.lat = a_Update.lat;
        l_NewUpdate.GPS.lon = a_Update.lon;
        l_NewUpdate.GPS.alt = a_Update.altitude;

        if (m_UseExternalPhysics)
        {
            l_NewUpdate.Rotation = new Vector3((float)a_Update.pitch, (float)a_Update.heading, (float)a_Update.roll);
        }
        else
        {
            if (Common.IsValidUnsignedAngle(a_Update.pitch)) l_NewUpdate.Rotation.x = a_Update.pitch;
            if (Common.IsValidUnsignedAngle(a_Update.heading)) l_NewUpdate.Rotation.y = a_Update.heading;
            if (Common.IsValidUnsignedAngle(a_Update.roll)) l_NewUpdate.Rotation.z = a_Update.roll;

        }

        //Debug.Log("Raw Message Rotation: " + l_NewUpdate + " - SimUpdate Rotation: " + l_NewUpdate.Rotation);

        l_NewUpdate.State = (EntityState)a_Update.state;
        l_NewUpdate.Value = a_Update.timeReceived;

        m_EntityUpdates.Add(l_NewUpdate);

        m_TimeOfLastMessage = (float)m_NetworkMonitor.GetNSITime();

        m_PreviousXSIMUpdate = a_Update;
    }

    public void addPosition(SimUpdate a_Update)
    {
        if (!m_EntityInitialized || !m_AcceptNewUpdates) return;

        if (m_NetworkMonitor.m_NetworkAgentActive)
        {
            a_Update.Value = (float)m_NetworkMonitor.GetNSITime();
        }

        m_EntityUpdates.Add(a_Update);

        if (HasPreviousUpdate()) SetPreviousUpdate(m_CurrentSimUpdate);
        else SetPreviousUpdate(a_Update);

        m_TimeOfLastMessage = (float)m_NetworkMonitor.GetNSITime();
    }

    void updateVehicleInformation()
    {
        if (m_RigidBody != null)
        {
            if (m_ControlType == EntityControlType.PLAYER || m_ControlType == EntityControlType.NONE) m_CurrentSpeed = Vector3.Dot(m_RigidBody.velocity, m_Transform.forward); //m_CurrentSpeed = transform.InverseTransformDirection(m_RigidBody.velocity).z * metersToKnots;
            else
            {
                if (currentXYZPosition != previousXYZPosition)
                    m_CurrentSpeed = (Vector3.Magnitude(currentXYZPosition - previousXYZPosition) / Time.deltaTime);// * Common.metersToKnots;
            }

            if (m_CurrentSpeed == 0)
            {

            }
        }

        m_CurrentHeading = transform.rotation.eulerAngles.y - 0;

        if (m_CurrentHeading < 0) m_CurrentHeading += 360;

        m_CurrentPitch = transform.rotation.eulerAngles.x;
        m_CurrentRoll = transform.rotation.eulerAngles.z;

        m_CurrentAltitude = gameObject.transform.position.y;

        UpdateSerialization();
    }

    Vector3 ConvertXYZtoGPS(Vector3 a_XYZ)
    {
        Vector3 l_GPS = GPSEncoder.GPSToUCS(currentGPSPosition);
        l_GPS.y = a_XYZ.y;

        return l_GPS;
    }

    void updatePositionData()
    {
        if (!m_PositionData_Initialized)
        {
            startPositionData();
        }
        else
        {
            currentXYZPosition = gameObject.transform.position;
            m_Elevation = currentXYZPosition.y;

            m_TempChanged = false;

            //if (SimulatorSettings.getGPSPanel().m_OriginChanged)
            //{
            //    Debug.Log(gameObject.name + " detected origin change.");
            //    currentXYZPosition = GPSEncoder.GPSToUCS(currentGPSPosition);
            //    updateXYZCoordinate(currentXYZPosition);

            //    changed = true;
            //}

            if (SimulatorSettings.getGPSPanel().m_OriginChanged) return;

            if (currentGPSPosition != previousGPSPosition) // If GPS pos changed
            {
                currentXYZPosition = ConvertXYZtoGPS(currentGPSPosition);
                updateXYZCoordinate(currentXYZPosition);

                m_TempChanged = true;
            }
            else if (currentXYZPosition != previousXYZPosition) // If XYZ pos changed
            {
                currentGPSPosition = GPSEncoder.USCToGPS(gameObject.transform.position);
                updateGPSCoordinate(currentGPSPosition);

                m_TempChanged = true;
            }


            if (m_TempChanged)
            {
                previousGPSPosition = currentGPSPosition;
                previousXYZPosition = currentXYZPosition;
            }

        }
    }

    void updateCommandModule()
    {
        Debug.Log("updateCommandModule");

    }

    public void addSmoke()
    {
        if (!m_HasSmoke)
        {
            ParticleSystem l_Smoke = (ParticleSystem)Instantiate(SimulatorSettings.getAnimationManager().getParticleSystem(gameObject.tag, "Smoke"), transform.position, transform.rotation);

            //set the target object's parent as the selected object

            l_Smoke.transform.SetParent(transform);
            l_Smoke.transform.Rotate(Vector3.right * -90);

            //smoke.transform.SetPositionAndRotation(Vector3.zero, transform.rotation);

            if (!m_ParticleList.ContainsKey("Smoke"))
            {
                m_ParticleList.Add("Smoke", l_Smoke);
                m_ParticleListSize = m_ParticleList.Count;
            }

            m_HasSmoke = true;
        }
    }

    public void RemoveSmoke()
    {
        if (m_HasSmoke)
        {
            if (m_ParticleList.ContainsKey("Smoke"))
            {
                m_ParticleList.Remove("Smoke");
            }

            m_HasSmoke = false;
        }
    }

    public void DisableParticles()
    {
        // Debug.Log("Disabling particles.");

        if (m_ControlObjects.GetControlObject("ParticleSystems"))
        {
            m_ControlObjects.GetControlObject("ParticleSystems").SetActive(false);
        }
        //foreach(KeyValuePair<string,ParticleSystem> l_Particle in m_ParticleList)
        //{
        //    if(l_Particle.Value == null)
        //    {
        //        m_ParticleList.Remove(l_Particle.Key);
        //    }
        //    else
        //    {
        //        l_Particle.Value.Stop();
        //    }
        //}
    }

    //Vector2 getCurrentHeadingtoDestination()
    //{
    //    XYm_CurrentHeading = Vector2.zero;
    //    XYm_CurrentHeading = (currentDestination - currentLocation).normalized;
    //    Debug.DrawLine(currentDestination, currentDestination + XYm_CurrentHeading * 10, Color.red, Mathf.Infinity);

    //    return XYm_CurrentHeading;
    //}

    //public void createDisplayName(int val = 0)
    //{

    //    bool bName, bID;
    //    if (m_EntityName == string.Empty)
    //    {
    //        if (val > 0) m_EntityName = gameObject.name + val.ToString();
    //        else m_EntityName = gameObject.name;
    //        bName = true;
    //    }
    //    else
    //    {
    //        bName = true;
    //    }

    //    if (m_EntityID >= 0)
    //    {
    //        bID = true;
    //    }
    //    else
    //    {
    //        bID = false;
    //    }

    //    if (bName && bID)
    //    {
    //        m_DisplayName = "ID: " + m_EntityID.ToString() + " (" + m_EntityName + ")";
    //    }
    //    else if (bName && !bID)
    //    {
    //        m_DisplayName = m_EntityName;
    //    }
    //    else if (!bName && bID)
    //    {
    //        m_DisplayName = "ID: " + m_EntityID.ToString();
    //    }
    //    else if (!bName && !bID)
    //    {
    //        m_DisplayName = "Unknown Target";
    //    }
    //}

    //public string getDisplayName()
    //{
    //    return m_DisplayName;
    //}

    void updateGPSCoordinate(Vector2 GPSCoordinate)
    {

    }

    public void updateXYZCoordinate(Vector3 XYZCoordinate)
    {
        if (!GPSEncoder.getLocalOrigin().Equals(new Vector2(0, 0)))
        {
            XYZCoordinate.y = transform.position.y;

            gameObject.transform.position = XYZCoordinate;
        }
    }

    public void setXYZPosition(Vector3 a_XYZ)
    {
        transform.position = a_XYZ;
        currentGPSPosition = GPSEncoder.USCToGPS(a_XYZ);
    }

    public void setGPSPosition(Vector2 a_LatLon)
    {
        currentGPSPosition = a_LatLon;
        float l_Elevation = transform.position.y;

        transform.position = GPSEncoder.GPSToUCS(currentGPSPosition);
        transform.position = new Vector3(transform.position.x, l_Elevation, transform.position.z);
    }

    Vector3 getXYZCoordinate()
    {
        return currentXYZPosition;
    }

    Vector3 getGPSCoordinate()
    {
        return new Vector3(currentGPSPosition.x, 0, currentGPSPosition.y);
    }

#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        if (m_labelPosition != null) Handles.Label(m_labelPosition.transform.position, m_EntityName);
        else setLabelPosition();
    }
#endif

    //public Transform getCameraAttachmentPoint()
    //{
    //    if (m_CameraAttachPoint == null)
    //    {
    //        return gameObject.transform;
    //    }
    //    else
    //    {
    //        Transform camTransform = m_CameraAttachPoint;
    //        camTransform.position = new Vector3((m_CameraAttachPoint.position.x / m_StaticControlSystem.transform.localScale.x), (m_CameraAttachPoint.position.y / m_StaticControlSystem.transform.localScale.y), (m_CameraAttachPoint.position.z / m_StaticControlSystem.transform.localScale.z));
    //        return camTransform;
    //    }

    //}

    public static Rect GUIRectWithObject(GameObject go)
    {
        Vector3 cen = go.GetComponent<Renderer>().bounds.center;
        Vector3 ext = go.GetComponent<Renderer>().bounds.extents;
        Vector2[] extentPoints = new Vector2[8]
           {
               WorldToGUIPoint(new Vector3(cen.x-ext.x, cen.y-ext.y, cen.z-ext.z)),
               WorldToGUIPoint(new Vector3(cen.x+ext.x, cen.y-ext.y, cen.z-ext.z)),
               WorldToGUIPoint(new Vector3(cen.x-ext.x, cen.y-ext.y, cen.z+ext.z)),
               WorldToGUIPoint(new Vector3(cen.x+ext.x, cen.y-ext.y, cen.z+ext.z)),
               WorldToGUIPoint(new Vector3(cen.x-ext.x, cen.y+ext.y, cen.z-ext.z)),
               WorldToGUIPoint(new Vector3(cen.x+ext.x, cen.y+ext.y, cen.z-ext.z)),
               WorldToGUIPoint(new Vector3(cen.x-ext.x, cen.y+ext.y, cen.z+ext.z)),
               WorldToGUIPoint(new Vector3(cen.x+ext.x, cen.y+ext.y, cen.z+ext.z))
           };
        Vector2 min = extentPoints[0];
        Vector2 max = extentPoints[0];
        foreach (Vector2 v in extentPoints)
        {
            min = Vector2.Min(min, v);
            max = Vector2.Max(max, v);
        }
        return new Rect(min.x, min.y, max.x - min.x, max.y - min.y);
    }

    public static Vector2 WorldToGUIPoint(Vector3 world)
    {
        Vector2 screenPoint = Camera.main.WorldToScreenPoint(world);
        screenPoint.y = (float)Screen.height - screenPoint.y;
        return screenPoint;
    }

    // Access Functions

    public string getEntityName()
    {
        if (m_EntityInitialized) return m_EntityName;
        else return "";
    }

    public void setEntityName(string a_NewName)
    {
        if (m_EntityInitialized) m_EntityName = a_NewName;
    }

    public int getEntityID()
    {
        if (m_EntityInitialized) return m_EntityID;
        else return -1;
    }

    public void setEntityID(int a_NewID)
    {
        Debug.Log("SetEntityID(int a_CurrentID(" + m_EntityID + "), int a_NewID(" + a_NewID + "))");

        if (m_EntityInitialized)
        {
            m_EntityID = a_NewID;
            ApplyHullNumbers();
        }
        else
        {
            Debug.Log("SetEntityID(int a_NewID(" + a_NewID + ")) Failed: Entity not initialized.");
        }
    }

    public int getEntitySMMTTID()
    {
        if (m_EntityInitialized) return m_EntitySMMTTID;
        else return -1;
    }

    public void setEntitySMMTTID(int a_NewType)
    {
        if (m_EntityInitialized) m_EntitySMMTTID = a_NewType;
    }

    public float getCurrentHeading()
    {
        return m_CurrentHeading;
    }

    public float getCurrentSpeed()
    {
        return m_CurrentSpeed;
    }

    public float getMaxSpeed()
    {
        return m_MaxSpeed;
    }

    public Vector2 getCurrentGPSPosition()
    {
        return currentGPSPosition;
    }

    public Vector3 getCurrentXYZPosition()
    {
        return currentXYZPosition;
    }

    public virtual void Restore()
    {
        Debug.Log("[Entity] Entity: " + m_EntityName + "(" + m_EntityID + ") has been restored.");
        m_EntityUpdates.Clear();
        m_AcceptNewUpdates = true;

        m_EntityState = m_OriginalState;
        m_CurrentHullPoints = m_OriginalHullPoints;
        SetPosition(m_OriginalPosition);
        SetRotation(m_OriginalRotation, true);

        m_RigidBody.mass = m_OriginalMass;
        m_MovementEnabled = true;
        m_PositionUpdatesStarted = false;
        m_TimeSinceFirstMessageReceived = (float)m_NetworkMonitor.GetNSITime();
        RemoveSmoke();
    }

    public void removeHullPoint()
    {
        m_CurrentHullPoints--;
    }

    public void removeHullPoints(int a_Num)
    {
        m_CurrentHullPoints -= a_Num;
    }

    public bool getMovementEnabled()
    {
        return m_MovementEnabled;
    }

    public void setMovementEnabled(bool a_Bool)
    {
        m_MovementEnabled = a_Bool;
    }

    public Transform getCameraAttachPoint()
    {
        if (!(m_EntityInitialized && m_EntityStarted))
        {
            Debug.Log("SOMEONE CALLED GET CAM ATTACH BEFORE THE ENTITY STARTED");
            return transform;
        }

        if (m_CameraAttachPoint != null) return m_CameraAttachPoint;

        Debug.Log("COs Active: " + m_ControlObjects.gameObject.activeInHierarchy + " GO Active + " + gameObject.activeInHierarchy);

        m_ControlObjects.GetControlObjects();

        if (m_ControlObjects.ContainsControlObject("CameraAttachPoint"))
        {
            Debug.Log(gameObject.name + " already has a cameraAttachPoint");
            Transform l_Transform = m_ControlObjects.GetControlObject("CameraAttachPoint").transform;

            if (l_Transform == null)
            {
                Debug.Log("Cam attach exists in CO, but is null when retrieved?");
            }

            setCameraAttachPoint(l_Transform);
        }
        else
        {

            Debug.Log(gameObject.name + " is adding a new cameraAttachPoint");
            m_ModelBounds = m_ModelLoader.getModelBounds();

            GameObject l_NewAttachPoint = new GameObject("CameraAttachPoint");
            l_NewAttachPoint.transform.parent = m_ControlObjects.transform;

            if (m_EntityType == "SENSOR")
            {
                l_NewAttachPoint.transform.localPosition = l_NewAttachPoint.transform.InverseTransformDirection(new Vector3(0, 0, (m_ModelBounds.extents.z)));
            }
            else
            {
                l_NewAttachPoint.transform.localPosition = l_NewAttachPoint.transform.InverseTransformDirection(new Vector3((0.0f), (m_ModelBounds.extents.y * 1.4f), (-0.5f * m_ModelBounds.extents.z)));

            }
            setCameraAttachPoint(l_NewAttachPoint.transform);

            m_ControlObjects.AddControlObject("CameraAttachPoint", l_NewAttachPoint);

        }

        return m_CameraAttachPoint;
    }

    public void setCameraAttachPoint(Transform a_Transform)
    {
        //Debug.Log("setCameraAttachPoint: " + a_Transform.localPosition);
        m_CameraAttachPoint = a_Transform;
    }

    public bool getIsTarget()
    {
        return m_IsTarget;
    }

    public void setIsTarget(bool a_Bool)
    {
        m_IsTarget = a_Bool;
    }

    public TargetZone getTargetZone()
    {
        return m_TargetZone;
    }

    public void setTargetZone(TargetZone a_Zone)
    {
        m_TargetZone = a_Zone;
    }

    public bool getTargetSunk()
    {
        return m_EntitySunkToTheBottom;
    }

    public virtual void setSpeed(int a_Speed)
    {
        m_DesiredSpeed = a_Speed;
    }

    public virtual void setMaxSpeed(int a_Speed)
    {
        m_MaxSpeed = a_Speed;
    }

    public virtual void setHeading(float a_Heading, float a_TurningSpeed = -1)
    {
        m_DesiredHeading = a_Heading;
    }

    public virtual void setSpeedOverride(int a_Speed)
    {
        m_SpeedOverride = a_Speed;
    }

    public void setHeadingOverride(float a_Heading)
    {
        Debug.Log(m_EntityName + "::setHeadingOverride");
        m_DesiredHeading = a_Heading;
        SetRotation(new Vector3(gameObject.transform.rotation.eulerAngles.x, a_Heading, gameObject.transform.rotation.eulerAngles.z));

    }

    void AddEffectorLaunchPoint()
    {
        GameObject l_LaunchPoint = m_ControlObjects.GetControlObject("EffectorLaunchPoint");
        if (l_LaunchPoint == null)
        {
            Debug.Log("Adding new EffectorLaunchPoint to " + gameObject.name);
            l_LaunchPoint = new GameObject("EffectorLaunchPoint");
            l_LaunchPoint.transform.position = new Vector3(m_ModelBounds.center.x, m_ModelBounds.center.y, m_ModelBounds.max.z);
            l_LaunchPoint.transform.parent = m_ControlObjects.gameObject.transform;

            m_ControlObjects.AddControlObject("EffectorLaunchPoint", l_LaunchPoint);
            m_LaunchPoint = l_LaunchPoint;
        }
        else
        {
            //Debug.Log("Using stored motor");

        }
    }

    void AddEffectorTargetPoint()
    {
        GameObject l_TargetPoint = m_ControlObjects.GetControlObject("EffectorTargetPoint");
        if (l_TargetPoint == null)
        {
            //Debug.Log("Adding new EffectorTargetPoint to " + gameObject.name);
            l_TargetPoint = new GameObject("EffectorTargetPoint");
            l_TargetPoint.transform.parent = m_ControlObjects.gameObject.transform;
            l_TargetPoint.transform.localPosition = Vector3.zero;

            m_ControlObjects.AddControlObject("EffectorTargetPoint", l_TargetPoint);
            m_EffectorTargetPoint = l_TargetPoint.transform;
        }
        else
        {
            //Debug.Log("Using stored motor");

        }
    }

    public Transform getEffectorLaunchPoint()
    {
        Transform l_LaunchPoint;

        if (m_LaunchPoint != null)
        {
            l_LaunchPoint = m_LaunchPoint.transform;
        }
        else
        {
            l_LaunchPoint = transform;
        }

        return l_LaunchPoint;
    }

    public void setEffectorLaunchPointWorld(Vector3 a_WorldPos, Quaternion a_Rotation)
    {
        if (m_LaunchPoint != null)
        {
            if (m_LaunchPoint != m_Transform)
            {
                m_LaunchPoint.transform.position = a_WorldPos;
                m_LaunchPoint.transform.rotation = a_Rotation;
            }
        }
    }

    public void switchEntityControl(EntityControlType a_ControlType)
    {
        if (m_EntityID == 0) return;

        if (a_ControlType == EntityControlType.PLAYER)
        {
            if (m_ControlType == EntityControlType.NETWORK || m_ControlType == EntityControlType.SCRIPT) return;
        }
        else if (a_ControlType == EntityControlType.SCRIPT)
        {
            if (m_ControlType == EntityControlType.NETWORK) return;
        }

        m_ControlType = a_ControlType;
    }

    public void endScriptedMovement()
    {
        if (m_ControlType == EntityControlType.SCRIPT) switchEntityControl(EntityControlType.NONE);

        m_LHorizontalInput = 0;
        m_LVerticalInput = 0;
        m_DesiredSpeed = 0;
    }

    public EntityState getState()
    {
        return m_EntityState;
    }

    public virtual void setState(EntityState a_NewState)
    {
        m_EntityState = a_NewState;

        if (m_EntityState != EntityState.DEFAULT_POSUPDATE)
        {
            SimulatorSettings.getNetworkMonitor().sendDebug(m_EntityName + "(" + m_EntityID + ") setState Request: " + m_EntityState as string + "(Was " + m_EntityState as string);
        }

        if ((m_EntityState != m_PreviousEntityState) && (m_AcceptNewUpdates))
        {
            SimulatorSettings.getNetworkMonitor().sendDebug(m_EntityName + "(" + m_EntityID + ") was assigned state: " + m_EntityState as string + "(Was " + m_EntityState as string);

            if (m_EntityState == EntityState.DEFAULT_POSUPDATE)
            {
                On_DEFAULT_POSUPDATE();
            }
            else if (m_EntityState == EntityState.DETECTION)
            {
                OnState_DETECTION();
            }
            else if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
            {
                OnState_EFFECTOR_COMPLETE();
            }
            else if (m_EntityState == EntityState.EFFECTOR_LAUNCHING)
            {
                OnState_EFFECTOR_LAUNCHING();
            }
            else if (m_EntityState == EntityState.EFFECTOR_MISSED)
            {
                OnState_EFFECTOR_MISSED();
            }
            else if (m_EntityState == EntityState.MINE_DETECTED)
            {
                OnState_MINE_DETECTED();
            }
            else if (m_EntityState == EntityState.MINE_CLASSIFIED)
            {
                OnState_MINE_CLASSIFIED();
            }
            else if (m_EntityState == EntityState.MINE_REACQUIRED)
            {
                OnState_MINE_REACQUIRED();
            }
            else if (m_EntityState == EntityState.MINE_IDENTIFIED)
            {
                OnState_MINE_IDENTIFIED();
            }
            else if (m_EntityState == EntityState.MINE_NEUTRALIZED)
            {
                OnState_MINE_NEUTRALIZED();
            }
            else if (m_EntityState == EntityState.MINE_ACTUATED)
            {
                OnState_MINE_ACTUATED();
            }
            else if (m_EntityState == EntityState.N81DEMOAQUAD_ARRIVED_AT_SHIP)
            {
                OnState_N81DEMOAQUAD_ARRIVED_AT_SHIP();
            }
            else if (m_EntityState == EntityState.OBJECT_DISABLED)
            {
                OnState_OBJECT_DISABLED();
            }
            else if (m_EntityState == EntityState.SYSTEM_TURNED_ON)
            {
                OnState_SYSTEM_TURNED_ON();
            }
            else if (m_EntityState == EntityState.SENSORS_ACTIVATED)
            {
                OnState_SENSORS_ACTIVATED();
            }
            else if (m_EntityState == EntityState.SENSORS_DEACTIVATED)
            {
                OnState_SENSORS_DEACTIVATED();
            }
            else if (m_EntityState == EntityState.STOPPED)
            {
                OnState_STOPPED();
            }
            else if (m_EntityState == EntityState.PAUSED)
            {
                OnState_PAUSED();
            }
            else if (m_EntityState == EntityState.SYSTEM_LAUNCHED)
            {
                OnState_SYSTEM_LAUNCHED();
            }
            else if (m_EntityState == EntityState.SYSTEM_COMPLETE)
            {
                OnState_SYSTEM_COMPLETE();
            }
            else if (m_EntityState == EntityState.SWITCH_LOADOUT_1)
            {
                OnState_SWITCH_LOADOUT_1();
            }
            else if (m_EntityState == EntityState.SWITCH_LOADOUT_2)
            {
                OnState_SWITCH_LOADOUT_2();
            }
            else if (m_EntityState == EntityState.SWITCH_LOADOUT_3)
            {
                OnState_SWITCH_LOADOUT_3();
            }
            else if (m_EntityState == EntityState.TURNING)
            {
                OnState_TURNING();
            }
            else if (m_EntityState == EntityState.STARTED)
            {
                OnState_STARTED();
            }
            else if (m_EntityState == EntityState.MOVE_TO_THREAT)
            {
                OnState_MOVE_TO_THREAT();
            }
            else if (m_EntityState == EntityState.RETURN_TO_HOST)
            {
                OnState_RETURN_TO_HOST();
            }
            else if (m_EntityState == EntityState.WAYPOINTS_START)
            {
                OnState_WAYPOINTS_START();
            }
            else if (m_EntityState == EntityState.WAYPOINTS_STOP)
            {
                OnState_WAYPOINTS_STOP();
            }
            else if (m_EntityState == EntityState.IDENTIFY)
            {
                OnState_IDENTIFY();
            }
            else if (m_EntityState == EntityState.CLASSIFY)
            {
                OnState_CLASSIFY();
            }
            else if (m_EntityState == EntityState.REACQUIRE)
            {
                OnState_REACQUIRE();
            }
            else if (m_EntityState == EntityState.NEUTRALIZE)
            {
                OnState_NEUTRALIZE();
            }
            else if (m_EntityState == EntityState.SPECIAL_ACTION_1)
            {
                OnState_SPECIAL_ACTION_1();
            }
            else if (m_EntityState == EntityState.SPECIAL_ACTION_2)
            {
                OnState_SPECIAL_ACTION_2();
            }
            else if (m_EntityState == EntityState.PASS_WAYPOINTS)
            {
                OnState_PASS_WAYPOINTS();
            }
            else if (m_EntityState == EntityState.DROP_NEARSURFACEMINE)
            {
                OnState_DROP_NEARSURFACEMINE();
            }
            else if (m_EntityState == EntityState.DROP_VOLUMEMINE)
            {
                OnState_DROP_VOLUMEMINE();
            }
            else if (m_EntityState == EntityState.DROP_BOTTOMMINE)
            {
                OnState_DROP_BOTTOMMINE();
            }
            else if (m_EntityState == EntityState.DROP_SURFACEMINE)
            {
                OnState_DROP_SURFACEMINE();
            }
            else if (m_EntityState == EntityState.START_BOTTOM_MINELINE)
            {
                OnState_START_MINELINE();
            }
            else if (m_EntityState == EntityState.START_SURFACE_MINELINE)
            {
                OnState_START_MINELINE();
            }
            else if (m_EntityState == EntityState.STOP_MINELINE)
            {
                OnState_STOP_MINELINE();
            }
            else if (m_EntityState == EntityState.LAND)
            {
                OnState_LAND();
            }
            else if (m_EntityState == EntityState.LOAD)
            {
                OnState_LOAD();
            }
            else if (m_EntityState == EntityState.UNLOAD)
            {
                OnState_UNLOAD();
            }
            else if (m_EntityState == EntityState.MINE_IDENTIFIED_NONMINE)
            {
                OnState_MINE_IDENTIFIED_NONMINE();
            }
            else if (m_EntityState == EntityState.DEPTHMODE_ALT)
            {
                OnState_DEPTHMODE_ALT();
            }
            else if (m_EntityState == EntityState.DEPTHMODE_DEPTH)
            {
                OnState_DEPTHMODE_DEPTH();
            }
            else if (m_EntityState == EntityState.SURFACE)
            {
                OnState_SURFACE();
            }
            else if (m_EntityState == EntityState.DIVE)
            {
                OnState_DIVE();
            }
            else if (m_EntityState == EntityState.CIRCLE)
            {
                OnState_CIRCLE();
            }
            else if (m_EntityState == EntityState.LOOP)
            {
                OnState_LOOP();
            }

            m_PreviousEntityState = m_EntityState;
        }
    }

    //public void EntityUpdateState()
    //{
    //    if (m_EntityState != m_PreviousEntityState)
    //    {
    //        Debug.Log(m_EntityName + "(" + m_EntityID + ") was assigned state: " + m_EntityState as string + "(Was " + m_EntityState as string);

    //        if (m_EntityState == EntityState.DEFAULT_POSUPDATE)
    //        {
    //            On_DEFAULT_POSUPDATE();
    //        }
    //        else if (m_EntityState == EntityState.DETECTION)
    //        {
    //            OnState_DETECTION();
    //        }
    //        else if (m_EntityState == EntityState.EFFECTOR_COMPLETE)
    //        {
    //            OnState_EFFECTOR_COMPLETE();
    //        }
    //        else if (m_EntityState == EntityState.EFFECTOR_LAUNCHING)
    //        {
    //            OnState_EFFECTOR_LAUNCHING();
    //        }
    //        else if (m_EntityState == EntityState.EFFECTOR_MISSED)
    //        {
    //            OnState_EFFECTOR_MISSED();
    //        }
    //        else if (m_EntityState == EntityState.MINE_ACTUATED)
    //        {
    //            OnState_MINE_ACTUATED();
    //        }
    //        else if (m_EntityState == EntityState.MINE_CLASSIFIED)
    //        {
    //            OnState_MINE_CLASSIFIED();
    //        }
    //        else if (m_EntityState == EntityState.MINE_DETECTED)
    //        {
    //            OnState_MINE_DETECTED();
    //        }
    //        else if (m_EntityState == EntityState.MINE_NEUTRALIZED)
    //        {
    //            OnState_MINE_NEUTRALIZED();
    //        }
    //        else if (m_EntityState == EntityState.N81DEMOAQUAD_ARRIVED_AT_SHIP)
    //        {
    //            OnState_N81DEMOAQUAD_ARRIVED_AT_SHIP();
    //        }
    //        else if (m_EntityState == EntityState.OBJECT_DISABLED)
    //        {
    //            OnState_OBJECT_DISABLED();
    //        }
    //        else if (m_EntityState == EntityState.SYSTEM_TURNED_ON)
    //        {
    //            OnState_SYSTEM_TURNED_ON();
    //        }

    //        m_PreviousEntityState = m_EntityState;
    //    }
    //}

    public virtual void On_DEFAULT_POSUPDATE()
    {

    }

    public virtual void OnState_DETECTION()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_EFFECTOR_COMPLETE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_EFFECTOR_LAUNCHING()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_EFFECTOR_MISSED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_ACTUATED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_CLASSIFIED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_DETECTED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_REACQUIRED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_IDENTIFIED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_NEUTRALIZED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_N81DEMOAQUAD_ARRIVED_AT_SHIP()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_DEFAULT_POSUPDATE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_OBJECT_DISABLED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        DisableEntity();
    }

    public virtual void OnState_SYSTEM_TURNED_ON()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_SENSORS_ACTIVATED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        SetSensorsActive(true);
    }

    public virtual void OnState_SENSORS_DEACTIVATED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        SetSensorsActive(false);
    }

    public virtual void SetSensorsActive(bool a_Bool)
    {
        Debug.Log("[Entity] Setting Sensors Active to: " + a_Bool);

        if (m_HasSensors)
        {
            m_SensorsActive = a_Bool;

            if (m_Sensors.Count > 0)
            {
                foreach (GameObject l_Sensor in m_Sensors)
                {
                    l_Sensor.SetActive(m_SensorsActive);
                }
            }
        }
    }

    public virtual void SetSensorsVisible(bool a_Bool)
    {
        Debug.Log("[Entity] Setting Sensors Active to: " + a_Bool);

        if (m_HasSensors)
        {
            m_SensorsActive = a_Bool;

            if (m_Sensors.Count > 0)
            {
                foreach (GameObject l_Sensor in m_Sensors)
                {
                    Renderer l_Rend = l_Sensor.GetComponent<Renderer>();

                    if (l_Rend)
                    {
                        l_Rend.enabled = a_Bool;
                    }

                }
            }
        }
    }

    public virtual void OnState_SYSTEM_LAUNCHED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_SYSTEM_COMPLETE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_SWITCH_LOADOUT_1()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        ActivateLoadout(0);
    }

    public virtual void OnState_SWITCH_LOADOUT_2()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        ActivateLoadout(1);
    }

    public virtual void OnState_SWITCH_LOADOUT_3()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_TURNING()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

    }

    public virtual void OnState_STOPPED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_PAUSED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        if (m_EntityState == EntityState.PAUSED)
        {
            Pause(m_TimeToPause / SimulatorSettings.getSimSpeed());
        }
    }

    public virtual void OnState_STARTED()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

    }

    public virtual void OnState_WAYPOINTS_START()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        if (m_EntityType == "HELICOPTER")
        {
            m_RigidBody.isKinematic = true;
            m_RigidBody.useGravity = false;
        }

        if (m_WaypointModule)
        {
            if (!HasPreviousUpdate())
            {
                Debug.Log("Has no previous update");
            }
            else
            {
                Debug.Log("Has previous update");
            }

            if (m_WaypointModule.m_Waypoints.Count > 0)
            {
                if (m_WasStopped)
                {
                    m_WaypointModule.m_Waypoints[m_WaypointModule.m_CurrentWaypointIndex].Position = transform.position;
                    if (m_PreviousSimUpdate != null) m_PreviousSimUpdate.Position = transform.position;

                    m_WasStopped = false;
                }
            }
            m_WaypointModule.m_Playing = true;
            m_WaypointModule.m_Speed = 0;
            if ((m_DesiredSpeed == 0) || (m_DesiredSpeed == -1)) m_DesiredSpeed = m_MaxSpeed;
            //m_PositionUpdatesStarted = true;
            //m_PreviousSimUpdate = m_WaypointModule.m_Waypoints[m_WaypointModule.m_CurrentWaypointIndex];
            //m_PreviousSimUpdate.Position = transform.position;
            //m_PreviousXYZDestination = transform.position;
            //m_CurrentXYZDestination = transform.position;
        }

        m_ControlType = EntityControlType.WAYPOINT;
        m_UseExternalPhysics = true;
        m_WaypointsStarted = true;
    }

    public virtual void OnState_WAYPOINTS_STOP()
    {
        if (m_EntityID == 0) return;

        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        m_ControlType = EntityControlType.NONE;
        m_WaypointsStarted = false;

        if (m_WaypointModule)
        {
            m_WaypointModule.m_Playing = false;
        }

        m_WasStopped = true;
    }

    public virtual void OnState_MOVE_TO_THREAT()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

    }

    public virtual void OnState_RETURN_TO_HOST()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

    }

    public virtual void OnState_ATTACH()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

    }

    public virtual void OnState_DETTACH()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

    }

    public virtual void DetonateEntity()
    {
        Debug.Log("Entity::DetonateEntity()");
        Instantiate(SimulatorSettings.getAnimationManager().getPrefabObject("Explosion"), transform.position, transform.rotation);
        SimulatorSettings.getEntityList().removeEntity(m_EntityID);
    }

    public virtual void DisableEntity()
    {
        Debug.Log("Entity::DisableEntity() (" + m_EntityName + ")");
    }

    public void SetActive(bool a_Bool)
    {
        //if (a_Bool) Debug.Log("[Entity] " + m_EntityName + " has been set active");
        //else Debug.Log("[Entity] " + m_EntityName + " has been set inactive");

        gameObject.SetActive(a_Bool);
    }

    public void Destroy()
    {
        m_QueuedForDestruction = true;
        Destroy(this.gameObject);
    }

    public virtual void toggleVisibileInScene()
    {
        setVisibleInScene(!m_VisibleInScene);
    }

    public virtual void setVisibleInScene(bool a_Bool)
    {
        //Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ")setVisibleInScene(" + a_Bool + ")");
        m_VisibleInScene = a_Bool;
        //m_ModelLoader.setModelVisible(m_VisibleInScene);
        m_ControlObjects.setCollidersEnabled(m_VisibleInScene);

        Renderer[] renderers = GetComponentsInChildren<Renderer>();

        foreach (Renderer child in renderers)
        {
            if (child)
            {
                child.enabled = a_Bool;
            }
        }

        m_PreviousVisibleInScene = m_VisibleInScene;
    }

    public void setCollidersActive(bool a_Bool)
    {
        m_ControlObjects.setCollidersEnabled(a_Bool);
    }

    public bool IsBroadcastingToEntityType(int a_SMMTTID)
    {
        bool l_Ret = false;

        foreach (int l_SMMTTID in m_EntitiesBroadcastingTo.Keys)
        {
            if (l_SMMTTID == a_SMMTTID)
            {
                l_Ret = true;
            }
        }

        return l_Ret;
    }

    public bool IsReceivingFromEntityType(int a_SMMTTID)
    {
        bool l_Ret = false;

        foreach (int l_SMMTTID in m_EntitiesReceivingFrom.Keys)
        {
            if (l_SMMTTID == a_SMMTTID)
            {
                l_Ret = true;
            }
        }

        return l_Ret;
    }

    public virtual void SetPosition(Vector3 a_Position)
    {
        if (m_EntityID == 12)
            Debug.Log(m_EntityID + " SetPosition: " + a_Position.x.ToString("F8") + " " + a_Position.y.ToString("F8") + " " + a_Position.z.ToString("F8"));

        transform.position = a_Position;
        currentXYZPosition = a_Position;

        currentGPSPosition = GPSEncoder.USCToGPS(a_Position);
        previousGPSPosition = currentGPSPosition;

        m_CurrentAltitude = a_Position.y;
    }

    public virtual void ArrivedAtLocation(Vector3 a_Position)
    {
        //transform.position = a_Position;

        currentGPSPosition = GPSEncoder.USCToGPS(a_Position);
        previousGPSPosition = currentGPSPosition;

        m_PreviousSimUpdate = m_CurrentSimUpdate;

        m_PreviousXYZDestination = transform.position;

        m_CurrentAltitude = a_Position.y;
    }

    public virtual void SetXZPosition(float a_X, float a_Z)
    {
        currentXYZPosition.x = a_X;
        currentXYZPosition.z = a_Z;

        SetPosition(currentXYZPosition);
    }

    public virtual void SetElevation(float a_Elevation)
    {
        Vector3 l_Position = transform.position;
        l_Position.y = a_Elevation;
        transform.position = l_Position;
    }

    public virtual void SetRotation(Vector3 a_Rotation, bool a_UpdateDesiredValues = true)
    {
        SetRotation(Quaternion.Euler(a_Rotation), a_UpdateDesiredValues);
    }

    public virtual void SetRotation(Quaternion a_Rotation, bool a_UpdateDesiredValues = true)
    {
        transform.rotation = a_Rotation;

        m_CurrentPitch = a_Rotation.eulerAngles.x;
        m_CurrentHeading = a_Rotation.eulerAngles.y;
        m_CurrentRoll = a_Rotation.eulerAngles.z;

        if (a_UpdateDesiredValues)
        {
            m_DesiredPitch = a_Rotation.eulerAngles.x;
            m_DesiredHeading = a_Rotation.eulerAngles.y;
            m_DesiredRoll = a_Rotation.eulerAngles.z;
        }
    }

    public virtual void InitialPlacement(Vector3 a_Position)
    {
        InitialPlacement(a_Position, Vector3.zero);
    }

    public virtual void InitialPlacement(Vector3 a_Position, Vector3 a_Rotation)
    {
        Vector3 l_FinalPosition = a_Position;
        Vector3 l_FinalRotation = a_Rotation;

        SetPosition(l_FinalPosition);
        SetRotation(l_FinalRotation);
    }

    public Transform GetAirCommunicationPoint()
    {
        Transform l_Ret = null;

        if (m_AirCommPoint != null)
        {
            l_Ret = m_AirCommPoint;
        }
        else
        {
            GameObject l_NewAirCommPoint = new GameObject("AirCommPoint");
            l_NewAirCommPoint.transform.SetParent(m_ControlObjects.transform);

            if (m_labelPosition)
            {
                l_NewAirCommPoint.transform.position = m_labelPosition.transform.position;
            }
            else
            {
                l_NewAirCommPoint.transform.localPosition = new Vector3(0, m_ModelBounds.extents.y, 0);
            }

            l_Ret = l_NewAirCommPoint.transform;
        }

        return l_Ret;
    }

    public Transform GetWaterCommunicationPoint()
    {
        Transform l_Ret = null;

        if (m_WaterCommPoint != null)
        {
            l_Ret = m_WaterCommPoint;
        }
        else
        {
            GameObject l_NewWaterCommPoint = new GameObject("WaterCommPoint");
            l_NewWaterCommPoint.transform.SetParent(m_ControlObjects.transform);

            l_NewWaterCommPoint.transform.localPosition = new Vector3(0, -1 * m_ModelBounds.extents.y, 0);

            l_Ret = l_NewWaterCommPoint.transform;
        }

        return l_Ret;
    }

    public virtual bool AttachToEntity(Entity a_Entity)
    {
        Debug.Log("Entity::AttachToEntity() base function called on: " + m_EntityName + " by: " + a_Entity.m_EntityName);

        if (typeof(Air).IsAssignableFrom(this.GetType()))
        {
            transform.SetParent(a_Entity.m_AirVehicleAttachPoint);
            SetRotation(a_Entity.m_AirVehicleAttachPoint.rotation);
        }
        else if (typeof(Surface).IsAssignableFrom(this.GetType()))
        {
            transform.SetParent(a_Entity.m_SurfaceVehicleAttachPoint);
            SetRotation(a_Entity.m_SurfaceVehicleAttachPoint.rotation);

            a_Entity.InformParentOfAttach(this);
        }

        return true;
    }

    public virtual bool DettachFromEntity(Entity a_Entity)
    {
        Debug.Log("Entity::DettachFromEntity() base function called on: " + m_EntityName + " by: " + a_Entity.m_EntityName);
        return true;
    }

    public virtual bool SetParent(Entity a_Entity)
    {
        if (a_Entity != null)
        {
            if (!m_AttachedEntities.Contains(a_Entity))
            {
                Debug.Log("Entity::SetParent(" + a_Entity.m_EntityName + ")");

                m_Transform.SetParent(a_Entity.m_Transform);
                a_Entity.m_AttachedEntities.Add(this);
                a_Entity.InformParentOfAttach(this);
            }
        }
        else
        {
            SimulatorSettings.getEntityList().DettaachFromParent(this);
        }

        return true;
    }

    public virtual void InformParentOfAttach(Entity a_Entity)
    {
        if (!m_Loadouts.Contains(a_Entity.gameObject))
        {
            AddToLoadouts(a_Entity);
        }
    }

    public void AddToLoadouts(Entity a_Entity)
    {
        Debug.Log(m_EntityName + " is attempting to add " + a_Entity.m_EntityName + "to its loadouts");
        if (typeof(Air).IsAssignableFrom(a_Entity.GetType()))
        {
            //Debug.Log("Add failed due to type air");
            return;
        }

        if (!a_Entity.m_EntityInitialized) a_Entity.ExternalStart();

        if (!m_Loadouts.Contains(a_Entity.gameObject)) m_Loadouts.Add(a_Entity.gameObject);

        a_Entity.SetActive(true);
        a_Entity.AttachToEntity(this);

        if (m_CurrentLoadout != (m_Loadouts.Count - 1))
        {
            a_Entity.SetActive(false);
        }

        Debug.Log(m_EntityName + " success");

        //a_Entity.SetActive(false);
    }

    public virtual bool DettachFromParent()
    {
        SimulatorSettings.getEntityList().DettaachFromParent(this);
        m_RigidBody.isKinematic = false;
        return true;
    }

    public void ClearInputs()
    {
        m_LHorizontalInput = 0;
        m_LVerticalInput = 0;
        m_RHorizontalInput = 0;
        m_RVerticalInput = 0;
        m_InputAltitude = 0;
        m_InputRudder = 0;

    }

    void OnGUI()
    {
        if (m_UIManager)
        {
            //Debug.DrawLine(m_labelPosition.transform.position, m_labelPosition.transform.position + new Vector3(0, 10, 0), Color.red);
            if (m_UIManager.m_DisplayEntityLabels && m_IsInView)
            {
                var position = Camera.main.WorldToScreenPoint(m_labelPosition.transform.position);
                var textSize = GUI.skin.label.CalcSize(new GUIContent(m_EntityName));
                GUI.Label(new Rect(position.x, Screen.height - position.y, textSize.x, textSize.y), m_EntityName);
            }
        }
    }

    void OnBecameVisible()
    {
        m_IsInView = true;
    }

    void OnBecameInvisible()
    {
        m_IsInView = false;
    }

    public bool LoadGhost()
    {
        if (m_ModelLoader == null)
        {
            m_ModelLoader = gameObject.GetComponentInChildren<ModelLoader>();
        }
        if (m_ModelLoader == null) return DebugErrorMissingLink(m_ModelLoader.GetType().ToString());

        //

        if (SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID).Valid)
        {
            m_ModelRotation = SimulatorSettings.getModelManager().getModelInformation(m_EntitySMMTTID).Rotation;
        }

        m_ModelLoader.m_ModelName = m_EntityModelName;
        m_ModelLoader.m_Controller = this;
        m_ModelLoader.m_ModelRotation = m_ModelRotation;
        m_ModelLoader.ExternalStart();

        setVisibleInScene(true);

        return true;
    }

    public virtual void CreateContextMenu()
    {

        m_ContextMenuItems = new List<ContextMenuItem>();

        System.Action<Image> EntityName = new System.Action<Image>(EntityNameAction);
        System.Action<Image> StartWaypoints = new System.Action<Image>(StartWaypointsAction);
        System.Action<Image> StopWaypoints = new System.Action<Image>(StopWaypointsAction);
        System.Action<Image> Attach = new System.Action<Image>(AttachAction);
        System.Action<Image> Dettach = new System.Action<Image>(DettachAction);
        System.Action<Image> Follow = new System.Action<Image>(FollowAction);
        System.Action<Image> BreakFollow = new System.Action<Image>(BreakFollowAction);
        System.Action<Image> SwitchLoadout = new System.Action<Image>(SwitchLoadoutAction);
        System.Action<Image> Remove = new System.Action<Image>(RemoveAction);
        System.Action<Image> Close = new System.Action<Image>(CloseAction);

        ContextMenuItem l_Name = new ContextMenuItem(m_ModelLoader.m_ModelName, SimulatorSettings.getUIManager().m_ContextMenuButton, EntityNameAction);
        ColorBlock l_Color = new ColorBlock();
        l_Color.normalColor = Color.white;
        l_Color.colorMultiplier = 1;
        l_Color.highlightedColor = Color.grey;
        l_Color.pressedColor = Color.blue;
        l_Name.button.colors = l_Color;

        m_ContextMenuItems.Add(l_Name);

        if (m_ControlObjects.HasControlObject("WaypointModule"))
        {
            if (!m_WaypointsStarted)
            {
                m_ContextMenuItems.Add(new ContextMenuItem("Start Waypoints", SimulatorSettings.getUIManager().m_ContextMenuButton, StartWaypoints));
            }
            else
            {
                m_ContextMenuItems.Add(new ContextMenuItem("Stop Waypoints", SimulatorSettings.getUIManager().m_ContextMenuButton, StopWaypointsAction));
            }
        }

        if (m_Loadouts.Count > 1)
        {
            m_ContextMenuItems.Add(new ContextMenuItem("SwitchLoadout", SimulatorSettings.getUIManager().m_ContextMenuButton, SwitchLoadout));
        }

        if (SimulatorSettings.getDirector().m_CurrentEntity == this)
        {
            m_ContextMenuItems.Add(new ContextMenuItem("Dettach", SimulatorSettings.getUIManager().m_ContextMenuButton, Dettach));
        }
        else
        {
            m_ContextMenuItems.Add(new ContextMenuItem("Attach", SimulatorSettings.getUIManager().m_ContextMenuButton, Attach));
        }

        if (!m_IsBeingFollowed) m_ContextMenuItems.Add(new ContextMenuItem("Follow", SimulatorSettings.getUIManager().m_ContextMenuButton, Follow));
        else m_ContextMenuItems.Add(new ContextMenuItem("BreakFollow", SimulatorSettings.getUIManager().m_ContextMenuButton, BreakFollow));

        m_ContextMenuItems.Add(new ContextMenuItem("Remove", SimulatorSettings.getUIManager().m_ContextMenuButton, Remove));
        m_ContextMenuItems.Add(new ContextMenuItem("Close", SimulatorSettings.getUIManager().m_ContextMenuButton, Close));
    }

    public void EntityNameAction(Image contextPanel)
    {

    }

    public void SwitchLoadoutAction(Image contextPanel)
    {
        Debug.Log("SwitchLoadout");
        //Destroy(contextPanel.gameObject);

        ActivateNextLoadout();

        CloseContextMenu(contextPanel);
    }

    public void ActivateNextLoadout()
    {
        int l_LoadoutNum = m_CurrentLoadout + 1;

        if (l_LoadoutNum >= m_Loadouts.Count)
        {
            l_LoadoutNum = 0;
        }

        ActivateLoadout(l_LoadoutNum);
    }

    public void TriggerContextMenu(Vector3 a_HitPosition)
    {
        //Debug.Log("TriggerContextMenu(): " + a_HitPosition);

        if (Input.GetMouseButtonDown(1) && !SimulatorSettings.getUIManager().m_ContextMenuOpen)
        {
            CreateContextMenu();

            int hoveredDisplay = Common.GetHoveredDisplay();

            if (hoveredDisplay < SimulatorSettings.getNumberOfCameras())
            {
                Vector3 pos = SimulatorSettings.getDirector().getCamera(hoveredDisplay).WorldToScreenPoint(a_HitPosition);
                ContextMenu.Instance.CreateContextMenu(m_ContextMenuItems, new Vector2(pos.x, pos.y), hoveredDisplay);

                //Debug.Log("Context Menu Open");
                SimulatorSettings.getUIManager().m_ContextMenuOpen = true;
                SimulatorSettings.getDirector().m_PreviousEnableMouseViewRotation = SimulatorSettings.getDirector().m_EnableMouseViewRotation;
                SimulatorSettings.getDirector().m_EnableMouseViewRotation = false;
            }

            //Vector3 pos = Camera.main.WorldToScreenPoint(transform.position);
            //ContextMenu.Instance.CreateContextMenu(m_ContextMenuItems, new Vector2(pos.x, pos.y));
        }

    }

    public void CloseContextMenu(Image contextPanel)
    {
        //Destroy(contextPanel.gameObject);
        //SimulatorSettings.getUIManager().m_ContextMenuOpen = false;
        //SimulatorSettings.getUIManager().m_ContextMenu = null;
        SimulatorSettings.getUIManager().DestroyContextMenu();
    }

    public void StartWaypoints()
    {
        m_PreviousSimUpdate = new SimUpdate();
        m_PreviousSimUpdate.Position = transform.position;
        m_PreviousSimUpdate.GPS.lat = currentGPSPosition.x;
        m_PreviousSimUpdate.GPS.lon = currentGPSPosition.y;
        m_PreviousSimUpdate.GPS.alt = transform.position.y;
        m_PreviousSimUpdate.Rotation = transform.rotation.eulerAngles;
        m_PreviousSimUpdate.State = EntityState.DEFAULT_POSUPDATE;
        m_PreviousSimUpdate.Type = UpdateType.POSITION;

        if (typeof(Air).IsAssignableFrom(this.GetType()))
        {
            m_IsFalling = false;
            m_RigidBody.isKinematic = true;
        }

        setState(EntityState.WAYPOINTS_START);
    }

    public void StartWaypointsAction(Image contextPanel)
    {
        Debug.Log("StartingWaypoint");

        StartWaypoints();
        CloseContextMenu(contextPanel);

        //CreateContextMenu();
    }

    public void StopWaypoints()
    {
        setState(EntityState.WAYPOINTS_STOP);
    }

    public void StopWaypointsAction(Image contextPanel)
    {
        Debug.Log("StartingWaypoint");

        StopWaypoints();

        CloseContextMenu(contextPanel);
    }

    public void AttachAction(Image contextPanel)
    {
        Debug.Log("AttachAction");

        SimulatorSettings.getDirector().switchtoVehicleByID(m_EntityID);

        CloseContextMenu(contextPanel);
    }

    public void DettachAction(Image contextPanel)
    {
        Debug.Log("DettachAction");

        SimulatorSettings.getDirector().m_MainCameraDrone.transform.position = SimulatorSettings.getDirector().getMainCamera().transform.position;
        SimulatorSettings.getDirector().switchtoVehicleByID(0);

        CloseContextMenu(contextPanel);
    }

    public void FollowAction(Image contextPanel)
    {
        Debug.Log("FollowAction");

        Entity l_Source = SimulatorSettings.getDirector().getCurrentEntity();
        Entity l_Target = this;

        if (l_Source && l_Target)
        {
            if (l_Source != l_Target)
            {
                Vector3 l_Offset = l_Source.transform.position - l_Target.transform.position;
                SimulatorSettings.getAnimationManager().AddEntityFollower(l_Source, l_Target, l_Offset, false, false);
            }
        }

        CloseContextMenu(contextPanel);
    }

    public void BreakFollowAction(Image contextPanel)
    {
        Debug.Log("BreakFollowAction");

        SimulatorSettings.getAnimationManager().RemoveAllEntityFollowers();

        CloseContextMenu(contextPanel);
    }

    public void RemoveAction(Image contextPanel)
    {
        Debug.Log("Removed");

        SimulatorSettings.getEntityList().removeEntity(m_EntityID);

        CloseContextMenu(contextPanel);
    }

    public void CloseAction(Image contextPanel)
    {
        Debug.Log("Closed");

        CloseContextMenu(contextPanel);
    }

    public virtual void ExecuteSpecialAction_1()
    {
        Debug.Log("[Entity] Execute Special Action 1");

    }

    public virtual void StopSpecialAction_1()
    {
        Debug.Log("[Entity] Stop Special Action 1");

    }

    public virtual void ExecuteSpecialAction_2()
    {
        Debug.Log("[Entity] Execute Special Action 2");

    }

    public virtual void StopSpecialAction_2()
    {
        Debug.Log("[Entity] Stop Special Action 2");

    }

    public virtual void ExecuteSpecialAction_3()
    {
        Debug.Log("[Entity] Execute Special Action 3");

    }

    public virtual void StopSpecialAction_3()
    {
        Debug.Log("[Entity] Stop Special Action 3");

    }

    public virtual void ExecuteSpecialAction_4()
    {
        Debug.Log("[Entity] Execute Special Action 4");

    }

    public virtual void StopSpecialAction_4()
    {
        Debug.Log("[Entity] Stop Special Action 4");

    }

    public void SetExternalPhysics(int a_ExtPhysics)
    {
        if (a_ExtPhysics == 0) m_UseExternalPhysics = false;
        else m_UseExternalPhysics = true;
    }

    public void SetExternalPhysics(bool a_ExtPhysics)
    {
        m_UseExternalPhysics = a_ExtPhysics;
    }

    public void SetStatusFlag(int a_Flag)
    {
        m_StatusFlag = a_Flag;
    }

    public virtual void OnState_IDENTIFY()
    {

    }

    public virtual void OnState_CLASSIFY()
    {

    }

    public virtual void OnState_REACQUIRE()
    {

    }

    public virtual void OnState_NEUTRALIZE()
    {

    }

    public virtual void OnState_SPECIAL_ACTION_1()
    {
        ExecuteSpecialAction_1();
    }

    public virtual void OnState_SPECIAL_ACTION_2()
    {
        ExecuteSpecialAction_2();
    }

    public virtual void OnState_PASS_WAYPOINTS()
    {

    }

    public virtual void OnState_DROP_NEARSURFACEMINE()
    {
        Debug.Log("Entity::OnState_DROP_NEARSURFACEMINE() (" + m_EntityName + ")");

        if (m_MineLaunchPoint)
        {
            Debug.Log("Position: (" + m_MineLaunchPoint.position + ")");
            SimulatorSettings.getEntityList().createAndAddEntity(1, 2752, m_MineLaunchPoint.position, true);
        }
    }

    public virtual void OnState_DROP_VOLUMEMINE()
    {
        Debug.Log("Entity::OnState_DROP_VOLUMEMINE() (" + m_EntityName + ")");

        if (m_MineLaunchPoint)
        {
            Debug.Log("Position: (" + m_MineLaunchPoint.position + ")");
            SimulatorSettings.getEntityList().createAndAddEntity(1, 2753, m_MineLaunchPoint.position, true);
        }
    }

    public virtual void OnState_DROP_BOTTOMMINE()
    {
        Debug.Log("Entity::OnState_DROP_BOTTOMMINE() (" + m_EntityName + ")");
        if (m_MineLaunchPoint)
        {
            Debug.Log("Position: (" + m_MineLaunchPoint.position + ")");
            SimulatorSettings.getEntityList().createAndAddEntity(1, 2750, m_MineLaunchPoint.position, true);
        }
    }

    public virtual void OnState_DROP_SURFACEMINE()
    {
        Debug.Log("Entity::OnState_DROP_SURFACEMINE() (" + m_EntityName + ")");
        if (m_MineLaunchPoint)
        {
            Debug.Log("Position: (" + m_MineLaunchPoint.position + ")");
            SimulatorSettings.getEntityList().createAndAddEntity(1, 2755, m_MineLaunchPoint.position, true);
        }
    }

    public virtual void OnState_START_MINELINE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_STOP_MINELINE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_LAND()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_LOAD()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_UNLOAD()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_MINE_IDENTIFIED_NONMINE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_DEPTHMODE_ALT()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        m_DepthMode = DepthMode.ALTITUDE;
    }

    public virtual void OnState_DEPTHMODE_DEPTH()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        m_DepthMode = DepthMode.DEPTH;
    }

    public virtual void OnState_SURFACE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_DIVE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_CIRCLE()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");
    }

    public virtual void OnState_LOOP()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        if(m_WaypointModule)
        {
            if(m_WaypointModule.m_WaypointModuleMode == WaypointModuleMode.REPEAT)
            {
                m_WaypointModule.m_CurrentWaypointIndex = 0;
            }
        }
    }

    public virtual void UnloadFromCurrentEntity(Entity a_Child)
    {

    }

    public virtual void LoadOntoCurrentEntity(Entity a_Child, Entity a_Parent)
    {

    }

    public void ClearWaypoints()
    {
        if (m_WaypointModule)
        {
            m_WaypointModule.ClearWaypoints();
        }
    }

    public virtual void ChildUpdate()
    {

    }

    public virtual void ActivateLoadout(Entity a_Entity)
    {
        for (int i = 0; i < m_Loadouts.Count; i++)
        {
            if (m_Loadouts[i] == a_Entity.gameObject)
            {
                ActivateLoadout(i);
            }
        }
    }
    public virtual void ActivateLoadout(int a_LoadoutNum)
    {
        for (int i = 0; i < m_Loadouts.Count; i++)
        {
            Entity l_Entity = m_Loadouts[i].GetComponent<Entity>();

            if (l_Entity)
            {
                if (i == a_LoadoutNum)
                {
                    l_Entity.SetActive(true);

                    l_Entity.setVisibleInScene(true);

                    if (!SimulatorSettings.getEntityList().containsID(l_Entity.m_EntityID))
                    {
                        SimulatorSettings.getEntityList().addEntity(l_Entity);
                    }

                    if (typeof(Air).IsAssignableFrom(l_Entity.GetType()))
                    {
                        m_Loadouts[i].transform.position = m_AirVehicleAttachPoint.position;
                        m_Loadouts[i].transform.rotation = m_AirVehicleAttachPoint.rotation;
                    }
                    else if (typeof(Surface).IsAssignableFrom(l_Entity.GetType()))
                    {
                        m_Loadouts[i].transform.position = m_SurfaceVehicleAttachPoint.position;
                        m_Loadouts[i].transform.rotation = m_SurfaceVehicleAttachPoint.rotation;
                    }

                    m_CurrentLoadout = a_LoadoutNum;

                    if (l_Entity)
                    {
                        m_ActiveSystem = l_Entity;

                        m_ActiveSensor = m_ActiveSystem as Sensor;
                    }
                }
                else
                {
                    l_Entity.setVisibleInScene(true);
                    l_Entity.SetActive(false);
                }
            }
        }
    }

    public void DeactivateLoadouts()
    {
        ActivateLoadout(-1);
    }

    public virtual void LaunchVehicle()
    {
        //SetParent(null);
        //m_IsFalling = true;
        //m_IsLoaded = false;
    }

    public void SetDetectedColor()
    {
        Material l_Mat = SimulatorSettings.getAnimationManager().m_TargetNonMineMaterial;

        if (typeof(Mine).IsAssignableFrom(this.GetType()))
        {
            if (!typeof(MILCO).IsAssignableFrom(this.GetType()))
            {
                l_Mat = SimulatorSettings.getAnimationManager().m_TargetMineMaterial;
            }

            foreach (Renderer l_Rend in m_ModelLoader.GetComponentsInChildren<Renderer>())
            {
                //m_OriginalMaterials.Add(l_Rend, l_Rend.material);
                m_ModelLoader.GetComponentInChildren<Renderer>().material = l_Mat;
            }
        }
    }

    public void RestoreOriginalColor()
    {
        foreach (KeyValuePair<Renderer, Material> l_Pair in m_OriginalMaterials)
        {
            l_Pair.Key.material = l_Pair.Value;
        }
    }

    public void ClearParticles()
    {
        foreach (KeyValuePair<string, ParticleSystem> l_System in m_ParticleList)
        {
            if (l_System.Value != null)
            {
                l_System.Value.Clear(true);
                l_System.Value.Stop();
            }
        }
    }

    public void StartParticles()
    {
        foreach (KeyValuePair<string, ParticleSystem> l_System in m_ParticleList)
        {
            if (l_System.Value != null)
            {
                l_System.Value.Play();
            }
        }
    }

    public void RecalculateTrail(Vector3 a_ChangeInPosition)
    {
        if (m_EntityTrail != null)
        {
            //Debug.Log("(Entity " + m_EntityID + ") Recalculating Entity Trail - Delta Pos: " + a_ChangeInPosition);

            if (m_EntityTrail.m_TrailRenderer)
            {
                Vector3[] l_Positions = new Vector3[m_EntityTrail.m_TrailRenderer.positionCount];
                m_EntityTrail.m_TrailRenderer.GetPositions(l_Positions);

                for (int i = 0; i < l_Positions.Length; i++)
                {
                    l_Positions[i] += a_ChangeInPosition;
                }

                m_EntityTrail.m_TrailRenderer.SetPositions(l_Positions);
            }
        }
    }

    public void SetPreviousUpdate(SimUpdate a_Update)
    {
        if (a_Update != null)
        {
            //Debug.Log("Set Previous Update - Pos: " + a_Update.Position + " - GPS: " + a_Update.GPS.lat + " " + a_Update.GPS.lon);
            m_PreviousSimUpdate = a_Update;
        }
    }

    public bool HasPreviousUpdate()
    {
        if (m_PreviousSimUpdate != null) return true;
        else return false;
    }

    public void SetPreviousUpdateAlt(float a_Alt)
    {
        if (m_PreviousSimUpdate != null)
        {
            m_PreviousSimUpdate.GPS.alt = a_Alt;
            m_PreviousSimUpdate.Position.y = a_Alt;
        }
    }

    public Vector3 GetPreviousUpdateXYZ()
    {
        if (m_PreviousSimUpdate != null)
        {
            return m_PreviousSimUpdate.Position;
        }

        return Vector3.zero;
    }

    public bool QueryPreviousUpdateType(UpdateType a_Type)
    {
        if (m_PreviousSimUpdate != null)
        {
            if (m_PreviousSimUpdate.Type == a_Type) return true;
        }

        return false;
    }

    public void SetPreviousUpdatePosition(Vector3 a_Pos)
    {
        if (m_PreviousSimUpdate != null)
        {
            m_PreviousSimUpdate.Position = a_Pos;
        }
    }

    public bool CompareGPSToPreviousUpdate(double a_Lat, double a_Lon)
    {
        if (m_PreviousSimUpdate != null)
        {
            if ((m_PreviousSimUpdate.GPS.lat == a_Lat) && (m_PreviousSimUpdate.GPS.lon == a_Lon))
            {
                return true;
            }
        }

        return false;
    }

    public virtual void MovementEnabled(bool a_Bool)
    {

    }

    public virtual void FireWeapon()
    {

    }
}
