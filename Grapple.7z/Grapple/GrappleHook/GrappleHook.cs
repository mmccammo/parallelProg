﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrappleHook : Weapon
{
    [Header("GrappleHook Module")]
    public Rigidbody m_HookRigidBody;
    public Transform m_HookTransform;
    public float m_FiringForce;
    public Vector3 m_RelativeFiringDirectionVector;
    public ForceMode m_ForceMode;
    public Vector3 m_FiringForceVector;
    public WrappingRopeLibrary.Scripts.Rope m_Rope;
    public WrappingRopeLibrary.Enums.AnchoringMode m_DefaultAnchoringMode = WrappingRopeLibrary.Enums.AnchoringMode.None;
    public Transform m_AttachedTransform;
    public Rigidbody m_AttachedRB;
    public Entity m_AttachedEntity;
    public Collider m_AttachedCollider;
    public Vector3 m_AttachedPosition;
    public Quaternion m_AttachedRotation;
    public Collider m_HookCollider;
    
    [Header("Options")]
    public bool m_RotateAttachedObject;
    public float m_MaxRopeLength;
    public float m_TimeToPreventReattach = 1;
    public float m_RetractionSpeed = 2f;

    [Header("States")]
    public bool m_Loaded;
    public bool m_FullyExtended;
    public bool m_Attached;
    public bool m_ReadyToAtach;
    public bool m_Retracting;
    public bool m_Extending;
    public float m_CurrentRopeLength;
    public float m_Timer;

    [Header("Debug")]
    public bool m_OriginalAttachedObjectGravity;
    public bool m_OriginalAttachedObjectKinematic;
    public float m_OriginalHookMass;
    public float m_OriginalHookDrag;
    public float m_OriginalHookAngDrag;
    public bool m_OriginalHookGravity;
    public bool m_OriginalHookKinematic;

    void Start()
    {
        BaseClass_Start();
        m_HookRigidBody.isKinematic = true;
        SaveOriginalHookValues();
        LoadHook();
    }


    void Update()
    {
        if (!m_ReadyToAtach)
        {
            m_Timer += Time.deltaTime;

            if (m_Timer > m_TimeToPreventReattach)
            {
                m_ReadyToAtach = true;
                m_Timer = 0;
            }


        }
        if (m_Fired)
        {
            UpdateRopeLength();

            if (!m_FullyExtended)
            {
                if (m_CurrentRopeLength > m_MaxRopeLength)
                {
                    m_Rope.AnchoringMode = WrappingRopeLibrary.Enums.AnchoringMode.ByBackEnd;
                    m_FullyExtended = true;
                }

                if(m_HookRigidBody)
                {
                    //m_HookTransform.rotation = Quaternion.Euler(m_HookRigidBody.velocity);
                    m_HookTransform.rotation = Quaternion.LookRotation(m_HookRigidBody.velocity, Vector3.up);
                }
            }
            
        }

        if(m_Attached)
        {
            if(m_AttachedRB)
            {
                if(m_RotateAttachedObject)
                {
                    //m_AttachedTransform.rotation = Quaternion.LookRotation(m_AttachedTransform.position - this.transform.position);
                    m_HookTransform.rotation = Quaternion.LookRotation(m_HookTransform.position - this.transform.position);
                }
            }
        }

        if(m_Retracting)
        {
            if(m_CurrentRopeLength < 0.5f)
            {
                Reset();
                m_Retracting = false;
            }
            else
            {
                Retract();
            }
        }


        if (m_Extending)
        {
            if (m_CurrentRopeLength >= m_MaxRopeLength)
            {
                m_Extending = false;
            }
            else
            {
                Extend();
            }
        }
    }

    public void UpdateRopeLength()
    {
        m_CurrentRopeLength = Vector3.Distance(this.transform.position, m_HookTransform.position);
    }

    public void LoadHook()
    {
        m_HookRigidBody.isKinematic = true;

        RestoreOriginalHookValues();

        m_Rope.AnchoringMode = m_DefaultAnchoringMode;
        SetVisible(true);
        m_Loaded = true;
        m_Fired = false;
    }

    public void ReleaseHook()
    {
        m_HookRigidBody.isKinematic = false;
        m_Loaded = false;
    }

    public override void Fire()
    {
        if (!m_Visible) SetVisible(true);
        if (m_Loaded)
        {
            m_HookCollider.enabled = true;
            ReleaseHook();
            m_FiringForceVector = this.transform.TransformVector(m_RelativeFiringDirectionVector) * m_FiringForce;
            //Debug.Log("Firing Hook - Force: " + m_FiringForceVector + " - Kinematic: " + m_HookRigidBody.isKinematic);
            m_HookRigidBody.AddForce(m_FiringForceVector, m_ForceMode);
            m_Fired = true;

        }
    }

    public override void Reset()
    {
        if(m_AttachedTransform)
        {
            m_AttachedPosition = m_AttachedTransform.position;
            m_AttachedRotation = m_AttachedTransform.rotation;
        }

        BaseClass_Reset();
        LoadHook();

        if(m_AttachedTransform)
        {
            if(m_AttachedRB)
            {
                m_AttachedRB.isKinematic = false;
                m_AttachedRB.useGravity = m_OriginalAttachedObjectGravity;
                m_AttachedRB.isKinematic = m_OriginalAttachedObjectKinematic;
            }

            m_AttachedTransform.SetParent(null);
            m_AttachedTransform.position = m_AttachedPosition;
            m_AttachedTransform.rotation = m_AttachedRotation;

            if (m_AttachedCollider)
            {
                m_AttachedCollider.enabled = true;
            }

            if(m_AttachedEntity)
            {
                m_AttachedEntity.enabled = true;
            }

            m_AttachedEntity = null;
            m_AttachedCollider = null;
            m_AttachedRB = null;

            m_ReadyToAtach = false;
            m_Attached = false;
            m_FullyExtended = false;
            m_Timer = 0;
        }
    }

    public void SaveOriginalHookValues()
    {
        m_OriginalHookMass = m_HookRigidBody.mass;
        m_OriginalHookDrag = m_HookRigidBody.drag;
        m_OriginalHookAngDrag = m_HookRigidBody.angularDrag;
        m_OriginalHookGravity = m_HookRigidBody.useGravity;
        m_OriginalHookKinematic = m_HookRigidBody.isKinematic;
    }

    public void RestoreOriginalHookValues()
    {
        m_HookRigidBody.mass = m_OriginalHookMass;
        m_HookRigidBody.drag = m_OriginalHookDrag;
        m_HookRigidBody.angularDrag = m_OriginalHookAngDrag;
        m_HookRigidBody.useGravity = m_OriginalHookGravity;
        m_HookRigidBody.isKinematic = m_OriginalHookKinematic;
    }

    public void InformCollision(Collision a_Collision, Collider a_HookCollider)
    {
        if(m_ReadyToAtach)
        {
            UpdateRopeLength();

            if (a_Collision.gameObject.layer == LayerMask.NameToLayer("Terrain")) return;
            if (!m_Attached && (m_CurrentRopeLength <= m_MaxRopeLength))
            {
                m_HookCollider.enabled = false;
                m_HookRigidBody.isKinematic = true;
                m_HookRigidBody.useGravity = true;
                m_HookRigidBody.isKinematic = false;
                
                m_Rope.AnchoringMode = WrappingRopeLibrary.Enums.AnchoringMode.ByBackEnd;

                m_AttachedTransform = a_Collision.gameObject.transform;

                m_AttachedEntity = m_AttachedTransform.GetComponent<Entity>();

                m_AttachedCollider = a_Collision.collider;
                m_AttachedCollider.enabled = false;

                if (m_AttachedEntity)
                {
                    m_AttachedEntity.enabled = false;
                }

                m_AttachedRB = m_AttachedTransform.GetComponent<Rigidbody>();

                if (m_AttachedRB)
                {
                    m_OriginalAttachedObjectGravity = m_AttachedRB.useGravity;
                    m_OriginalAttachedObjectKinematic = m_AttachedRB.isKinematic;

                    //m_AttachedRB.isKinematic = true;

                    m_HookRigidBody.mass = m_AttachedRB.mass;
                    m_HookRigidBody.drag = m_AttachedRB.drag;
                    m_HookRigidBody.angularDrag = m_AttachedRB.angularDrag;
                }

                m_AttachedTransform.SetParent(m_HookTransform);

                m_Attached = true;
            }
        }
    }

    public override void Trigger()
    {
        if(!m_Fired)
        {
            Fire();
        }
        else
        {
            Reset();
        }
    }

    public override void StartRetract()
    {
        m_Retracting = true;
    }

    public override void StopRetract()
    {
        m_Retracting = false;
    }

    public void Retract()
    {
        Debug.Log("Retract");
        m_Rope.CutRope(m_RetractionSpeed * Time.fixedDeltaTime, WrappingRopeLibrary.Enums.Direction.FrontToBack);
    }

    public override void StartExtend()
    {
        m_Extending = true;
    }

    public override void StopExtend()
    {
        m_Extending = false;
    }

    public void Extend()
    {
        Debug.Log("Extend");
        m_Rope.CutRope(-m_RetractionSpeed * Time.fixedDeltaTime, WrappingRopeLibrary.Enums.Direction.FrontToBack);
    }
}
