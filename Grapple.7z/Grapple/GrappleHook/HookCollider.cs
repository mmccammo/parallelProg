﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HookCollider : MonoBehaviour
{
    public GrappleHook m_Parent;
    public Collider m_Collider;

    void OnCollisionEnter(Collision collision)
    {
        if (m_Parent) m_Parent.InformCollision(collision, m_Collider);
    }
}
