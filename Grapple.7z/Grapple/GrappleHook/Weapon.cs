﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public struct OriginalState
    {
        public Vector3 Position;
        public Vector3 Rotation;
        public Transform Transform;
        public Rigidbody Rigidbody;
    }

    [Header("Weapon Module")]
    public bool m_Visible;
    public GameObject m_WeaponObject;
    public List<GameObject> m_Children = new List<GameObject>();
    public List<OriginalState> m_ChildOriginalStates = new List<OriginalState>();
    public int m_NumberOfChildren;
    public bool m_Fired;

    public void BaseClass_Start()
    {
        m_NumberOfChildren = 0;

        foreach (Transform l_Child in transform)
        {
            OriginalState l_NewState;

            m_Children.Add(l_Child.gameObject);

            l_NewState.Position = l_Child.transform.localPosition;
            l_NewState.Rotation = l_Child.transform.localRotation.eulerAngles;
            l_NewState.Transform = l_Child.transform;
            l_NewState.Rigidbody = l_Child.GetComponent<Rigidbody>();

            m_ChildOriginalStates.Add(l_NewState);

            Debug.Log("Storing Local Position: " + l_NewState.Position);

            m_NumberOfChildren++;
        }

        SetVisible(m_Visible);
    }

    public virtual void Fire()
    {

    }

    public void BaseClass_Reset()
    {
        foreach(OriginalState l_State in m_ChildOriginalStates)
        {
            if(l_State.Transform)
            {
                l_State.Transform.localPosition = l_State.Position;
                l_State.Transform.localRotation = Quaternion.Euler(l_State.Rotation);

                //Debug.Log("Restoring " + gameObject.name + " to Local Position: " + l_State.Position);

                if(l_State.Rigidbody)
                {
                    l_State.Rigidbody.velocity = Vector3.zero;
                }
            }
        }
    }

    public virtual void Reset()
    {

    }

    public virtual void SetVisible()
    {
        SetVisible(!m_Visible);
    }

    public virtual void Trigger()
    {
        
    }

    public virtual void StartRetract()
    {

    }

    public virtual void StopRetract()
    {

    }

    public virtual void StartExtend()
    {

    }

    public virtual void StopExtend()
    {

    }

    public virtual void SetVisible(bool a_Bool)
    {
        m_Visible = a_Bool;

        foreach(GameObject l_Child in m_Children)
        {
            l_Child.SetActive(m_Visible);
        }
    }
}
