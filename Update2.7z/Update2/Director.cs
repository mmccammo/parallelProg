﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.InteropServices;
using UnityStandardAssets.ImageEffects;
using UnityEngine.EventSystems;
using System;
//using UnityEngine.Rendering.PostProcessing;
using UnityStandardAssets.CinematicEffects;
using System.IO;
using UnityEngine.Audio;

public class Director : MonoBehaviour {

    [Header("Script Links")]

    public EntityList m_EntityList;
    public HUD m_HUD;
    private WaterInterface m_Ocean;
    public ViewSettings m_ViewSettings;
    private GameObject m_CameraCategory;

    public Entity m_MainCameraDrone;

    public Quadcopter m_InvisibleClawPrefab;
    public Quadcopter m_ActiveClaw;

    public Entity m_CaptiveEntity;
    public Transform m_CaptiveOriginalParent;
    public GameObject m_CaptiveModel;
    public Vector3 m_CaptiveModelPreviousLocalPosition;

    public GameObject m_WayPointParentObject;
    //public PostProcessVolume m_PostProcessingVolume;

    [Header("Configuration Information")]

    public bool m_Fullscreen;
    public cameraConfiguration m_CameraConfiguration;
    public bool m_MultidisplayMode;
    public int m_NumberOfCameras = 1;
    public int m_NumberOfTargetDisplays = 1;
    public int m_NumberOfConnectedDisplays = 1;
    public int m_MainDisplayIndex;
    public int m_MainCameraIndex;
    public bool m_FirstPersonMode;
    public float m_PreFPSFOV = 70;
    public float m_FPSFOV = 35;

    [Header("Camera Information")]

    public GameObject m_ActiveCameraObject;
    private GameObject m_ActiveCameraPivot;

    [Header("Sound Information")]

    public AudioMixer m_AudioMixer;
    public int m_InitialVolumePercent;
    public int m_Volume_Percent;
    public float m_Volume_Decimal;
    public float m_Volume_DB;
    public int m_InitialEntityVolumePercent;
    public int m_InitialEnvVolumePercent;
    public List<AudioSource> m_AudioSources = new List<AudioSource>();
    public AudioSource m_HovecraftIdleNoise;
    public Transform m_SoundEffectsLibraryHierarchy;
    public Dictionary<string, AudioSource> m_SoundEffectLibrary;

    [Header("Vehicle Information")]
    public Text m_DisplayText;

    public int m_CurrentEntityIndex;
    public int m_CurrentEntityID;
    public Entity m_CurrentEntity;
    public Transform m_CurrentEntityTransform;

    private bool m_PreviousVehicleControlEnabled;

    [Header("Display Information")]
    public int windowWidth;
    public int windowHeight;

    public int windowOriginX = 0;
    public int windowOriginY = 0;

    public List<int> targetScreens = new List<int>();

    [Header("Camera Options")]

    public Entity m_StartingVehicle;
    public float m_DistanceofHUDFromCamera = 0.5f;

    public List<WaypointObject> m_CameraWaypoints = new List<WaypointObject>();
    public bool m_PostProcessingActive;

    public bool m_EnableMouseViewRotation;
    public bool m_PreviousEnableMouseViewRotation;

    public bool m_EnableScrollwheelZoom;
    public bool m_PreviousEnableScrollwheelZoom;

    public bool m_Initialized = false;

    public List<int> m_KeySwitchEntities;

    public float m_COPHeightOffset;
    public Vector3 m_COPPositionVector;
    public Camera m_COPCamera;

    public Color m_COPBackgroundColor;

    public bool m_COPActive = true;

    public bool m_TakeScreenshot;
    public int resWidth = 2550;
    public int resHeight = 3300;

    public bool m_takeNewScreenshot;

    public bool m_takeNewSuperScreenshot;
    public int m_SuperSize = 1;

    public VisionMode m_VisionMode = 0;
    public List<Light> m_NVGLights;
    public List<AdvancedNightVision.AdvancedNightVision> m_NVGScripts;

    public int m_CurrentDisplayIndex;

    public Vector3 m_CurrentViewRotation;
    public float m_CurrentViewHeight;

    public bool m_BirdsEyeView;
    public int m_BirdsEyeHeight = 5000;
    public float m_BirdsEyeMarkerObjectSizeMultiplier = 10;
    public Vector3 m_BirdsEyeMarkerObjectSizeVector;
    public Vector3 m_BirdsEyeCamPivotRotation = new Vector3(90,0,0);
    public float m_BirdsEyeMarkerHeightMultiplier = 1;
    public float m_BirdsEyeMarkerLineMultiplier = 1;

    public bool m_Bighead;

    public float m_OriginalCamDistance;
    public float m_OriginalCamHeight;
    public Vector3 m_OriginalEntityPosition;
    public Vector3 m_OriginalEntityRotation;
    public Vector3 m_OriginalCamPivotRotation;
    public bool m_OriginalMouseViewRotation;
    public int m_OriginalSpeedMode;
    public Entity m_OriginalEntity;

    public bool m_MouseClickPanEnabled;

    public List<Camera> m_ExtraCameras = new List<Camera>();

    public Transform m_DynaCamJoint;
    public Camera m_DynaCam;
    public Entity m_DynaCamTarget;
    public float m_DynaCamStandoffDistance = 25;
    public Vector3 m_DynaCamStandOffVector;
    public Vector3 m_DynaCamBlankRotationVector;
    public Vector3 m_DynaCamRotationVector;
    public float m_DynaCamZoom;
    public float m_DynaCamRotation;
    public float m_MaxZoom = 60f;
    public Vector3 m_DynaCamPanVector;

    public bool m_CinematicMode;

    public GameObject m_StaticCameraPrefab;
    public GameObject m_StaticCamera;

    public bool m_HasSavedPosition = false;
    public bool m_SavedPositionIsRelative = false;
    public Vector3 m_SavedPos;
    public Vector3 m_SavedRot;
    public float m_SavedCamDist;
    public float m_SavedCamPan;
    public float m_SavedCamHeight;
    public float m_SavedCamX;
    public float m_SavedCamY;
    public int m_SavedEntityFollowingID;

    public string m_SavedCamPosString;
    public string m_SavedCamRotString;
    public string m_SavedCamViewString;

    public float m_SpotlightIntensity;
    public float m_SpotlightRange;

    public float m_NVGLightIntensity;
    public float m_NVGLightRange;

    public Color m_LDoorColor;

    public bool SimStart()
    {
        //Debug.Log("SimStart: " + gameObject.name);
        m_Initialized = false;
        Initialize();
        return m_Initialized;
    }

    void getScriptLinksAndSetDefaults()
    {
        if (m_CameraCategory == null)
        {
            m_CameraCategory = GameObject.Find("[Cameras]");
        }

        if (m_Ocean == null)
        {
            m_Ocean = SimulatorSettings.getEnvironmentManager().getOcean();
        }

        if (m_ActiveCameraObject == null)
        {
            m_ActiveCameraObject = GameObject.FindGameObjectWithTag("MainCamera");
        }
        
        if (m_ViewSettings == null)
        {
            m_ViewSettings = m_ActiveCameraObject.GetComponent<ViewSettings>();
        }

        if (SimulatorSettings.UIManagerActive())
        {
            m_HUD = SimulatorSettings.getUIManager().getHUD();
        }

        m_CameraConfiguration = SimulatorSettings.getConfigManager().getCameraConfiguration();
        m_MultidisplayMode = SimulatorSettings.getMultiDisplayMode();
        m_NumberOfTargetDisplays = SimulatorSettings.getNumberOfTargetDisplays();
        m_NumberOfConnectedDisplays = Display.displays.Length;
        m_NumberOfCameras = SimulatorSettings.getNumberOfCameras();

        m_PreviousVehicleControlEnabled = false;

        m_KeySwitchEntities = new List<int>();

        m_ActiveCameraObject.SetActive(true);
        m_ActiveCameraObject.GetComponent<ViewSettings>().setInitialized(true);
        // FIX
        //m_Ocean.ProjectionCamera = m_ActiveCameraObject;

        if (m_DynaCam == null)
        {
            GameObject l_Obj = GameObject.Find("DynaCamJoint");

            m_DynaCam = l_Obj.transform.GetComponentInChildren<Camera>();
        }

        if (m_DynaCam == null)
        {
            GameObject l_Joint = new GameObject("DynaCamJoint");
            l_Joint.transform.SetParent(m_CameraCategory.transform);
            l_Joint.transform.localPosition = Vector3.zero;

            m_DynaCamJoint = l_Joint.transform;

            GameObject l_Obj = new GameObject("DynaCam");
            l_Obj.transform.SetParent(l_Joint.transform);
            l_Obj.transform.localPosition = Vector3.zero;

            m_DynaCam = l_Obj.AddComponent<Camera>();
        }

        windowWidth = Display.main.systemWidth;
        windowHeight = Display.main.systemHeight;
    
    }

    void SetDisplay()
    {
        Display.main.SetParams(windowWidth, windowWidth, windowOriginX, windowOriginY);
        //Debug.Log("Window X: " + windowOriginX + " - Window Y: " + windowOriginY);

        Rect viewportRect;
        float screenRectSize = 0;

        //RectTransform camRectTransform = new RectTransform;
        //camRectTransform.rect.Set(ViewSettings.cameras[0].rect.x, ViewSettings.cameras[0].rect.y, ViewSettings.cameras[0].rect.width, ViewSettings.cameras[0].rect.height);
        //camRectTransform.

        if (m_NumberOfCameras == 1)
        {
            Debug.Log("[Director] Number of cameras requested is: " + m_NumberOfCameras + " - Number of target displays is: " + m_NumberOfTargetDisplays + "/" + m_NumberOfConnectedDisplays + ". Using Monodisplay Mode Bezel Size: " + m_CameraConfiguration.bezelSize);
        }
        // FIXME This could be a mistake, was just an if
        else if ((m_NumberOfCameras > 1) && (m_NumberOfTargetDisplays == 1))
        {
            Debug.Log("[Director] Number of cameras requested is: " + m_NumberOfCameras + " - Number of target displays is: " + m_NumberOfTargetDisplays + "/" + m_NumberOfConnectedDisplays + ". Using Split Monodisplay Mode Bezel Size: " + m_CameraConfiguration.bezelSize);

            screenRectSize = 1f / m_NumberOfCameras;

            for (int i = 0; i < m_ViewSettings.m_NumberOfCameras; i++)
            {
                if (m_CameraConfiguration.cameras[i].changeRect)
                {
                    viewportRect = new Rect(m_CameraConfiguration.cameras[i].screenX, m_CameraConfiguration.cameras[i].screenY, m_CameraConfiguration.cameras[i].screenW, m_CameraConfiguration.cameras[i].screenH);
                }
                else
                {
                    viewportRect = new Rect(screenRectSize * i, 0, screenRectSize, 1);
                }
                m_ViewSettings.m_ChildCameras[i].rect = viewportRect;

                m_ViewSettings.m_ChildCameras[i].targetDisplay = 0;

                Debug.Log("Cam " + i + " is on Display " + m_ViewSettings.m_ChildCameras[i].targetDisplay);
            }
        }
        else if (m_MultidisplayMode && (m_NumberOfCameras <= m_NumberOfTargetDisplays))
        {
            Debug.Log("[Director] Number of cameras requested is: " + m_NumberOfCameras + " - Number of target displays is: " + m_NumberOfTargetDisplays + "/" + m_NumberOfConnectedDisplays + ". Using Multidisplay Mode - Bezel Size: "+ m_CameraConfiguration.bezelSize + " - Downsizing to number of displays");

            int targetDisplay = 1;
            int targetScreen;
            screenRectSize = 1f;

            m_NumberOfCameras = m_NumberOfTargetDisplays;

            for (int i = 0; i < m_NumberOfCameras; i++)
            {
                if (m_CameraConfiguration.cameras[i].changeRect)
                {
                    if(m_CameraConfiguration.cameras[i].screenY < 0)
                    {
                        viewportRect = new Rect(m_CameraConfiguration.cameras[i].screenX, m_CameraConfiguration.cameras[i].screenY + (-m_CameraConfiguration.bezelSize), m_CameraConfiguration.cameras[i].screenW, m_CameraConfiguration.cameras[i].screenH);
                    }
                    else if (m_CameraConfiguration.cameras[i].screenY > 0)
                    {
                        viewportRect = new Rect(m_CameraConfiguration.cameras[i].screenX, m_CameraConfiguration.cameras[i].screenY + m_CameraConfiguration.bezelSize, m_CameraConfiguration.cameras[i].screenW, m_CameraConfiguration.cameras[i].screenH);
                    }
                    else
                    {
                        viewportRect = new Rect(m_CameraConfiguration.cameras[i].screenX, m_CameraConfiguration.cameras[i].screenY, m_CameraConfiguration.cameras[i].screenW, m_CameraConfiguration.cameras[i].screenH);
                    }
                }
                else
                {
                    viewportRect = new Rect(0, 0, 1, 1);
                }

                m_ViewSettings.m_ChildCameras[i].rect = viewportRect;

                targetScreen = targetScreens[i];
                Debug.Log("Activating " + m_ViewSettings.m_ChildCameras[i] + " using TargetDisplay[" + targetDisplay + "] on Screen[ " + targetScreen + "]");
                m_ViewSettings.m_ChildCameras[i].targetDisplay = i;
                if (i != 0) Display.displays[i].Activate();

                targetDisplay++;
            }
            //Debug.Log("Director finished creating Multidisplay.");
        }
        else
        {
            Debug.Log("[Director] ERROR. UKNKNOWN COMBINATION. Number of cameras requested is: " + m_NumberOfCameras + " - Number of target displays is: " + m_NumberOfTargetDisplays + "/" + m_NumberOfConnectedDisplays + " - Multidisplay Mode is set to: " + m_MultidisplayMode);
        }

        m_NVGLights.Clear();
        m_NVGScripts.Clear();

        foreach (Camera l_Cam in m_ViewSettings.m_ChildCameras)
        {
            if(l_Cam.GetComponent<Light>())
            {
                m_NVGLights.Add(l_Cam.GetComponent<Light>());
            }
            if (l_Cam.GetComponent<AdvancedNightVision.AdvancedNightVision>())
            {
                m_NVGScripts.Add(l_Cam.GetComponent<AdvancedNightVision.AdvancedNightVision>());
            }
        }

        if(m_NumberOfCameras == 5)
        {
            m_ViewSettings.m_ZoomEnabled = false;
        }
        else m_ViewSettings.m_ZoomEnabled = true;
    }
	
	void Initialize()
    {
        if (!Application.isPlaying)
        {
            Debug.Log("[Director] Application is not running. Starting in Editor Mode.");

            m_SavedPos = new Vector3();
            m_SavedRot = new Vector3();

            m_ViewSettings.m_MainCamera.clearFlags = CameraClearFlags.SolidColor;
            m_ViewSettings.m_MainCamera.backgroundColor = Color.black;

            m_COPCamera.clearFlags = CameraClearFlags.SolidColor;
            m_COPCamera.backgroundColor = Color.black;

            if (m_HUD.m_LoadingMessage)
            {
                m_HUD.m_LoadingMessage.SetActive(true);
            }

            if(m_BirdsEyeView)
            {
                m_BirdsEyeMarkerObjectSizeVector = new Vector3(m_BirdsEyeMarkerObjectSizeMultiplier, m_BirdsEyeMarkerObjectSizeMultiplier, m_BirdsEyeMarkerObjectSizeMultiplier);
            }
            else
            {
                m_BirdsEyeMarkerObjectSizeVector = new Vector3(1, 1, 1);
            }

            m_Initialized = true;
            return;
        }
        else
        {
            Debug.Log("[Director] Application is running. Starting in Simulator Mode.");

            m_ViewSettings.m_MainCamera.clearFlags = CameraClearFlags.Skybox;

            //m_COPCamera.clearFlags = CameraClearFlags.SolidColor;
            m_COPCamera.backgroundColor = m_COPBackgroundColor;

            if (m_HUD.m_LoadingMessage)
            {
                m_HUD.m_LoadingMessage.SetActive(false);
            }
        }

        if (!m_Initialized)
        {

            getScriptLinksAndSetDefaults();

            Quadcopter l_Controller = m_MainCameraDrone.GetComponent<Quadcopter>();
            
            if(l_Controller != null)
            {
                if(SimulatorSettings.getConfigManager().m_HasInitialPosition)
                {
                    //Debug.Log("Initial Camera Lat Lon: " + SimulatorSettings.getInitialCameraLatLon() + " XYZ: " + GPSEncoder.GPSToUCS(SimulatorSettings.getInitialCameraLatLon()));
                    if (SimulatorSettings.getInitialCameraLatLon() != Vector2.zero)
                    {
                        //Debug.Log("Setting Main Camera Drone Position - Currently is: " + l_Controller.transform.position);
                        l_Controller.setGPSPosition(SimulatorSettings.getInitialCameraLatLon());
                        l_Controller.SetElevation(SimulatorSettings.getInitialCameraElevation());

                        m_EntityList.checkOutsideCutOffDistance(l_Controller);
                    }

                    if (SimulatorSettings.getInitialCameraElevation() != 0)
                    {
                        l_Controller.transform.position = new Vector3(l_Controller.transform.position.x, SimulatorSettings.getInitialCameraElevation(), l_Controller.transform.position.z);
                    }

                    if (SimulatorSettings.getInitialCameraRotation() != Vector3.zero)
                    {
                        l_Controller.SetRotation(Quaternion.Euler(SimulatorSettings.getInitialCameraRotation()));
                        l_Controller.m_DesiredHeading = SimulatorSettings.getInitialCameraRotation().y;
                    }
                }
               
            }

            m_ViewSettings.SimStart();

            if(SimulatorSettings.getDebugMode()) Debug.Log("[Director] Active Camera is: " + m_ActiveCameraObject.name);

            SetDisplay();
            

            if (m_StartingVehicle != null)
            {

               // Debug.Log("Starting Vehicle ID: " + m_StartingVehicle.m_EntityID);

                m_CurrentEntity = m_StartingVehicle;

                switchtoVehicleByID(m_StartingVehicle.m_EntityID);
            }
            else
            {
                m_CurrentEntityIndex = 0;
            }
            
            m_CurrentEntityTransform = m_ActiveCameraObject.transform;
            // FIX
            //m_Ocean.AssignFolowTarget(oceanTarget);

            //GetCameraWaypoints();

            if(m_COPCamera)
            {
                m_COPCamera.GetComponent<COPCameraUI>().ExternalStart();
            }

            toggleCOP(m_COPActive);

            Reset();

            if(m_InitialVolumePercent >= 0) SetVolumePercent_Master(m_InitialVolumePercent);
            if (m_InitialEnvVolumePercent >= 0) SetVolumePercent_Env(m_InitialEnvVolumePercent);
            if (m_InitialEntityVolumePercent >= 0) SetVolumePercent_Entity(m_InitialEntityVolumePercent);

            m_SoundEffectLibrary = new Dictionary<string, AudioSource>();
            if(m_SoundEffectsLibraryHierarchy)
            {
                foreach (Transform l_Child in m_SoundEffectsLibraryHierarchy)
                {
                    AudioSource l_Source = l_Child.GetComponent<AudioSource>();

                    if (l_Source)
                    {
                        m_SoundEffectLibrary.Add(l_Child.gameObject.name, l_Source);
                    }
                }
            }

            Debug.Log("Camera Director initialized successfully");
            m_Initialized = true;
        }
        
	}

    public void GetCameraWaypoints()
    {
        m_CameraWaypoints.Clear();

        if(m_WayPointParentObject != null)
        {
            foreach (WaypointObject l_ChildWaypoint in m_WayPointParentObject.GetComponentsInChildren<WaypointObject>())
            {
                m_CameraWaypoints.Add(l_ChildWaypoint);
            }
        }
    }

    public void forceStart()
    {
        
    }
	
    public void forceMultiDisplay()
    {
        Rect viewportRect;
        float screenRectSize = 0;

        Debug.Log("Director has begun building Multidisplay Mode. Number of cameras is: " + m_ViewSettings.m_NumberOfCameras + " Number of Displays is: " + m_NumberOfTargetDisplays);
        int targetDisplay = 1;
        int targetScreen;
        screenRectSize = 1f;

        for (int i = 0; i < m_ViewSettings.m_NumberOfCameras; i++)
        {
            viewportRect = new Rect(0, 0, 1, 1);
            m_ViewSettings.m_ChildCameras[i].rect = viewportRect;

            targetScreen = targetScreens[i];
            Debug.Log("Activating " + m_ViewSettings.m_ChildCameras[i] + "across Display[" + targetDisplay + "] on Screen[ " + targetScreen + "]");
            m_ViewSettings.m_ChildCameras[i].targetDisplay = i;
            if (i != 0) Display.displays[i].Activate();

            targetDisplay++;
        }
        Debug.Log("Director finished creating Multidisplay.");
    }

	// Update is called once per frame
    void Update()
    {
        //if (m_NumberOfTargetDisplays > 1)
        //{
        //    if (test == false)
        //    {
        //        //forceMultiDisplay();
        //        test = true;
        //    }
            
        //}
        if (!m_Initialized)
        {
            SimStart();
        }
        else
        {
            if (m_NumberOfTargetDisplays > 1) m_CurrentDisplayIndex = Common.GetHoveredDisplay();
            else m_CurrentDisplayIndex = 0;

            m_CurrentViewRotation = m_ViewSettings.m_ViewRotation;
            m_CurrentViewHeight = m_ViewSettings.m_CameraHeight;

            if(m_BirdsEyeView)
            {
                SimulatorSettings.getAnimationManager().m_IndicatorLineWidth = (m_BirdsEyeMarkerObjectSizeMultiplier / 3) + (m_ViewSettings.m_CameraOffsetVector.y / 1000);
            }
}
	}

    void FixedUpdate()
    {
        if (m_Initialized)
        {
            UpdateCOP();
        }
    }

    public Ray GetScreenPointToRay(Vector3 a_Point)
    {
        return m_ViewSettings.m_ChildCameras[m_CurrentDisplayIndex].ScreenPointToRay(a_Point);
    }

    public Ray GetMousePosScreenPointToRay()
    {
        return m_ViewSettings.m_ChildCameras[m_CurrentDisplayIndex].ScreenPointToRay(Input.mousePosition);
    }

    public Ray GetMousePosScreenPointToRay(Vector3 a_Vec)
    {
        return m_ViewSettings.m_ChildCameras[m_CurrentDisplayIndex].ScreenPointToRay(a_Vec);
    }

    public Ray GetOverlayMousePosScreenPointToRay()
    {
        return m_ViewSettings.m_OverlayCamera.ScreenPointToRay(Input.mousePosition);
    }

    public Ray GetOverlayMousePosScreenPointToRay(Vector3 a_Vec)
    {
        return m_ViewSettings.m_OverlayCamera.ScreenPointToRay(a_Vec);
    }

    public Vector3 GetWorldToScreenPoint(Vector3 a_Point)
    {
        return m_ViewSettings.m_ChildCameras[m_CurrentDisplayIndex].WorldToScreenPoint(a_Point);
    }
    
    public static string ScreenShotName(int width, int height, int camNumber)
    {
        string l_RetString = "";

        if(Application.isEditor)
        {
            if (!Directory.Exists("C:/Developer/VIBE2/Screenshots"))
            {
                Directory.CreateDirectory("C:/Developer/VIBE2/Screenshots");
            }

            l_RetString = string.Format("{0}/Screenshot_{1}x{2}_{3}_Cam_{4}.png",
                                 "C:/Developer/VIBE2/Screenshots",
                                 width, height, camNumber,
                                 System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss"));
        }
        else
        {
            if (!Directory.Exists(string.Format("{0}/Screenshots/", Application.dataPath)))
            {
                Directory.CreateDirectory(string.Format("{0}/Screenshots/", Application.dataPath));
            }

            l_RetString = string.Format("{0}/Screenshots/Screen_{1}x{2}_{3}_Cam_{4}.png",
                     Application.dataPath,
                     width, height, camNumber,
                     System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss"));
        }

        Debug.Log("Targeting Screenshot Path: " + l_RetString);

        return l_RetString;
    }

    void LateUpdate()
    {
        if(Application.isPlaying)
        {
            if (m_TakeScreenshot)
            {
                string filename;

                for (int i = 0; i < m_NumberOfCameras; i++ )
                {
                    Camera l_Camera = m_ViewSettings.getCameraByIndex(i);

                    RenderTexture rt = new RenderTexture(resWidth, resHeight, 24);
                    l_Camera.targetTexture = rt;
                    Texture2D screenShot = new Texture2D(resWidth, resHeight, TextureFormat.ARGB32, false);
                    l_Camera.Render();
                    RenderTexture.active = rt;
                    screenShot.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);
                    l_Camera.targetTexture = null;
                    RenderTexture.active = null; // JC: added to avoid errors
                    Destroy(rt);
                    byte[] bytes = screenShot.EncodeToPNG();
                    filename = ScreenShotName(resWidth, resHeight, i);
                    System.IO.File.WriteAllBytes(filename, bytes);

                    m_TakeScreenshot = false;
                }
            }

            if(m_takeNewScreenshot)
            {
                string filename;

                for (int i = 0; i < m_NumberOfCameras; i++)
                {
                    filename = ScreenShotName(resWidth, resHeight, i);
                    ScreenCapture.CaptureScreenshot(filename);

                    Debug.Log(string.Format("Took screenshot to: {0}", filename));
                }

                m_takeNewScreenshot = false;
            }

            if(m_takeNewSuperScreenshot)
            {
                string filename;

                for (int i = 0; i < m_NumberOfCameras; i++)
                {
                    filename = ScreenShotName(resWidth, resHeight, i);
                    ScreenCapture.CaptureScreenshot(filename, m_SuperSize);

                    Debug.Log(string.Format("Took screenshot to: {0}", filename));
                }

                m_takeNewSuperScreenshot = false;
            }
        }
    }

    public void TakeScreenshot()
    {
        resWidth = Screen.width;
        resHeight = Screen.height;

        if(m_TakeScreenshot)
        {
            Debug.Log("[Director] Something attempted to trigger a screenshot while another shot was being processed.");
        }
        else
        {
            m_TakeScreenshot = true;
        }
    }

    public void TakeScreenshot(int a_Width, int a_Height)
    {
        resWidth = a_Width;
        resHeight = a_Height;

        if (m_TakeScreenshot)
        {
            Debug.Log("[Director] Something attempted to trigger a screenshot while another shot was being processed.");
        }
        else
        {
            m_TakeScreenshot = true;
        }
    }

    public void TakeNewScreenshot()
    {
        if (m_takeNewScreenshot)
        {
            Debug.Log("[Director] Something attempted to trigger a screenshot while another shot was being processed.");
        }
        else
        {
            m_takeNewScreenshot = true;
        }

    }

    public void TakeNewSuperScreenshot(int a_Supersize)
    {
        m_SuperSize = a_Supersize;

        if (m_takeNewSuperScreenshot)
        {
            Debug.Log("[Director] Something attempted to trigger a screenshot while another shot was being processed.");
        }
        else
        {
            m_takeNewSuperScreenshot = true;
        }

    }

    void lockCamera()
    {
        m_ActiveCameraObject.transform.SetParent(m_CurrentEntity.getCameraAttachPoint());
        m_ActiveCameraObject.transform.position = Vector3.zero;
        m_ActiveCameraObject.transform.rotation = Quaternion.identity;

        if (m_ActiveCameraObject.GetComponent<ViewSettings>())
        {
            m_ActiveCameraObject.GetComponent<ViewSettings>().changeTarget(m_CurrentEntity.GetComponent<Entity>().getCameraAttachPoint());
        }       

        //ViewSettings.setFreeCameraMode(true);
        m_ActiveCameraObject.GetComponent<ExtendedFlycam>().setMouseLock(false);
        m_ActiveCameraObject.GetComponent<ExtendedFlycam>().enabled = false;
    }


    void freeCamera()
    {
        m_ActiveCameraObject.transform.position = m_CurrentEntity.transform.position;
        m_ActiveCameraObject.transform.rotation = m_CurrentEntity.transform.rotation;
        m_ActiveCameraObject.transform.SetParent(null); //(flyingCameraAnchor.transform);

        m_ViewSettings.m_FollowTarget = null; //flyingCameraAnchor.transform;

        //ViewSettings.setFreeCameraMode(false);
        m_ActiveCameraObject.GetComponent<ExtendedFlycam>().setMouseLock(true);
        m_ActiveCameraObject.GetComponent<ExtendedFlycam>().enabled = true;
    }

    public void switchToPreviousVehicle()
    {
        if (m_FirstPersonMode)
        {
            if (HasPreviousFPSCamera())
            {
                m_CurrentEntity.m_CurrentFPSCameraIndex--;
                switchFPSCamera();

                return;
            }
        }

        bool l_Found = false;

        for (int i = 0; i < m_EntityList.getNumVehicles(); i++)
        {
            m_CurrentEntityIndex--;
            if (m_CurrentEntityIndex < 0) m_CurrentEntityIndex = m_EntityList.getNumVehicles() - 1;

            //if (m_EntityList.getVehicle(m_CurrentEntityIndex).gameObject.activeInHierarchy)
            //{
            //    l_Found = true;
            //    break;
            //}

            l_Found = true;
            break;
        }

        if (l_Found)
        {
            switchVehicle();
        }
        else
        {
            Debug.Log("switchToPreviousVehicle() error");
        }
    }

    public void switchToNextVehicle()
    {
        if(m_FirstPersonMode)
        {
            if (HasNextFPSCamera())
            {
                m_CurrentEntity.m_CurrentFPSCameraIndex++;
                switchFPSCamera();

                return;
            }
        }

        bool l_Found = false;
        
        for (int i = 0; i < m_EntityList.getNumVehicles(); i++ )
        {
            m_CurrentEntityIndex++;
            if (m_CurrentEntityIndex >= m_EntityList.getNumVehicles()) m_CurrentEntityIndex = 0;

            l_Found = true;
            break;

            //if (m_EntityList.getVehicle(m_CurrentEntityIndex).gameObject.activeInHierarchy)
            //{
            //    l_Found = true;
            //    break;
            //}
        }
        
        if(l_Found)
        {
            switchVehicle();
        }
        else
        {
            Debug.Log("switchToNextVehicle() error");
        }
       
    }

    IEnumerator disableFollowCamera()
    {
        yield return new WaitForSeconds(3);
        if (m_CurrentEntityIndex == 0) m_CurrentEntity.GetComponent<FollowTargetCamera>().enabled = false;
    }

    void setVehicleControl(bool a_Bool)
    {
        //l_Controller.setMovementEnabled(a_Bool);

        if (a_Bool)
        {
            m_CurrentEntity.switchEntityControl(EntityControlType.PLAYER);
        }
        else
        {
            m_CurrentEntity.switchEntityControl(EntityControlType.NONE);
            //l_Controller.ClearInputs();
        }
    }

    public bool HasNextFPSCamera()
    {
        if((m_CurrentEntity.m_CurrentFPSCameraIndex + 1) < m_CurrentEntity.m_FPSCameraPositions.Count)
        {
            return true;
        }

        return false;
    }

    public bool HasPreviousFPSCamera()
    {
        if ((m_CurrentEntity.m_CurrentFPSCameraIndex - 1) >= 0)
        {
            return true;
        }

        return false;
    }

    public void switchFPSCamera()
    {
        m_ViewSettings.changeTarget(m_CurrentEntity.getFPSCameraAttachPoint());
        m_ViewSettings.enabled = true;
        m_ActiveCameraObject.transform.SetParent(m_CurrentEntity.getFPSCameraAttachPoint().transform);
    }

    void switchVehicle()
    {
        if (m_BirdsEyeView) ToggleBirdsEyeView(false);

        string displayName = "";

        bool l_ChangeJoystickAssignment = false;
        int l_JoystickID = -1;

        Entity l_PreviousEntity = m_CurrentEntity;

        if(l_PreviousEntity.m_ControlType == EntityControlType.PLAYER)
        {
            l_PreviousEntity.m_ControlType = EntityControlType.NONE;
        }

        Entity l_NewEntity = m_EntityList.getVehicle(m_CurrentEntityIndex);

        if (l_PreviousEntity.m_ControllerAssigned)
        {
            l_JoystickID = l_PreviousEntity.m_JoystickID;

            l_NewEntity.m_EntityGear = l_PreviousEntity.m_EntityGear;
            l_PreviousEntity.m_EntityGear = EntityGear.FORWARD;

            l_ChangeJoystickAssignment = true;
        }

        if (l_NewEntity.getEntityName() != string.Empty)
        {
            displayName = l_NewEntity.getEntityName();
        }
        else displayName = "Vehicle: " + l_NewEntity.m_EntityName;

        m_ActiveCameraObject.transform.rotation = Quaternion.identity;

        //Debug.Log("l_NewEntity.getCameraAttachPoint():Object: " + l_NewEntity.getCameraAttachPoint().name);

        if (m_FirstPersonMode)
        {
            m_ViewSettings.changeTarget(l_NewEntity.getFPSCameraAttachPoint());
            m_ViewSettings.enabled = true;
            m_ActiveCameraObject.transform.SetParent(l_NewEntity.getFPSCameraAttachPoint().transform);
        }
        else
        {
            m_ViewSettings.changeTarget(l_NewEntity.getCameraAttachPoint());
            m_ViewSettings.enabled = true;
            m_ActiveCameraObject.transform.SetParent(l_NewEntity.getCameraAttachPoint().transform);
        }

        //Debug.Log("m_ActiveCameraObject: " + m_ActiveCameraObject.name);

        m_DisplayText.text = displayName;

        if (m_HUD != null)
        {
            m_HUD.changeTarget(l_NewEntity.gameObject);

            m_HUD.toggleThrottleVisible(true);
            //if (typeof(Air).IsAssignableFrom(l_NewEntity.GetType())) m_HUD.toggleThrottleVisible(true);
            //else m_HUD.toggleThrottleVisible(false);

        }

        SimulatorSettings.setActiveEntity(l_NewEntity);

        if (l_ChangeJoystickAssignment)
        {
            SimulatorSettings.getInputManager().assignControllerSource(l_JoystickID, l_NewEntity.m_EntityID);
        }

        m_ActiveCameraObject.GetComponent<ViewSettings>().setLookAtMode(false);
        SimulatorSettings.getDirector().resetCameraView();
        //setVehicleControl(true);

        //if (l_NewEntity.m_ControlType == EntityControlType.NONE)
        //{
        //    l_NewEntity.m_ControlType = EntityControlType.PLAYER;
        //}

        m_CurrentEntity = l_NewEntity;
        m_CurrentEntityID = m_CurrentEntity.m_EntityID;
        m_CurrentEntityTransform = m_CurrentEntity.transform;

        l_NewEntity.m_ControlType = RequestControl(m_CurrentEntity.m_ControlType, EntityControlType.PLAYER);

        //Debug.Log("Magnitude of distance between new entity and origin: " + m_CurrentEntity.transform.position.magnitude);
        if (m_CurrentEntity.transform.position.magnitude > 5000)
        {
            Debug.Log("Magnitude is greater than threshold, setting origin to: " + m_CurrentEntity.currentGPSPosition);
            SimulatorSettings.getGPSPanel().setOrigin(m_CurrentEntity.currentGPSPosition);
            SimulatorSettings.getEntityList().checkEntityPositions();
        }

        l_PreviousEntity.SetAudioSpatialBlend(1);
        m_CurrentEntity.SetAudioSpatialBlend(0);

        Debug.Log("Switched to Vehicle (" + m_CurrentEntityIndex + ") : " + displayName);
    }

    public void RequestControl(Entity a_Entity, EntityControlType a_Type, bool a_Override = false)
    {
        EntityControlType l_Type = RequestControl(a_Entity.m_ControlType, a_Type, a_Override);

        if(l_Type == a_Type)
        {
            if(a_Entity.m_ControlType != a_Type)
            {
                a_Entity.switchEntityControl(a_Type);
            }
        }
    }

    EntityControlType RequestControl(EntityControlType a_CurrentType, EntityControlType a_NewType, bool a_Override = false)
    {
        EntityControlType l_Type = EntityControlType.NONE;

        Debug.Log("Control Request for ID: " + m_CurrentEntityID + " - From Type " + a_CurrentType + " to Type " + a_NewType);

        if(a_Override)
        {
            Debug.Log("Control Hierarchy has been overriden.");

            //switch (a_CurrentType) // Current Control Type
            //{
            //    case EntityControlType.NETWORK:
            //        break;
            //    case EntityControlType.SCRIPT: // Medium Priority
            //        break;
            //    case EntityControlType.WAYPOINT: // Medium Priority
            //        break;
            //    default:
            //        break;
            //}

            return a_NewType;
        }

        switch (a_NewType) // Requested Control Type
        {
            case EntityControlType.NETWORK: // Highest Priority

                l_Type = a_NewType;

                break;
            case EntityControlType.SCRIPT: // Medium Priority

                l_Type = a_NewType;

                break;
            case EntityControlType.WAYPOINT: // Medium Priority

                l_Type = a_NewType;

                break;
            case EntityControlType.PLAYER: // Low Priority

                switch(a_CurrentType) // Current Control Type
                {
                    case EntityControlType.NETWORK:
                        Debug.Log("NETWORK");
                        l_Type = EntityControlType.NETWORK;

                        break;
                    case EntityControlType.SCRIPT: // Medium Priority
                        Debug.Log("SCRIPT");
                        l_Type = EntityControlType.SCRIPT;

                        break;
                    case EntityControlType.WAYPOINT: // Medium Priority
                        Debug.Log("WAYPOINT");
                        l_Type = EntityControlType.WAYPOINT;

                        break;
                    default:
                        Debug.Log("default");
                        l_Type = a_NewType;
                        break;
                }

                break;
            default: // Lowest Priority

                l_Type = a_NewType;

                break;
        }

        return l_Type;
    }

    public GameObject getCurrentCameraObject()
    {
        return m_ActiveCameraObject;
    }

    public void switchtoVehicleByID(int a_ID)
    {
        int l_Index = m_EntityList.getVehicleIndexByID(a_ID);
        if (l_Index != -1)
        {
            if(m_BirdsEyeView)
            {
                TetherQuadcopterToEntity(a_ID);
            }
            else
            {
                SimulatorSettings.getEntityList().AddRecentEntity(a_ID);

                m_CurrentEntityIndex = l_Index;
                //Debug.Log("Switchting to " + a_ID + " which is stored in index: " + m_CurrentEntityIndex);
                switchVehicle();
            }
        }
    }

    public void switchtoVehicleByIndex(int index)
    {
        m_CurrentEntityIndex = index;
        switchVehicle();
    }

    public Entity getCurrentEntity()
    {
        return m_CurrentEntity;
    }

    public void setScreenResolution(int width, int height)
    {
        Screen.SetResolution(width, height, Screen.fullScreen);
        SimulatorSettings.getUIManager().setRefrenceResolution(width, height);
    }

    public void setDisplayResolution(int a_Display, int a_Width, int a_Height, int a_X, int a_Y)
    {
        Display.displays[a_Display].SetParams(a_Width, a_Height, a_X, a_Y);
    }

    public int getNumDisplays()
    {
        Debug.Log("Number of Displays: " + Display.displays.Length);
        return Display.displays.Length;
    }

    public void activateDisplay(int displayNum, int width, int height)
    {
        Display.displays[displayNum].Activate(width, height, 60);
    }

    public void setWindowLocation(int x, int y)
    {
        //Display.main.SetParams(windowWidth, windowHeight, x, y);
        SetPosition(x, y);
    }

    public void setWindowParams(int width, int height, int x, int y)
    {
        Display.main.SetParams(width, height, x, y);
    }

    public void resetCameraView()
    {
        Debug.Log("Resetting camera rotation.");

        if (!m_BirdsEyeView)
        {
            m_ActiveCameraObject.GetComponent<ViewSettings>().resetViewRotation();
        }
        else
        {
            m_ViewSettings.SetViewPivotRotation(m_BirdsEyeCamPivotRotation);
            m_CurrentEntity.SetRotation(Vector3.zero);
        }
    }

    public void toggleRotateAroundObject()
    {
        m_ActiveCameraObject.GetComponent<ViewSettings>().m_RotateAroundActiveObject = !m_ActiveCameraObject.GetComponent<ViewSettings>().m_RotateAroundActiveObject;

    }

    public void rotateCamera(float a_Horizontal, float a_Vertical, float a_Speed)
    {
        //Debug.Log("Rotating camera by X: " + a_Horizontal + " Y: " + a_Vertical);

        float speed = 2.0f;
        //m_ActiveCameraObject.GetComponent<ViewSettings>().rotateCamera(a_Horizontal, a_Vertical, speed);
    }

    public void setHorizontalRotation(float a_Rotation)
    {
        m_ActiveCameraObject.GetComponent<ViewSettings>().m_CameraRotationHorizontal = a_Rotation;
    }
    
    public void setVerticalRotation(float a_Rotation)
    {
        m_ActiveCameraObject.GetComponent<ViewSettings>().m_CameraRotationVertical = a_Rotation;
    }

    public GameObject getActiveCameraObject()
    {
        return m_ActiveCameraObject;
    }

    private IEnumerator coroutine;

    public void changeScreen(int a_ScreenNum)
    {
        Debug.Log("changeScreen(" + a_ScreenNum + ") called.");
        coroutine = TargetDisplayHack(a_ScreenNum);
        StartCoroutine(coroutine);

        //SetMonitorIndex(a_ScreenNum);

        //Debug.Log("changeScreen(" + a_ScreenNum + ") finished.");
    }

    public void SetMonitorIndex(int newMonitorIndex)
    {
        PlayerPrefs.SetInt("UnitySelectMonitor", newMonitorIndex);

        var display = Display.displays[newMonitorIndex];
        int resWidth = display.systemWidth;
        int resHeight = display.systemHeight;
        Screen.SetResolution(resWidth, resHeight, Screen.fullScreen);
    }

    public IEnumerator TargetDisplayHack(int a_TargetDisplay)
    {
        // Get the current screen resolution.
        int screenWidth = Screen.width;
        int screenHeight = Screen.height;

        // Set the target display and a low resolution.
        PlayerPrefs.SetInt("UnitySelectMonitor", a_TargetDisplay);
        Screen.SetResolution(800, 600, Screen.fullScreen);

        // Wait a frame.
        yield return null;

        // Restore resolution.
        Screen.SetResolution(screenWidth, screenHeight, Screen.fullScreen);

    }

    public void activateDisplay(int a_DisplayNumber)
    {
        if (a_DisplayNumber < Display.displays.Length)
        {
            Display.displays[a_DisplayNumber].Activate();
        }
    }

    public void printDisplayStatus()
    {
        for (int i = 0; i < Display.displays.Length; i++)
        {
            Debug.Log("Display [" + i + "]: Render Width/Height (" + Display.displays[i].renderingWidth + "/" + Display.displays[i].renderingHeight + ") System Width/Height (" + Display.displays[i].systemWidth + "/" + Display.displays[i].systemHeight + ") Active: (" + Display.displays[i].active + ")");
        }
    }

    public void switchTargetDisplay(int a_PreviousDisplayIndex, int a_NewDisplayIndex)
    {
        if(a_PreviousDisplayIndex == a_NewDisplayIndex)
        {
            Debug.Log("Invalid Display Index entered.");
            return;
        }

        if(a_PreviousDisplayIndex < 0 || a_PreviousDisplayIndex > m_NumberOfCameras)
        {
            Debug.Log("Invalid Display Index entered.");
            return;
        }

        if (a_NewDisplayIndex < 0 || a_NewDisplayIndex > m_NumberOfCameras)
        {
            Debug.Log("Invalid Display Index entered.");
            return;
        }

        List<int> l_CamerasAssignedToPreviousDisplay = indexOfCamerasAssignedToDisplayIndex(a_PreviousDisplayIndex);
        List<int> l_CamerasAssignedToNewDisplay = indexOfCamerasAssignedToDisplayIndex(a_NewDisplayIndex);

        if(l_CamerasAssignedToPreviousDisplay.Count == 0)
        {
            Debug.Log("Error: No camera is assigned to the target display you requested to switch (" + a_PreviousDisplayIndex + ").");
            return;
        }
        
        foreach (int l_CameraIndex in l_CamerasAssignedToPreviousDisplay)
        {
            m_ViewSettings.m_ChildCameras[l_CameraIndex].targetDisplay = a_NewDisplayIndex;
        }

        foreach (int l_CameraIndex in l_CamerasAssignedToNewDisplay)
        {
            m_ViewSettings.m_ChildCameras[l_CameraIndex].targetDisplay = a_PreviousDisplayIndex;
        }

    }

    public List<int> indexOfCamerasAssignedToDisplayIndex(int a_DisplayIndex)
    {
        List<int> l_Ret = new List<int>();

        for (int i = 0; i < m_NumberOfCameras; i++)
        {
            Camera l_Camera = m_ViewSettings.m_ChildCameras[i];

            if (l_Camera.targetDisplay == a_DisplayIndex)
            {
                l_Ret.Add(i);
            }
        }

        return l_Ret;
    }

    public Camera getMainCamera()
    {
        return m_ViewSettings.m_MainCamera;
    }

    public int getNumberOfTargetDisplays()
    {
        return m_NumberOfTargetDisplays;
    }

    public void moveCameraToCameraWaypoint(int a_WaypointIndex)
    {
        if((a_WaypointIndex >= 0) && (a_WaypointIndex < m_CameraWaypoints.Count))
        {
            m_CameraWaypoints[0].transform.position = m_StartingVehicle.transform.position;

            Vector3 l_NewPosition = GPSEncoder.GPSToUCS(m_CameraWaypoints[a_WaypointIndex].m_LatLon);
            l_NewPosition.y = m_CameraWaypoints[a_WaypointIndex].m_Elevation;

            Vector3 l_NewRotation = m_CameraWaypoints[a_WaypointIndex].m_Rotation;

            m_StartingVehicle.SetPosition(l_NewPosition);
            m_StartingVehicle.SetRotation(l_NewRotation);

            if(m_CurrentEntity != m_MainCameraDrone) switchtoVehicleByID(m_StartingVehicle.GetComponent<Entity>().m_EntityID);
        }
    }

    public void ClawGrabTarget(int a_EntityID)
    {
        if (m_EntityList.containsID(a_EntityID))
        {
            m_CaptiveEntity = m_EntityList.getEntityByVIBEID(a_EntityID);

            m_CaptiveEntity.gameObject.SetActive(false);

            //Quadcopter l_Claw = Instantiate(m_InvisibleClawPrefab, m_CaptiveEntity.transform.position, Quaternion.identity);

            int l_ID = m_EntityList.getNextAvailableID(0);

            Vector2 l_CaptiveCoordinates = new Vector2(m_CaptiveEntity.transform.position.x, m_CaptiveEntity.transform.position.z);
            float l_Elevation = m_CaptiveEntity.m_labelPosition.transform.position.y;
            float l_Heading = m_CaptiveEntity.m_CurrentHeading;

            //SimulatorSettings.getNetworkMonitor().addVehicle(l_ID, 54, l_ID, l_CaptiveCoordinates, l_Elevation, "VIBE", l_Heading, 0);

            Debug.Log("Claw Grab has been created: " + l_ID + " " + 54 + " " + l_CaptiveCoordinates + " " + l_Elevation + " " + l_Heading + " " + 0);

            Entity m_ActiveClaw = m_EntityList.getEntityByVIBEID(l_ID);

            if (m_ActiveClaw != null)
            {
                //l_Claw.m_MovementScript.droneCamera = GameObject.Find("_Main Camera").GetComponent<DroneCamera>();

                //m_CaptiveOriginalParent = m_CaptiveEntity.transform.parent;
                //m_CaptiveEntity.transform.SetParent(m_ActiveClaw.transform);
                //m_CaptiveEntity.transform.localPosition = Vector3.zero;

                //m_CaptiveModel = m_CaptiveEntity.m_ModelLoader.m_Model;
                //m_CaptiveModelPreviousLocalPosition = m_CaptiveModel.transform.localPosition;
                //m_CaptiveModel.transform.localPosition = Vector3.zero;

                //m_CaptiveModel.transform.SetParent(m_ActiveClaw.m_ModelLoader.m_Model.transform);

                //switchtoVehicleByID(m_ActiveClaw.m_EntityID);
            }
            else
            {
                Debug.Log("Claw was not created successfully.");
            }
        }
    }

    public void ClawReleaseTarget()
    {
        if(m_ActiveClaw != null)
        {
            m_CaptiveModel.transform.SetParent(m_CaptiveEntity.m_ModelLoader.m_ModelControlSystem.transform);
            m_CaptiveModel.transform.position = m_CaptiveModelPreviousLocalPosition;

            m_CaptiveEntity.transform.SetParent(m_CaptiveOriginalParent);
            m_CaptiveEntity.gameObject.SetActive(true);

            switchtoVehicleByID(m_CaptiveEntity.m_EntityID);
        }
    }

    public List<Camera> getCameras()
    {
        return m_ViewSettings.getCameras();
    }

    public Camera getCamera(int a_Index)
    {
        return m_ViewSettings.getCameras()[a_Index];
    }

    public void fireEffectorFromScreen()
    {
        if (SimulatorSettings.getDirector().m_ViewSettings.m_TargetMode)
        {
            RaycastHit l_Hit = SimulatorSettings.getDirector().m_ViewSettings.GetTarget(10000);

            if (SimulatorSettings.getUIManager().getHUD().m_TargetedEntity != null)
            {
                CMD.ExecuteCommand("fire " + SimulatorSettings.getActiveEntity().m_EntityID.ToString() + " " + SimulatorSettings.getUIManager().getHUD().m_TargetedEntity.m_EntityID.ToString());
            }
            else if (l_Hit.collider != null)
            {
                //CMD.ExecuteCommand("fireAtTarget");
            }
        }
    }

    

    public void togglePostProcessing()
    {
        m_PostProcessingActive = !m_PostProcessingActive;

        updatePostProcessing();
    }

    public void togglePostProcessing(bool a_Bool)
    {
        m_PostProcessingActive = a_Bool;

        updatePostProcessing();   
    }

    public void updatePostProcessing()
    {
        m_ViewSettings.togglePostProcessing(m_PostProcessingActive);
//        m_PostProcessingVolume.enabled = m_PostProcessingActive;

        foreach (Camera l_Camera in m_ViewSettings.m_ChildCameras)
        {
            if(l_Camera.gameObject.GetComponent<AntiAliasing>())
            {
                l_Camera.gameObject.GetComponent<AntiAliasing>().enabled = m_PostProcessingActive;
            }
        }

        //Debug.Log("PostProcessing set to: " + m_PostProcessingActive);
    }

    public void setFisheye(bool a_Enabled)
    {
        foreach (Camera l_Camera in m_ViewSettings.m_ChildCameras)
        {
            if (l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>())
            {
                //l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>().enabled = a_Enabled;
                //l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>().SetBorderEnabled(a_Enabled);
            }
        }
    }

    public void setFisheyeBorder(float a_BorderWidth)
    {
        foreach (Camera l_Camera in m_ViewSettings.m_ChildCameras)
        {
            if (l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>())
            {
                //l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>().SetBorder(a_BorderWidth);
                //l_Camera.gameObject.GetComponent<UnityStandardAssets.ImageEffects.Fisheye>().SetBorderEnabled(true);
            }
        }
    }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR
    [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
    private static extern bool SetWindowPos(IntPtr hwnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);
    [DllImport("user32.dll", EntryPoint = "FindWindow")]
    public static extern IntPtr FindWindow(System.String className, System.String windowName);

    public static void SetPosition(int x, int y, int resX = 0, int resY = 0)
    {
        //SetWindowPos(FindWindow(null, "VIBE2"), 0, x, y, resX, resY, resX * resY == 0 ? 1 : 0);

        if(SetWindowPos(FindWindow(null, "VIBE2"), 0, x, y, resX, resY, resX * resY == 0 ? 1 : 0))
        {
            Debug.Log("Found VIBE2");
        }
        else
        {
            Debug.Log("Did not find VIBE2");
        }
    }
#endif

    public void toggleCOP()
    {
        toggleCOP(!m_COPActive);
    }

    public void toggleCOP(bool a_Bool)
    {
        m_COPActive = a_Bool;

        m_COPCamera.gameObject.SetActive(a_Bool);
    }

    void UpdateCOP()
    {
        m_COPPositionVector = m_CurrentEntity.transform.position;
        m_COPPositionVector.y += m_COPHeightOffset;

        m_COPCamera.transform.position = m_COPPositionVector;
    }

    public void SetObliqueness(float horizObl, float vertObl)
    {
        m_ViewSettings.SetObliqueness(horizObl, vertObl);
    }

    public void SetObliqueness()
    {
        m_ViewSettings.SetObliqueness(m_ViewSettings.m_HorizontalOblique, m_ViewSettings.m_VerticalOblique);
    }

    public void NextVisionMode()
    {
        int l_VMode = (int)m_VisionMode + 1;

        if (Enum.IsDefined(typeof(VisionMode), l_VMode))
        {
            SetVisionMode(l_VMode);
        }
        else
        {
            l_VMode = 0;
            SetVisionMode(l_VMode);
        }
    }

    public void SetLightIntensity(float a_Intensity)
    {
        foreach (Light l_Light in m_NVGLights)
        {
            l_Light.intensity = a_Intensity;
        }
    }

    public void SetVisionMode(int a_Val)
    {
        m_VisionMode = (VisionMode)a_Val;

        switch (m_VisionMode)
        {
            case VisionMode.NORMAL:
                foreach(Light l_Light in m_NVGLights)
                {
                    l_Light.enabled = false;
                    l_Light.intensity = m_SpotlightIntensity;
                    l_Light.range = m_SpotlightRange;

                    m_EntityList.SetAllDoorAlbedo(Color.white);
                    m_EntityList.SetAllWakeMods(30);
                }
                foreach (AdvancedNightVision.AdvancedNightVision l_Script in m_NVGScripts)
                {
                    l_Script.enabled = false;
                }
                break;
            case VisionMode.SPOTLIGHT:
                foreach (Light l_Light in m_NVGLights)
                {
                    l_Light.enabled = true;
                    l_Light.intensity = m_NVGLightIntensity;
                    l_Light.range = m_NVGLightRange;

                    m_EntityList.SetAllDoorAlbedo(m_LDoorColor);
                    m_EntityList.SetAllWakeMods(10);
                }
                foreach (AdvancedNightVision.AdvancedNightVision l_Script in m_NVGScripts)
                {
                    l_Script.enabled = false;
                }
                break;
            case VisionMode.NVG:
                foreach (Light l_Light in m_NVGLights)
                {
                    l_Light.enabled = true;
                }
                foreach (AdvancedNightVision.AdvancedNightVision l_Script in m_NVGScripts)
                {
                    l_Script.enabled = true;
                }
                break;
            default:
                foreach (Light l_Light in m_NVGLights)
                {
                    l_Light.enabled = false;
                }
                foreach (AdvancedNightVision.AdvancedNightVision l_Script in m_NVGScripts)
                {
                    l_Script.enabled = false;
                }
                break;
        }
    }

    public void EnableMouseViewRotation(bool a_Bool)
    {
        Debug.Log("EnableMouseViewRotation: " + a_Bool);

        if (m_EnableMouseViewRotation != a_Bool)
        {
            m_PreviousEnableMouseViewRotation = m_EnableMouseViewRotation;
            m_EnableMouseViewRotation = a_Bool;
        }
    }

    public void RestoreMouseViewRotation()
    {
        if (m_EnableMouseViewRotation != m_PreviousEnableMouseViewRotation)
        {
            m_EnableMouseViewRotation = m_PreviousEnableMouseViewRotation;
        }
        //Debug.Log("RestoreMouseViewRotation: " + m_EnableMouseViewRotation);
    }

    public void EnableScrollwheelZoom(bool a_Bool)
    {
        //Debug.Log("EnableScrollwheelZoom: " + a_Bool);
        if (m_EnableScrollwheelZoom != a_Bool)
        {
            m_PreviousEnableScrollwheelZoom = m_EnableScrollwheelZoom;
            m_EnableScrollwheelZoom = a_Bool;
        }
    }

    public void RestoreScrollwheelZoom()
    {
        if (m_EnableScrollwheelZoom != m_PreviousEnableScrollwheelZoom)
        {
            m_EnableScrollwheelZoom = m_PreviousEnableScrollwheelZoom;
        }
    }

    public void ToggleBighead()
    {
        ToggleBighead(!m_Bighead);
    }

    public void ToggleBighead(bool a_Bool)
    {
        m_Bighead = a_Bool;

        if (m_Bighead)
        {
            m_BirdsEyeMarkerHeightMultiplier = 15;

            m_BirdsEyeMarkerObjectSizeVector.x = m_BirdsEyeMarkerObjectSizeMultiplier;
            m_BirdsEyeMarkerObjectSizeVector.y = m_BirdsEyeMarkerObjectSizeMultiplier;
            m_BirdsEyeMarkerObjectSizeVector.z = m_BirdsEyeMarkerObjectSizeMultiplier;
        }
        else
        {
            m_BirdsEyeMarkerHeightMultiplier = 1;

            m_BirdsEyeMarkerObjectSizeVector.x = 1;
            m_BirdsEyeMarkerObjectSizeVector.y = 1;
            m_BirdsEyeMarkerObjectSizeVector.z = 1;
        }
    }

    public void ToggleBirdsEyeView()
    {
        ToggleBirdsEyeView(!m_BirdsEyeView);
    }

    public void ForceBirdsEyeView(bool a_Bool)
    {
        if (m_BirdsEyeView == a_Bool)
        {
            ToggleBirdsEyeView(!a_Bool);
        }

        ToggleBirdsEyeView(a_Bool);
    }

    public void MoveQuadcopterToEntity(Entity a_Entity)
    {
        m_MainCameraDrone.SetPosition(a_Entity.transform.position + new Vector3(0, 25, 0));
    }

    public void TetherQuadcopterToEntity(int a_ID)
    {
        Entity l_Entity = m_EntityList.getEntityByVIBEID(a_ID);

        if(l_Entity)
        {
            MoveQuadcopterToEntity(l_Entity);
            Vector3 l_Offset = m_MainCameraDrone.transform.position - l_Entity.transform.position;
            SimulatorSettings.getAnimationManager().AddEntityFollower(m_MainCameraDrone, l_Entity, l_Offset, false, false);
        }
    }

    public void TetherQuadcopterToEntity(Entity a_Entity)
    {
        MoveQuadcopterToEntity(a_Entity);
        Vector3 l_Offset = m_MainCameraDrone.transform.position - a_Entity.transform.position;
        SimulatorSettings.getAnimationManager().AddEntityFollower(m_MainCameraDrone, a_Entity, l_Offset, false, false);
    }

    public void ToggleBirdsEyeView(bool a_Bool)
    {
        if (m_BirdsEyeView != a_Bool)
        {
            if (a_Bool)
            {
                m_OriginalEntityPosition = m_CurrentEntity.transform.position;
                m_OriginalEntityRotation = m_CurrentEntity.transform.rotation.eulerAngles;
                //m_CurrentEntity.SetPosition(m_CurrentEntity.transform.position + new Vector3(0, m_BirdsEyeHeight, 0));

                m_OriginalEntity = m_CurrentEntity;

                if (m_CurrentEntity.m_EntityID != 0)
                {
                    switchtoVehicleByID(0);
                    TetherQuadcopterToEntity(m_OriginalEntity);
                }

                m_BirdsEyeView = a_Bool;

                Quadcopter l_Quad = m_MainCameraDrone.GetComponent<Quadcopter>();

                if(l_Quad)
                {
                    m_OriginalSpeedMode = l_Quad.m_SpeedMode;
                }

                m_OriginalCamHeight = m_ViewSettings.m_CameraHeight;
                m_ViewSettings.setCameraHeight(m_BirdsEyeHeight);

                m_OriginalCamDistance = m_ViewSettings.m_Distance;

                m_CurrentEntity.SetRotation(Vector3.zero);

                m_OriginalCamPivotRotation = m_ViewSettings.m_ViewPivotRotation;
                m_ViewSettings.SetViewPivotRotation(m_BirdsEyeCamPivotRotation);

                m_OriginalMouseViewRotation = m_EnableMouseViewRotation;
                m_EnableMouseViewRotation = false;

                m_MouseClickPanEnabled = true;

                m_BirdsEyeMarkerHeightMultiplier = 15;

                m_BirdsEyeMarkerObjectSizeVector.x = m_BirdsEyeMarkerObjectSizeMultiplier;
                m_BirdsEyeMarkerObjectSizeVector.y = m_BirdsEyeMarkerObjectSizeMultiplier;
                m_BirdsEyeMarkerObjectSizeVector.z = m_BirdsEyeMarkerObjectSizeMultiplier;

                m_BirdsEyeMarkerLineMultiplier = m_BirdsEyeMarkerObjectSizeMultiplier;

                SimulatorSettings.getAnimationManager().m_IndicatorLineWidth = m_BirdsEyeMarkerObjectSizeMultiplier / 3;
            }
            else
            {
                m_BirdsEyeView = a_Bool;

                if(m_CurrentEntity.getEntityID() == 0)
                {
                    m_CurrentEntity.SetPosition(m_OriginalEntityPosition);
                    m_CurrentEntity.SetRotation(m_OriginalEntityRotation);
                }

                if (m_OriginalEntity != m_CurrentEntity) switchtoVehicleByID(m_OriginalEntity.m_EntityID);

                Quadcopter l_Quad = m_MainCameraDrone.GetComponent<Quadcopter>();

                if (l_Quad)
                {
                    l_Quad.toggleSpeedMode(m_OriginalSpeedMode);

                }

                m_ViewSettings.setCameraHeight(m_OriginalCamHeight);
                m_ViewSettings.setCameraDistance(m_OriginalCamDistance);

                m_ViewSettings.SetViewPivotRotation(m_OriginalCamPivotRotation);
                m_EnableMouseViewRotation = m_OriginalMouseViewRotation;

                m_MouseClickPanEnabled = false;

                m_BirdsEyeMarkerObjectSizeVector.x = 1;
                m_BirdsEyeMarkerObjectSizeVector.y = 1;
                m_BirdsEyeMarkerObjectSizeVector.z = 1;

                m_BirdsEyeMarkerLineMultiplier = 1;

                m_BirdsEyeMarkerHeightMultiplier = 1;

                SimulatorSettings.getAnimationManager().m_IndicatorLineWidth = 1;
            }
        }
    }

    public void AddExtraCamera(int a_ID, int a_Display)
    {
        Entity l_Entity = SimulatorSettings.getEntityList().getEntityByVIBEID(a_ID);

        if (l_Entity)
        {
            Transform l_Transform = l_Entity.getCameraAttachPoint();

            if(l_Transform)
            {
                GameObject l_ChildCameraObject = Instantiate(m_ViewSettings.m_MainCamera.gameObject, l_Transform);
                Camera l_ChildCamera = l_ChildCameraObject.GetComponent<Camera>();

                l_ChildCameraObject.name = "ExtraCam-" + m_ExtraCameras.Count;
                l_ChildCameraObject.transform.localPosition = Vector3.zero;

                l_ChildCamera.fieldOfView = m_ViewSettings.m_VerticalFOV;

                m_ExtraCameras.Add(l_ChildCamera);

                SimulatorSettings.getEnvironmentManager().AddSlavedUnderwaterRenderer(l_ChildCamera);
                SimulatorSettings.getEnvironmentManager().m_EnviroSky.InitImageEffects();

                EnviroSkyRendering l_SkyRend = l_ChildCamera.GetComponent<EnviroSkyRendering>();

                if (l_SkyRend) l_SkyRend.ExternalStart();

                Hydroform.HydroMultiCamComp l_Hydro = l_ChildCamera.GetComponent<Hydroform.HydroMultiCamComp>();

                //LuxWater.LuxWater_UnderWaterRendering l_Master = l_ChildCamera.GetComponent<LuxWater.LuxWater_UnderWaterRendering>();
                //LuxWater.LuxWater_UnderwaterRenderingSlave l_Slave = l_ChildCamera.GetComponent<LuxWater.LuxWater_UnderwaterRenderingSlave>();

                //if (l_Slave) l_Slave.ExternalStart(l_Master);

                // Needs this toggle or it won't render right for some resaon
                l_ChildCamera.orthographic = true;
                l_ChildCamera.orthographic = false;

                l_ChildCamera.targetDisplay = a_Display;
                l_ChildCamera.rect = new Rect(0, 0, 1, 1);
            }
        }
    }

    public void AddExtraCamera(float a_Lat, float a_Lon, float a_Ele, float a_X, float a_Y, float a_Z, int a_Display)
    {
        //GameObject l_ChildCameraObject = Instantiate(m_ViewSettings.m_MainCamera.gameObject);
        //Camera l_ChildCamera = l_ChildCameraObject.GetComponent<Camera>();

        //l_ChildCameraObject.name = "ExtraCam-" + m_ExtraCameras.Count;
        //l_ChildCameraObject.transform.position = new Vector3(a_X, a_Y, a_Z);

        //l_ChildCamera.fieldOfView = m_ViewSettings.m_VerticalFOV;

        //m_ExtraCameras.Add(l_ChildCamera);

        //SimulatorSettings.getEnvironmentManager().AddSlavedUnderwaterRenderer(l_ChildCamera);
        //SimulatorSettings.getEnvironmentManager().m_EnviroSky.InitImageEffects();

        Vector3 l_XYZPosition = GPSEncoder.GPSToUCS(a_Lat, a_Lon);
        l_XYZPosition.y = a_Ele;

        GameObject l_ChildCameraObject = Instantiate(m_ViewSettings.m_MainCamera.gameObject);
        Camera l_ChildCamera = l_ChildCameraObject.GetComponent<Camera>();

        l_ChildCameraObject.name = "ExtraCam-" + m_ExtraCameras.Count;
        l_ChildCameraObject.transform.position = l_XYZPosition;
        l_ChildCameraObject.transform.rotation = Quaternion.Euler(a_X, a_Y, a_Z);

        l_ChildCamera.fieldOfView = m_ViewSettings.m_VerticalFOV;

        m_ExtraCameras.Add(l_ChildCamera);

        SimulatorSettings.getEnvironmentManager().AddSlavedUnderwaterRenderer(l_ChildCamera);
        SimulatorSettings.getEnvironmentManager().m_EnviroSky.InitImageEffects();

        EnviroSkyRendering l_SkyRend = l_ChildCamera.GetComponent<EnviroSkyRendering>();

        if (l_SkyRend) l_SkyRend.ExternalStart();

        Hydroform.HydroMultiCamComp l_Hydro = l_ChildCamera.GetComponent<Hydroform.HydroMultiCamComp>();

        //LuxWater.LuxWater_UnderWaterRendering l_Master = l_ChildCamera.GetComponent<LuxWater.LuxWater_UnderWaterRendering>();
        //LuxWater.LuxWater_UnderwaterRenderingSlave l_Slave = l_ChildCamera.GetComponent<LuxWater.LuxWater_UnderwaterRenderingSlave>();

        //if (l_Slave) l_Slave.ExternalStart(l_Master);

        // Needs this toggle or it won't render right for some resaon
        l_ChildCamera.orthographic = true;
        l_ChildCamera.orthographic = false;

        l_ChildCamera.targetDisplay = a_Display;
        l_ChildCamera.rect = new Rect(0, 0, 1, 1);

    }

    public void removeExtraCameras()
    {
        for (int i = m_ExtraCameras.Count-1; i >= 0; i--)
        {
            Destroy(m_ExtraCameras[i]);
        }

        m_ExtraCameras.Clear();
    }

    public void Reset()
    {
        EnableMouseViewRotation(true);
        EnableScrollwheelZoom(true);
    }

    public void EnableDynaCam(bool a_Bool)
    {
        m_DynaCam.gameObject.SetActive(a_Bool);
    }

    public void AssignDynaCam(Entity a_Entity)
    {
        if (m_DynaCam && m_DynaCamJoint)
        {
            if (!m_DynaCam.gameObject.activeInHierarchy) EnableDynaCam(true);
            SimulatorSettings.getUIManager().EnableDynaCamUI(true);
            m_DynaCamTarget = a_Entity;

            m_DynaCamJoint.transform.SetParent(m_DynaCamTarget.m_ControlObjects.gameObject.transform);

            m_DynaCamStandOffVector = Vector3.zero;
            m_DynaCamStandOffVector.x = m_DynaCamTarget.m_ModelBounds.extents.x + m_DynaCamStandoffDistance;
            m_DynaCamRotationVector = Vector3.zero;
            m_DynaCamRotationVector.y = -90;

            m_DynaCamJoint.gameObject.transform.localPosition = m_DynaCamStandOffVector;
            m_DynaCamJoint.gameObject.transform.rotation = Quaternion.Euler(m_DynaCamRotationVector);

            m_DynaCamBlankRotationVector = Vector3.zero;
            m_DynaCamBlankRotationVector.z = m_DynaCamTarget.m_ModelBounds.extents.x + m_DynaCamStandoffDistance;

            m_DynaCamPanVector = Vector3.zero;
            m_DynaCam.transform.localPosition = m_DynaCamPanVector;

            RefreshDynaCam();
        }
    }

    public void AssignStaticCam(Entity a_Entity)
    {
        
    }

    public void UnassignDynaCam()
    {
        if (m_DynaCam && m_DynaCamJoint)
        {
            if (m_DynaCam.gameObject.activeInHierarchy) EnableDynaCam(false);
            SimulatorSettings.getUIManager().EnableDynaCamUI(false);
            m_DynaCamTarget = null;

            m_DynaCamJoint.transform.SetParent(m_CameraCategory.transform);
        }
    }

    public void RefreshDynaCam()
    {
        Slider_DynaCamZoom(0);
        Slider_DynaCamRotation(-.5f);
    }

    public void Slider_DynaCamZoom(float a_Zoom)
    {
        m_DynaCamZoom = (1 - a_Zoom);
        //Debug.Log("Slider_DynaCamZoom: " + a_Zoom);
        m_DynaCam.fieldOfView = m_MaxZoom * m_DynaCamZoom;
    }

    public void Slider_DynaCamRotation(float a_Rot)
    {
        //Debug.Log("Slider_DynaCamRotation: " + a_Rot);
        m_DynaCamRotation = a_Rot * 180;

        m_DynaCamPanVector = m_DynaCam.transform.localPosition;
        m_DynaCam.transform.localPosition = Vector3.zero;

        m_DynaCamJoint.transform.localPosition = m_DynaCamBlankRotationVector;
        m_DynaCamJoint.transform.rotation = Quaternion.LookRotation(m_DynaCamTarget.transform.position - m_DynaCam.transform.position);
        m_DynaCamJoint.transform.RotateAround(m_DynaCamTarget.transform.position, Vector3.up, m_DynaCamRotation);

        m_DynaCam.transform.localPosition = m_DynaCamPanVector;
    }

    public void DynaCamPan(float a_X, float a_Y)
    {
        m_DynaCamPanVector = m_DynaCam.transform.localPosition;
        m_DynaCamPanVector.x += a_X;
        m_DynaCamPanVector.y += a_Y;

        m_DynaCam.transform.localPosition = m_DynaCamPanVector;
    }

    public void CloseDynaCam()
    {
        SimulatorSettings.getUIManager().EnableDynaCamUI(false);
        EnableDynaCam(false);
    }

    public void SetCinematicMode(bool a_Bool)
    {
        m_CinematicMode = a_Bool;

        if(m_CinematicMode)
        {
            m_MainCameraDrone.CinematicMode(true);
        }
        else
        {
            m_MainCameraDrone.CinematicMode(false);
        }
    }

    public void SaveCameraState()
    {
        if (SimulatorSettings.getAnimationManager().ContainsEntityFollower(m_CurrentEntity))
        {
            Debug.Log("Saving relative position");
            SaveRelCameraPosition();

            m_SavedPositionIsRelative = true;
        }
        else
        {
            Debug.Log("Saving global position");
            SaveCameraPosition();

            m_SavedPositionIsRelative = false;
        }
            
        SaveCameraAngle();
        m_HasSavedPosition = true;
    }

    public void SaveRelCameraState()
    {
        SaveRelCameraPosition();
        SaveCameraAngle();

        m_HasSavedPosition = true;
        m_SavedPositionIsRelative = true;
    }

    void SaveRelCameraPosition()
    {
        if (SimulatorSettings.getAnimationManager().ContainsEntityFollower(m_CurrentEntity))
        {
            EntityFollower l_Pair = SimulatorSettings.getAnimationManager().GetEntityFollowPair(m_CurrentEntity);

            m_SavedEntityFollowingID = l_Pair.TargetID;
            m_SavedPos = l_Pair.Offset;
            m_SavedRot = m_CurrentEntity.transform.rotation.eulerAngles;

            m_SavedCamPosString = "RELPOS " + m_SavedPos.x + " " + m_SavedPos.y + " " + m_SavedPos.z;
            m_SavedCamRotString = "ROT " + m_SavedRot.x + " " + m_SavedRot.y + " " + m_SavedRot.z;
            Debug.Log("Saved following " + m_SavedEntityFollowingID);
        }
    }

    void SaveCameraPosition()
    {
        m_SavedPos = m_MainCameraDrone.currentXYZPosition;
        m_SavedRot = m_MainCameraDrone.transform.rotation.eulerAngles;

        m_SavedCamPosString = "GPS " + m_SavedPos.x + " " + m_SavedPos.y + " " + m_SavedPos.z;
        m_SavedCamRotString = "ROT " + m_SavedRot.x + " " + m_SavedRot.y + " " + m_SavedRot.z;
    }

    void SaveCameraAngle()
    {
        m_SavedCamDist = m_ViewSettings.m_Distance;
        m_SavedCamHeight = m_ViewSettings.m_CameraHeight;
        m_SavedCamPan = m_ViewSettings.m_PanAmount;
        m_SavedCamX = m_ViewSettings.m_RotationX;
        m_SavedCamY = m_ViewSettings.m_RotationY;

        m_SavedCamViewString = "VIEW " + m_SavedCamDist + " " + m_SavedCamHeight + " " + m_SavedCamPan + " " + m_SavedCamX + " " + m_SavedCamY;
    }

    public string GetSavedCamPosString()
    {
        return m_SavedCamPosString;
    }

    public string GetSavedCamRotString()
    {
        return m_SavedCamRotString;
    }

    public string GetSavedCamViewString()
    {
        return m_SavedCamViewString;
    }

    public void LoadCameraState()
    {
        if(m_HasSavedPosition)
        {
            LoadCameraPosition();
            LoadCameraAngle();
        }
    }

    void LoadCameraPosition()
    {
        if (m_SavedPositionIsRelative)
        {
            SimulatorSettings.getAnimationManager().AddEntityFollower(0, m_SavedEntityFollowingID, m_SavedPos, false, false);
        }
        else
        {
            m_MainCameraDrone.SetPosition(m_SavedPos);
        }

        Debug.Log("Setting rotation to: " + m_SavedRot);
        m_MainCameraDrone.SetRotation(m_SavedRot);
    }

    void LoadCameraAngle()
    {
        m_ViewSettings.SetViewRotation(m_SavedCamDist, m_SavedCamHeight, m_SavedCamPan, m_SavedCamX, m_SavedCamY);
    }

    public void SetSavedPos(float a_Lat, float a_Lon, float a_Alt)
    {
        Vector3 l_Vec = new Vector3(a_Lat, a_Lon, a_Alt);

        SetSavedPos(l_Vec);
    }

    public void SetSavedPos(Vector3 a_Pos)
    {
        m_SavedPos = a_Pos;
        m_SavedCamPosString = "GPS " + m_SavedPos.x + " " + m_SavedPos.y + " " + m_SavedPos.z;
    }

    public void SetSavedRot(float a_X, float a_Y, float a_Z)
    {
        Vector3 l_Vec = new Vector3(a_X, a_Y, a_Z);

        SetSavedRot(l_Vec);
    }

    public void SetSavedRot(Vector3 a_Rot)
    {
        m_SavedRot = a_Rot;

        m_SavedCamRotString = "ROT " + m_SavedRot.x + " " + m_SavedRot.y + " " + m_SavedRot.z;
    }

    public void SetSavedView(float a_Dist, float a_Height, float a_Pan, float a_X, float a_Y)
    {
        Vector3 l_Vec3 = new Vector3(a_Dist, a_Height, a_Pan);
        Vector3 l_Vec2 = new Vector2(a_X, a_Y);

        SetSavedView(l_Vec3, l_Vec2);
    }

    public void SetSavedView(Vector3 a_DistHeightPan, Vector2 a_XY)
    {
        m_SavedCamDist = a_DistHeightPan.x;
        m_SavedCamHeight = a_DistHeightPan.y;
        m_SavedCamPan = a_DistHeightPan.z;

        m_SavedCamX = a_XY.x;
        m_SavedCamY = a_XY.y;

        m_SavedCamViewString = "VIEW " + m_SavedCamDist + " " + m_SavedCamHeight + " " + m_SavedCamPan + " " + m_SavedCamX + " " + m_SavedCamY;
    }

    public void ToggleCrosshair()
    {
        ToggleCrosshair(!m_ViewSettings.m_TargetMode);
    }

    public void ToggleCrosshair(bool a_Bool)
    {
        m_ViewSettings.m_TargetMode = a_Bool;
    }

    public void ToggleFirstPersonMode()
    {
        m_FirstPersonMode = !m_FirstPersonMode;

        if(m_FirstPersonMode)
        {
            m_PreFPSFOV = m_ViewSettings.m_HorizontalFOV;
            m_ViewSettings.setTotalCameraFOV(m_FPSFOV);
        }
        else
        {
            m_ViewSettings.setTotalCameraFOV(m_PreFPSFOV);
        }

        Debug.Log("FirstPersonMode: " + m_FirstPersonMode);

        int l_Temp = m_CurrentEntityID;
        switchtoVehicleByID(0);
        switchtoVehicleByID(l_Temp);
    }

    public void ToggleFullscreen()
    {
        ToggleFullscreen(!m_Fullscreen);
    }

    public void ToggleFullscreen(bool a_Bool)
    {
        m_Fullscreen = a_Bool;
        Screen.fullScreen = m_Fullscreen;

        if (Screen.fullScreen)
        {
            Screen.fullScreenMode = FullScreenMode.FullScreenWindow;
        }
        else
        {
            Screen.fullScreenMode = FullScreenMode.Windowed;
        }
    }

    public void SetVolumePercent_Master(int a_VolPercent)
    {
        Debug.Log("<color=red>Setting Master Volume to" + a_VolPercent + "% </color>");
        SetVolume(a_VolPercent, "m_MasterVolume");
    }

    public void SetVolumePercent_Env(int a_VolPercent)
    {
        Debug.Log("<color=red>Setting Env Volume to" + a_VolPercent + "% </color>");
        SetVolume(a_VolPercent, "m_EnvVolume");
    }

    public void SetVolumePercent_Entity(int a_VolPercent)
    {
        Debug.Log("<color=red>Setting Entity Volume to" + a_VolPercent + "% </color>");
        SetVolume(a_VolPercent, "m_EntitiesVolume");
    }

    public void SetVolume(int a_VolPercent, string a_Mixer)
    {
        m_Volume_Percent = a_VolPercent;

        if (m_Volume_Percent <= 0) m_Volume_Decimal = 0.0001f;
        else if (m_Volume_Percent >= 100) m_Volume_Decimal = 1.0f;
        else
        {
            m_Volume_Decimal = m_Volume_Percent;
            m_Volume_Decimal = m_Volume_Decimal / 100.0f;
        }

        SetVolume(m_Volume_Decimal, a_Mixer);
    }

    public void SetVolume(float a_VolDecimal, string a_Mixer)
    {
        if (a_VolDecimal <= 0.0001f) m_Volume_Decimal = 0.0001f;
        else if (a_VolDecimal >= 1.0f) m_Volume_Decimal = 1.0f;
        else m_Volume_Decimal = a_VolDecimal;

        m_Volume_DB = Mathf.Log10(m_Volume_Decimal) * 20;

        Debug.Log("Volume Decimal Requestion: " + a_VolDecimal + "Volume(Raw): " + m_Volume_Decimal + "Volume(%): " + m_Volume_Percent + "Volume(DB): " + m_Volume_DB);

        m_AudioMixer.SetFloat(a_Mixer, m_Volume_DB);
    }

    public void AddAudioSource(ref AudioSource a_Source)
    {
        if(m_AudioMixer)
        {
            a_Source.outputAudioMixerGroup = m_AudioMixer.FindMatchingGroups("Master")[0];

            Debug.Log("Added audio source: " + a_Source.gameObject.name);
        }
    }

    public void ApplyEnvironmentSound_AboveWater()
    {
        SetVolume(1.0f, "m_AbovewaterVolume");
        SetVolume(0.0f, "m_BelowwaterVolume");
    }

    public void ApplyEnvironmentSound_BelowWater()
    {
        SetVolume(0.0f, "m_AbovewaterVolume");
        SetVolume(1.0f, "m_BelowwaterVolume");
    }

    public void PlaySoundEffect(Transform a_Target, string a_SoundEffectName)
    {
        Debug.Log("PlaySoundEffect: " + a_SoundEffectName);
        if (m_SoundEffectLibrary.ContainsKey(a_SoundEffectName))
        {
            //Debug.Log(a_SoundEffectName + " added.");
            GameObject l_NewObj = Instantiate(m_SoundEffectLibrary[a_SoundEffectName].gameObject);
            l_NewObj.transform.SetParent(a_Target);
            l_NewObj.SetActive(true);
        }
        //else
        //{
        //    Debug.Log(a_SoundEffectName + " not found. Size: " + m_SoundEffectLibrary.Count + " - Contents are: ");

        //    foreach (KeyValuePair<string, AudioSource> entry in m_SoundEffectLibrary)
        //    {
        //        Debug.Log("   " + entry.Value.gameObject.name);
        //    }
        //}
    }
}

//if (m_CurrentEntityIndex == 0)
//{

//    displayName = "Free Camera";

//    followCameraScript.enabled = true;

//    //if (followCameraScript.target != m_CurrentVehicle.transform) StartCoroutine(disableFollowCamera());

//    flyingCameraAnchor.GetComponent<ExtendedFlycam>().mouseMode = false;
//    flyingCameraAnchor.GetComponent<ExtendedFlycam>().enabled = true;
//    m_ActiveCameraObject.GetComponent<ViewSettings>().setFreeCameraMode(false);
//}
//else
//{
//    if (m_CurrentVehicle.GetComponent<Entity>().getDisplayName() != null)
//    {
//        displayName = m_CurrentVehicle.GetComponent<Entity>().getDisplayName();
//    }
//    else displayName = "Vehicle: " + m_CurrentEntityIndex.ToString();

//    followCameraScript.enabled = true;

//    m_ActiveCameraObject.GetComponent<ViewSettings>().setFreeCameraMode(true);
//}

//for (int i = 0; i < m_NumberOfCameras; i++)
//{
//    Camera l_Camera = m_ViewSettings.m_ChildCameras[i];

//    if (l_Camera.targetDisplay == a_PreviousDisplayIndex)
//    {
//        l_CameraIndexA = i;
//        l_CameraAssignedToPreviousDisplayLocated = true;
//    }
//    else if (l_Camera.targetDisplay == a_NewDisplayIndex)
//    {
//        l_CameraIndexB = i;
//        l_CameraAssignedToNewDisplayLocated = true;
//    }
//}

//if(l_CameraAssignedToPreviousDisplayLocated)
//{
//    if(l_CameraAssignedToNewDisplayLocated)
//    {
//        m_ViewSettings.m_ChildCameras[l_CameraIndexA].targetDisplay = a_NewDisplayIndex;
//        m_ViewSettings.m_ChildCameras[l_CameraIndexB].targetDisplay = a_PreviousDisplayIndex;
//    }
//    else
//    {
//        m_ViewSettings.m_ChildCameras[l_CameraIndexA].targetDisplay = a_NewDisplayIndex;
//    }
//}
//else
//{
//    Debug.Log("Error: No camera is assigned that target display");
//}