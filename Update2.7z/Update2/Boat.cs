﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

public class Boat : Surface
{
    [Header("Boat Module")]
    public bool m_BoatClassStarted = false;
    public bool m_BoatClassInitialized = false;

    public float m_CurrentTargetSpeed = 0.0f;
    public float m_CurrentTargetSpeedInM = 0.0f;

    public float m_CurrentSpeedInKnots = 0.0f;
    public float m_DesiredSpeedInKnots = 0.0f;

    public List<Transform> m_Motors;
    public float m_RotationTorque = 5.0f;

    public bool m_BuoyancyEnabled = true;
    public Buoyancy m_BuoyancyScript;
    public BoxCollider m_BuoyancyCollider;
    public bool m_ForceResizeBuoyancyCollider;
    public bool m_ForceAddMotor = false;

    public ForceMode m_ForceMode = ForceMode.Acceleration;

    public WaterInterface m_Ocean;

    public bool m_UpdateBuoyancyOnFixedUpdate = true;

    public float m_RotationAngle = 0.2f;
    public float m_RotationDirectionMulitplier = 1.0f;

    public float m_ForceMultiplier;
    public float m_TurningFactor = 100.0F;

    public Transform m_DockingPoint;

    public bool m_IsStatic;
    public bool m_NoPhys;

    public int m_ChildrenSMMTTID;
    public bool m_HasLaunchableSystems;
    public bool m_HasInfiniteLaunchableSystems;
    public List<Entity> m_LaunchableSystems = new List<Entity>();
    public List<Entity> m_LaunchedSystems = new List<Entity>();
    public Entity m_CurrentActiveSystem;

    public GameObject m_RampObj;
    public LoadingRamp m_Ramp;

    public bool m_Flying;

    public int m_CurrentLoadoutIndex;

    public bool m_RetractionStarted;
    public bool m_RetractionComplete;
    public bool m_PlatformDeployed;

    public float m_RetractionSpeed = 1f;

    public int m_LoadoutToStartWith = 0;

    public LaunchBayController m_LaunchBay;
    public USV_LaunchBayController m_USVLaunchBay;
    public bool m_LoadingInProgress;
    public bool m_LaunchBayOpen;
    public Entity m_EntityBeingLoaded;

    public bool m_UnloadInProgress;

    public ParticleSystem m_Wake;
    public GameObject m_WakeObject;
    public List<ParticleSystem> m_WakeList = new List<ParticleSystem>();
    public List<ParticleSystem> m_MiddleWakeList = new List<ParticleSystem>();
    public ParticleSystem.MainModule m_Main;

    public List<float> m_WakeEmissionRateOverTimeList = new List<float>();
    public List<float> m_WakeEmissionRateOverDistanceList = new List<float>();

    public Color m_WakeColor = Color.white;
    public float m_SunLightIntensity;
    public float m_Mod = 20;

    public bool m_LocalRotationReturningToIdentity;

    public Cable_Procedural_Simple m_SecondaryTether;
    public Transform m_SecondaryTetherPoint;

    public float m_CurrentLifetime;
    public float m_OriginalLifetime;
    public float m_ZeroLifetime = 0;
    public bool m_WakeActive;
    public float m_SpeedMagnitude;

    Vector3 m_TempVec;

    public Transform m_GrappleConnectionPoint;

    public float m_CurrentSimSpeed;

    public float m_LaunchBackForce = 5;
    public float m_LaunchDownForce = 2;

    public bool m_WaitingForArrivalOfChild;
    public bool m_HoldBeforeLaunching;
    public bool m_WireToLauncher;
    public float m_ReelSpeed = 15;
    public float m_ReelDist = 50;

    public AudioSource m_EngineNoise_1;
    public AudioSource m_EngineNoise_2;

    public float m_MinimumIdle = 0.3f;

    public override bool getInitialized()
    {
        return m_BoatClassInitialized;
    }

    public Boat()
    {
        //Debug.Log("[" + this.GetType().ToString() + "] Constructor called.");
    }

    ~Boat()
    {
        //Debug.Log("[" + this.GetType().ToString() + "] Destructor called.");
    }

    public override bool ExternalStart()
    {
        return StartBoatClass();
    }

    public bool StartBoatClass()
    {
        m_EntityInitialized = false;
        m_EntityStarted = true;

        StartEntityClass();

        if (m_EntityInitialized)
        {
            m_BoatClassStarted = true;
            m_BoatClassInitialized = false;

            InitializeBoatClass();

            if (m_BoatClassInitialized)
            {
                Debug.Log("[" + this.GetType().ToString() + "] " + gameObject.name + " Initialized successfully.");
                return true;
            }
            else
            {
                Debug.Log("[" + GetType() + "] " + gameObject.name + " Failed to initialize.");
                return false;
            }
        }

        return false;
    }

    void InitializeBoatClass()
    {
        if (!m_BoatClassInitialized)
        {
            if (!SimulatorSettings.getInitialized())
            {
                Debug.Log("Failed to Start: " + gameObject.name + " . SimulatorSettings not initialized.");
                m_BoatClassInitialized = false;
                return;
            }

            m_Ocean = SimulatorSettings.getEnvironmentManager().getOcean();

            m_EntityStarted = true;

            if(m_EntitySMMTTID == 99 || m_EntitySMMTTID == 120)
            {
                m_MaxSpeed = SimulatorSettings.getEntityList().m_LCACSpeed;
                m_TurningSpeed = SimulatorSettings.getEntityList().m_LCACTurningSpeed;
                m_Acceleration = SimulatorSettings.getEntityList().m_LCACAccel;
                m_Decceleration = SimulatorSettings.getEntityList().m_LCACDeccel;
            }

            if (!m_IsSavedPrefab)
            {
                m_RigidBody.useGravity = true;
                m_RigidBody.isKinematic = false;
            }

            if (m_BuoyancyEnabled)
            {

                if (m_BuoyancyScript == null)
                {
                    m_BuoyancyScript = gameObject.GetComponent<Buoyancy>();
                    if (m_BuoyancyScript == null)
                    {
                        Debug.Log(gameObject.name + " needs a buoyancy script.");
                        m_BoatClassInitialized = false;
                    }
                }
                if (m_BuoyancyCollider == null)
                {
                    m_BuoyancyCollider = m_ControlObjects.GetControlObject("BuoyancyCollider").GetComponent<BoxCollider>();
                    if (m_BuoyancyCollider == null)
                    {
                        Debug.Log(gameObject.name + " needs a box collider.");
                        m_BoatClassInitialized = false;
                    }

                    m_BuoyancyCollider.center = Vector3.zero;
                    m_BuoyancyCollider.size = new Vector3(1, 1, 1);
                    resizeBuoyancyCollider();
                    m_BuoyancyScript.setCollider(m_BuoyancyCollider);
                    m_BuoyancyScript.useFixedUpdate = m_UpdateBuoyancyOnFixedUpdate;
                    m_BuoyancyScript.enabled = true;
                }
                else if (!m_IsSavedPrefab)
                {
                    resizeBuoyancyCollider();
                }

                m_BuoyancyCollider.gameObject.SetActive(false);
            }

            if(m_IsStatic)
            {
                m_RigidBody.isKinematic = true;
                m_BuoyancyCollider.gameObject.SetActive(false);
            }

        if (m_Flying)
            {
                m_RigidBody.isKinematic = false;
                m_RigidBody.useGravity = false;
            }
            else
            {
                m_RigidBody.useGravity = true;
            }

            m_BoatClassInitialized = true;

            if (m_IsMovableObject)
            {
                if(m_MaxSpeed == 0)
                {
                    m_MaxSpeed = 40;
                }

            }

            if (m_CenterOfMass != null)
            {
                m_RigidBody.centerOfMass = m_CenterOfMass.localPosition;
            }
            else
            {
                m_RigidBody.ResetCenterOfMass();
            }

            //if(m_LineMaterial == null)
            //{
            //    m_LineMaterial = SimulatorSettings.getAnimationManager().m_WaypointLineMaterial;
            //}

            if (!m_SystemLaunchPoint)
            {
                if (m_ControlObjects.HasControlObject("SystemLaunchPoint"))
                {
                    m_SystemLaunchPoint = m_ControlObjects.GetControlObject("SystemLaunchPoint").transform;
                }
            }

            Entity[] l_Launchables = transform.GetComponentsInChildren<Entity>();

            foreach (Entity l_Entity in l_Launchables)
            {
                if(l_Entity != this)
                {
                    m_LaunchableSystems.Add(l_Entity);
                    if (l_Entity.m_HasSensors) l_Entity.SetSensorsActive(false);
                    if(l_Entity.m_WaypointModule)
                    {
                        l_Entity.m_WaypointModule.m_LineToNextWaypoint.enabled = false;
                        l_Entity.m_WaypointModule.m_WaypointIndicator.enabled = false;
                    }
                }
            }

            if (m_SystemLaunchPoint)
            {
                foreach (Entity l_Entity in m_LaunchableSystems)
                {
                    if(l_Entity)
                    {
                        Debug.Log("Setting the position of launchable system: " + l_Entity.m_EntityName);
                        l_Entity.SetPosition(m_SystemLaunchPoint.position);
                    }

                }
            }

            if(m_Ramp == null)
            {
                m_RampObj = m_ControlObjects.GetControlObject("LoadingRampAnimation");
                if(m_RampObj != null)
                {
                    m_Ramp = m_RampObj.GetComponent<LoadingRamp>();
                }
            }

            //foreach (GameObject l_Loadout in m_Loadouts)
            //{
            //    Entity l_Entity = l_Loadout.GetComponent<Entity>();

            //    if (l_Entity)
            //    {
            //        l_Loadout.SetActive(true);
            //        l_Entity.AttachToEntity(this);
            //        //l_Entity.ExternalStart();
            //        l_Loadout.SetActive(false);
            //    }
            //}

            if ((m_LoadoutToStartWith >= 0) && (m_LoadoutToStartWith < m_Loadouts.Count))
            {
                ActivateLoadout(m_LoadoutToStartWith);
            }

            m_DesiredSpeedInKnots = 0;

            m_RetractionStarted = false;

            //if (!SimulatorSettings.getEnvironmentManager().m_EntitiesSendingSonarRings.Contains(this))
            //{
            //    SimulatorSettings.getEnvironmentManager().m_EntitiesSendingSonarRings.Add(this);
            //}

            if(m_LaunchableSystems.Count > 0)
            {
                foreach (Entity l_Ent in m_LaunchableSystems)
                {
                    if(l_Ent)
                    {
                        if (!SimulatorSettings.getEntityList().containsID(l_Ent.m_EntityID))
                        {
                            SimulatorSettings.getEntityList().addEntity(l_Ent);
                        }
                    }
                }
            }

            if(m_WakeObject)
            {
                m_WakeList.Clear();
                m_MiddleWakeList.Clear();

                foreach(ParticleSystem l_Particle in m_WakeObject.transform.GetComponentsInChildren<ParticleSystem>())
                {
                    m_WakeList.Add(l_Particle);
                    m_OriginalLifetime = l_Particle.startLifetime;
                    if (l_Particle.name.Contains("Middle"))
                    {
                        m_MiddleWakeList.Add(l_Particle);
                    }

                    m_WakeEmissionRateOverTimeList.Add(l_Particle.emission.rateOverTimeMultiplier);
                    m_WakeEmissionRateOverDistanceList.Add(l_Particle.emission.rateOverDistanceMultiplier);
                }

                SetMiddleWakeActive(true);
            }
        }
        else
        {
        }
        

    }

    void UpdateOptionToggles()
    {
        if (m_ForceRestart)
        {
            m_EntityInitialized = false;
            m_BoatClassInitialized = false;

            m_ForceRestart = false;
        }
        if (m_ForceResizeBuoyancyCollider)
        {
            resizeBuoyancyCollider();
            m_TargetZone.createModelBoxCollider();
            m_ForceResizeBuoyancyCollider = false;
        }
        if (m_ForceAddMotor)
        {
            ClearMotors();
            AddMotor();
            m_ForceAddMotor = false;
        }
    }

    void UpdateCenterOfMass()
    {
        if (m_CenterOfMass != null)
        {
            m_RigidBody.centerOfMass = m_CenterOfMass.localPosition;
        }
    }

    void Update()
    {
        if (!m_BoatClassInitialized)
        {
            InitializeBoatClass();
        }
        else
        {
            m_CurrentSimSpeed = SimulatorSettings.getSimSpeed();
            if(m_WakeActive) UpdateWakeSpeed();

            if (m_EntityIsSinking && gameObject.transform.position.y <= -30)
            {
                if(m_BuoyancyScript)
                {
                    m_BuoyancyScript.enabled = false;
                }
            }

            if (m_IsLoaded)
            {
                m_RigidBody.useGravity = false;
                m_RigidBody.isKinematic = true;

                if(m_Wake)
                {
                    if(m_Wake.isPlaying)
                    {
                        m_Wake.Stop();
                    }
                }
            }
            else if (m_IsFalling)
            {
                m_RigidBody.useGravity = true;
                m_RigidBody.isKinematic = false;

                m_HeightOfWater = SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(transform.position.x, transform.position.z);

                if(m_Transform.position.y < m_HeightOfWater)
                {
                    m_IsFalling = false;

                    if (m_Wake)
                    {
                        if (m_Wake.isStopped)
                        {
                            m_Wake.Play();
                        }
                    }

                    Unpause();
                }
            }
            else if(m_IsStatic)
            {
                m_RigidBody.useGravity = false;
                m_RigidBody.isKinematic = true;
            }
            else if(m_NoPhys)
            {
                m_RigidBody.useGravity = false;
                m_RigidBody.isKinematic = false;
            }
            else if (m_IsLocked)
            {
                m_RigidBody.isKinematic = true;
                m_RigidBody.useGravity = false;
            }
            else
            {
                m_RigidBody.useGravity = true;
                m_RigidBody.isKinematic = false;
            }

            if(m_LocalRotationReturningToIdentity)
            {
                if(m_Transform.localRotation != Quaternion.identity)
                {
                    m_Transform.localRotation = Quaternion.Euler(Vector3.MoveTowards(m_Transform.localRotation.eulerAngles, Quaternion.identity.eulerAngles, Time.deltaTime * 4));
                }
                else
                {
                    m_LocalRotationReturningToIdentity = false;
                }
            }
            UpdateOptionToggles();
            UpdateCenterOfMass();
            Update_EntityClass();
            UpdateAnimations();

            UpdateWaypointVisualization();

            if (m_RetractionStarted)
            {
                if (m_ActiveSensor)
                {
                    if (m_ActiveSensor.m_ReadyToRetractPlatform)
                    {
                        m_ActiveSystem.m_RigidBody.useGravity = false;
                        m_ActiveSystem.m_RigidBody.isKinematic = true;

                        if (m_ActiveSensor.m_UseJoint)
                        {
                            m_ActiveSensor.m_UseJoint = false;
                            m_ActiveSensor.m_Joint.enabled = false;
                        }

                        RetractSystem(m_Loadouts[m_CurrentLoadoutIndex]);
                    }
                    else if (!m_ActiveSensor.m_RetractingLaunchedSystems)
                    {
                        m_ActiveSensor.RetractSystems();
                    }
                }
            }

            if (Application.isPlaying && m_MovementEnabled)
            {
                //switch (m_ControlType)
                //{
                //    case EntityControlType.PLAYER:
                //        UpdatePosition_Player();
                //        break;
                //    case EntityControlType.SCRIPT:
                //        UpdatePosition_Script();
                //        break;
                //    case EntityControlType.NETWORK:
                //        UpdatePosition_Network();
                //        break;
                //    case EntityControlType.WAYPOINT:
                //        UpdatePosition_Network();
                //        break;
                //    default:
                //        break;
                //}

                if (m_DesiredSpeedInKnots > m_MaxSpeed) m_DesiredSpeedInKnots = m_MaxSpeed;
                if (m_DesiredSpeedInKnots < -m_MaxReverseSpeed) m_DesiredSpeedInKnots = -m_MaxReverseSpeed;

                UpdateMotion(); // Update object motion according to the boat script
                Update_Children();
            }

            if (m_WakeObject)
            {
                m_SpeedMagnitude = Mathf.Abs(m_CurrentSpeed);
                if (m_SpeedMagnitude <= 0.1)
                {
                    if(m_WakeActive)
                    {
                        m_WakeActive = false;
                        SetWakeActive(false);
                    }
                }
                else
                {
                    if (!m_WakeActive)
                    {
                        m_WakeActive = true;
                        SetWakeActive(true);
                    }
                }
            }

            //if(m_WakeObject)
            //{
            //    if (Mathf.Abs(m_CurrentSpeed) <= 0.1)
            //    {
            //        if(m_WakeObject.activeInHierarchy)
            //        {
            //            m_WakeObject.SetActive(false);
            //        }
            //    }
            //    else
            //    {
            //        if (!m_WakeObject.activeInHierarchy)
            //        {
            //            m_WakeObject.SetActive(true);
            //        }
            //    }
            //}

            if(m_EngineNoise_1 || m_EngineNoise_2)
            {
                if (m_DesiredSpeedInKnots == 0) m_EngineVolume = m_MinimumIdle;
                else if (m_DesiredSpeedInKnots > 0) m_EngineVolume = m_DesiredSpeedInKnots / m_MaxSpeed;
                else m_EngineVolume = Mathf.Abs(m_DesiredSpeedInKnots / m_MaxSpeed);

                if (m_EngineVolume < m_MinimumIdle) m_EngineVolume = m_MinimumIdle;
                else if (m_EngineVolume > 1.0f) m_EngineVolume = 1.0f;

                if(m_EngineNoise_1) m_EngineNoise_1.volume = m_EngineVolume;
                if (m_EngineNoise_2) m_EngineNoise_2.volume = m_EngineVolume;
            }
        }
        
    }

    public void Update_Children()
    {
        if(m_HasLaunchableSystems)
        {
            foreach(Entity l_Entity in m_LaunchedSystems)
            {
                //l_Entity.ChildUpdate();
            }
        }
    }

    public override void UpdatePosition_Player()
    {
        //if (m_EntityGear == EntityGear.FORWARD)
        //{
        //    m_DesiredSpeedInKnots = m_MaxSpeed * m_LVerticalInput;
        //}
        //else
        //{
        //    m_DesiredSpeedInKnots = m_MaxSpeed * -m_LVerticalInput;
        //}
        m_DesiredSpeedInKnots = m_MaxSpeed * m_LVerticalInput;
        m_DesiredHeading = m_CurrentHeading + (m_LHorizontalInput * m_TurningSpeed);
    }

    public override void UpdatePosition_Script()
    {
        //m_DesiredSpeedInKnots = m_MaxSpeed * m_LVerticalInput;
        //m_DesiredHeading = m_CurrentHeading + (m_LHorizontalInput * m_TurningSpeed);
    }

    void UpdateAnimations()
    {
        if(m_EntitySMMTTID == 95)
        {
            Update_LaunchBay();
        }
        else if (m_EntitySMMTTID == 104)
        {
            Update_USVLaunchBay();
        }

        if (m_IsTarget)
        {
            if ((m_CurrentHullPoints <= 0) && (!m_EntityIsSinking) && m_EntityInitialized)
            {
                Debug.Log("Gameobject (" + gameObject.name + ") has started sinking. (HP: " + m_CurrentHullPoints + ").");

                SimulatorSettings.getAnimationManager().CreateExplosion(transform.position, 8, 5);
                StartSinking();

                SimulatorSettings.getAnimationManager().CreateShipFire(this, 0, 7);

                if (m_WaypointModule.m_Playing)
                {
                    m_WaypointModule.m_Playing = false;
                    m_ControlType = EntityControlType.NONE;
                }
            }
            if (m_EntityIsSinking)
            {
                //Debug.Log("Gameobject (" + gameObject.name + ") continues to sink - Current Y is: " + transform.position.y);
                m_RigidBody.mass = (float)(m_RigidBody.mass * (1 + (.01 * m_SinkingSpeed)));

                if (m_ParticleList.ContainsKey("Bubbles"))
                {
                    if(m_ParticleList["Bubbles"] != null)
                    {
                        m_ParticleList["Bubbles"].Stop();
                    }
                }

                //if ((gameObject.transform.position.y <= -10) && (gameObject.transform.position.y > -30))
                if ((gameObject.transform.position.y <= -10) && (gameObject.transform.position.y > -30))
                   
                {
                    if (m_ParticleList.ContainsKey("Smoke"))
                    {
                        if (m_ParticleList["Smoke"] != null)
                        {
                            m_ParticleList["Smoke"].Stop();
                        }
                        else
                        {
                            m_ParticleList.Remove("Smoke");
                        }
                    }
                    if (m_ParticleList.ContainsKey("ShipFire"))
                    {
                        if (m_ParticleList["ShipFire"] != null)
                        {
                            m_ParticleList["ShipFire"].Stop();
                        }
                        else
                        {
                            m_ParticleList.Remove("ShipFire");
                        }
                    }

                }
                //else if (gameObject.transform.position.y <= -30)
                else if (gameObject.transform.position.y <= m_HeightOfLand + 1)
                {
                    if (!m_ParticleList.ContainsKey("Smoke"))
                    {
                        if (!Application.isEditor)
                        {
                            ParticleSystem l_PS = m_ParticleList["Smoke"];
                            m_ParticleList.Remove("Smoke");
                            Destroy(l_PS);

                            l_PS = m_ParticleList["ShipFire"];
                            m_ParticleList.Remove("ShipFire");
                            Destroy(l_PS);
                        }
                    }

                    DisableParticles();
                    m_EntitySunkToTheBottom = true;
                }
            }
        }

        // FIXME this needs wider implementation in the Entity or Vehicle class

        if (m_SteeringWheel)
        {
            m_SteeringWheelCurrentTurnAngle = m_SteeringWheel.transform.localRotation.eulerAngles.y;
            m_SteeringWheelCurrentTurnSpeed = 0;

            m_WheelPosLeft = false;
            m_WheelPosRight = false;
            m_TurningLeft = false;
            m_TurningRight = false;
            m_LeftMax = false;
            m_RightMax = false;

            if (m_SteeringWheelCurrentTurnAngle <= 180)
            {
                m_SteeringWheelCurrentMaxTurnAngle = m_SteeringWheelMaxTurnAngle;
                m_WheelPosRight = true;
            }
            else
            {
                m_SteeringWheelCurrentMaxTurnAngle = (360 - m_SteeringWheelMaxTurnAngle);
                m_WheelPosLeft = true;
            }

            if (m_LHorizontalInput < 0) // Input Left
            {
                if(m_WheelPosLeft)
                {
                    if (m_SteeringWheelCurrentTurnAngle >= (360 - m_SteeringWheelMaxTurnAngle))
                    {
                        m_TurningLeft = true;
                        m_SteeringWheelCurrentTurnSpeed = (-m_LHorizontalInput * m_SteeringWheelTurnSpeed * Time.deltaTime) * m_SteeringWheelMaxTurnAngle;
                    }
                    else m_LeftMax = true;
                }
                else
                {
                    m_TurningLeft = true;
                    m_SteeringWheelCurrentTurnSpeed = (-m_LHorizontalInput * m_SteeringWheelTurnSpeed * Time.deltaTime) * m_SteeringWheelMaxTurnAngle;
                }
            }
            if (m_LHorizontalInput > 0) // Input Right
            {
                if(m_WheelPosRight)
                {
                    if (m_SteeringWheelCurrentTurnAngle <= m_SteeringWheelMaxTurnAngle)
                    {
                        m_TurningRight = true;
                        m_SteeringWheelCurrentTurnSpeed = (-m_LHorizontalInput * m_SteeringWheelTurnSpeed * Time.deltaTime) * m_SteeringWheelMaxTurnAngle;
                    }
                    else m_RightMax = true;
                }
                else
                {
                    m_TurningRight = true;
                    m_SteeringWheelCurrentTurnSpeed = (-m_LHorizontalInput * m_SteeringWheelTurnSpeed * Time.deltaTime) * m_SteeringWheelMaxTurnAngle;
                }
            }

            if (m_SteeringWheelCurrentTurnSpeed != 0) m_SteeringWheel.Rotate(m_SteeringWheelAxis, m_SteeringWheelCurrentTurnSpeed, Space.Self);
        }
    }

    public Transform m_SteeringWheel;
    public float m_SteeringWheelTurnSpeed = 1.0f;
    public float m_SteeringWheelCurrentTurnAngle;
    public float m_SteeringWheelCurrentTurnLocalAngle;
    public float m_SteeringWheelCurrentTurnSpeed;
    public Vector3 m_SteeringWheelAxis = new Vector3(1, 1, 0);
    public float m_SteeringWheelMaxTurnAngle = 180.0f;
    public float m_SteeringWheelCurrentMaxTurnAngle = 180.0f;
    public bool m_WheelPosLeft;
    public bool m_WheelPosRight;
    public bool m_TurningLeft;
    public bool m_TurningRight;
    public bool m_LeftMax;
    public bool m_RightMax;
    
    void Update_LaunchBay()
    {
        if (m_LoadingInProgress)
        {
            if (!m_LaunchBayOpen)
            {
                if (m_LaunchBay.m_State == LaunchBayController.LaunchBayState.OPEN)
                {
                    if (!m_LaunchBay.m_AnimationInProgress)
                    {
                        if (!m_WaitingForArrivalOfChild)
                        {
                            Debug.Log("Triggering Doors to Close");
                            m_LaunchBayOpen = true;

                            m_LaunchBay.TriggerLaunchAnimation();
                            m_EntityBeingLoaded.transform.SetParent(m_SurfaceVehicleAttachPoint);
                            m_EntityBeingLoaded.transform.localPosition = Vector3.zero;
                            m_LaunchBay.Update_AnchorPoints(m_EntityBeingLoaded);
                        }
                            
                    }
                }
            }
            else
            {
                if (m_LaunchBay.m_State == LaunchBayController.LaunchBayState.CLOSED)
                {
                    if (!m_LaunchBay.m_AnimationInProgress)
                    {
                        //m_EntityBeingLoaded.transform.SetParent(m_SurfaceVehicleAttachPoint);
                        //m_EntityBeingLoaded.transform.localPosition = Vector3.zero;

                        Debug.Log("Triggering Doors to Close");

                        m_LaunchBayOpen = false;
                        m_EntityBeingLoaded = null;
                        m_LoadingInProgress = false;

                        SetMiddleWakeActive(true);
                    }
                }
            }
        }
        else if (m_UnloadInProgress)
        {
            //Debug.Log("m_UnloadInProgress");

            if (!m_LaunchBayOpen)
            {
                //Debug.Log("m_LaunchBayOpen: " + m_LaunchBayOpen);

                if (m_LaunchBay.m_State == LaunchBayController.LaunchBayState.OPEN)
                {
                    if (!m_LaunchBay.m_AnimationInProgress)
                    {
                        LaunchVehicle();

                        if (m_HoldBeforeLaunching)
                        {
                            //Debug.Log("m_HoldBeforeLaunching");
                            return;
                        }

                        if (m_EntityBeingLoaded.m_Paused)
                        {
                            m_EntityBeingLoaded.Pause(false);
                        }

                        if (!m_EntityBeingLoaded.m_IsLaunchSystem)
                        {
                            m_LaunchBay.ReleaseAnchorPoints();

                            m_EntityBeingLoaded.m_RigidBody.useGravity = true;
                            m_EntityBeingLoaded.m_IsLoaded = false;
                        }

                        m_LaunchBay.StopAnchorPoints();

                        m_LaunchBayOpen = true;
                        m_LaunchBay.TriggerLaunchAnimation();
                    }
                }
            }
            else
            {
                //Debug.Log("m_LaunchBayOpen: " + m_LaunchBayOpen);
                if (m_LaunchBay.m_State == LaunchBayController.LaunchBayState.CLOSED)
                {
                    if (!m_LaunchBay.m_AnimationInProgress)
                    {

                        m_LaunchBayOpen = false;
                        m_EntityBeingLoaded = null;
                        m_LoadingInProgress = false;
                        m_LaunchBay.Update_AnchorPoints(null);

                        //Debug.Log("[Entity] Animation finished");
                        SetMiddleWakeActive(true);
                    }
                }
            }
        }
    }

    void Update_USVLaunchBay()
    {
        if (m_UnloadInProgress)
        {
            if (!m_USVLaunchBay.m_AnimationInProgress)
            {
                LaunchSystem();
            }
        }
    }

    public override void setSpeed(int a_Speed)
    {
        m_DesiredSpeedInKnots = a_Speed;
    }

    public override void setSpeedOverride(int a_Speed)
    {
        m_DesiredSpeedInKnots = a_Speed;
        m_CurrentSpeed = a_Speed;
    }

    public override void setHeading(float a_Heading, float a_TurningSpeed = -1)
    {
        m_DesiredHeading = a_Heading;

        if(a_TurningSpeed != -1)
        {
            m_TurningSpeed = a_TurningSpeed;
        }
    }

    void resizeBuoyancyCollider()
    {
        GameObject l_RootObject = m_ModelLoader.m_Model;
        Bounds l_Bounds = m_ModelLoader.getModelBounds();
        
        BoxCollider l_Collider = m_BuoyancyCollider;
        if (l_Collider != null)
        {
            l_Collider.center = l_Bounds.center - l_RootObject.transform.position;
            l_Collider.size = l_Bounds.size;

            l_Collider.size = new Vector3(l_Collider.size.x, l_Collider.size.y / 2, l_Collider.size.z);
            l_Collider.center = new Vector3(l_Collider.center.x, l_Collider.center.y - (l_Collider.size.y / 2), l_Collider.center.z);
        }
    }

    void ClearMotors()
    {
        m_Motors.Clear();
    }

    void AddMotor()
    {
        GameObject l_Motor = m_ControlObjects.GetControlObject("Motor");
        if(l_Motor == null)
        {
            //Debug.Log("Adding new motor to " + gameObject.name);
            l_Motor = new GameObject("Motor");
            l_Motor.transform.position = new Vector3(m_ModelBounds.center.x, m_ModelBounds.min.y, m_ModelBounds.min.z);
            l_Motor.transform.parent = m_ControlObjects.gameObject.transform;

            m_ControlObjects.AddControlObject("Motor", l_Motor);
        }
        else
        {
            //Debug.Log("Using stored motor");
                
        }
    }

    void UpdateMotion()
    {
        if (m_DesiredSpeedInKnots > 0)
        {
            if (m_CurrentTargetSpeed < m_DesiredSpeedInKnots) // If you are going slower than your target, accelerate.
            {
                m_CurrentTargetSpeed += m_Acceleration * Time.deltaTime;
            }
            else if (m_CurrentTargetSpeed > m_DesiredSpeedInKnots) // If you are going faster than your target, decelerate/
            {
                m_CurrentTargetSpeed -= m_Decceleration * Time.deltaTime;
            }
        }
        else if (m_DesiredSpeedInKnots < 0)
        {
            if (m_CurrentTargetSpeed < m_DesiredSpeedInKnots)
            {
                m_CurrentTargetSpeed += m_Decceleration * Time.deltaTime;
            }
            else if (m_CurrentTargetSpeed > m_DesiredSpeedInKnots)
            {
                m_CurrentTargetSpeed -= m_Acceleration * Time.deltaTime;
            }
        }
        else
        {
            //m_CurrentTargetSpeed = 0;

            if (m_CurrentTargetSpeed < m_DesiredSpeedInKnots)
            {
                m_CurrentTargetSpeed += m_Decceleration * Time.deltaTime;
            }
            else if (m_CurrentTargetSpeed > m_DesiredSpeedInKnots)
            {
                m_CurrentTargetSpeed -= m_Decceleration * Time.deltaTime;
            }
        }

        m_CurrentTargetSpeedInM = m_CurrentTargetSpeed / knotsToMeters;


        if (!(m_ControlType == EntityControlType.PLAYER))
        {
            if(m_ControlType == EntityControlType.SCRIPT)
            {
                if (m_CurrentHeading != m_DesiredHeading)
                {
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_ScriptControllerTurningSpeed);
                }
            }

            else if (m_ControlType == EntityControlType.NETWORK)
            {
                if(m_UseExternalPhysics)
                {
                    
                }
                else if (m_CurrentHeading != m_DesiredHeading)
                {
                    SetPosition(Vector3.Lerp(transform.position, m_CurrentXYZDestination, Time.deltaTime));
                    if (m_WaypointModule.m_NumberOfPositionWaypoints == 0)
                    {
                        transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_TurningSpeed);
                    }
                    else if (m_WaypointModule.m_NumberOfPositionWaypoints > 0)
                    {
                        transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_ScriptControllerTurningSpeed);
                        //transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_ScriptControllerTurningSpeed);
                    }
                }
            }
            else if (m_ControlType == EntityControlType.WAYPOINT)
            {
                if(!m_IsLoaded)
                {
                    if (m_WaypointModule.m_NumberOfPositionWaypoints > 0)
                    {
                        transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_ScriptControllerTurningSpeed);
                        //transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_ScriptControllerTurningSpeed);
                    }
                }
            }

            else if (m_CurrentHeading != m_DesiredHeading)
            {
                if (!m_IsLoaded)
                {
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, m_DesiredHeading, 0), Time.deltaTime * m_TurningSpeed);
                }
                //Vector3 torque = new Vector3(0f, m_TurningSpeed, 0f);
                //Vector3 torqueForce = (torque.normalized * m_RigidBody.mass * m_RotationTorque);
                //m_RigidBody.AddRelativeTorque(m_LHorizontalInput * torqueForce);
            }

            float l_Drag = 1;

            if (m_RigidBody.drag > 1)
            {
                l_Drag = m_RigidBody.drag;
            }


            if (m_Motors.Count > 0) // If there are motors attached, apply force divided among them
            {
                foreach (Transform l_Motor in m_Motors)
                {
                    m_RigidBody.AddRelativeForce(Vector3.forward * (m_CurrentTargetSpeedInM / m_Motors.Count), m_ForceMode);
                }
            }
            else
            {
                m_RigidBody.AddRelativeForce(Vector3.forward * m_CurrentTargetSpeedInM, m_ForceMode);
            }
        }
        else
        {
            applyForceEqualToSpeed(m_CurrentTargetSpeedInM);
            applyRotationEqualToInput();
        }
        
    }

    private void applyRotationEqualToInput()
    {
        addRotation(m_LHorizontalInput);

        if ((m_LTriggerInput != 0) || (m_RTriggerInput != 0))
        {
            float l_Rotation = 0;

            if ((m_LTriggerInput == 1) && (m_RTriggerInput == 0))
            {
                l_Rotation = -1.0f;
            }
            else if ((m_LTriggerInput == 0) && (m_RTriggerInput == 1))
            {
                l_Rotation = 1.0f;
            }
            else if ((m_LTriggerInput == 1) && (m_RTriggerInput == 1))
            {
                l_Rotation = 0;
            }

            if (l_Rotation != 0)
            {
                addRotation(l_Rotation);
            }
        }
    }

    private void applyForceEqualToSpeed(float desiredSpeed) //Input should be in meters
    {
        Vector3 motionDirection = Vector3.forward;

        if (m_RigidBody.drag < 1) m_RigidBody.AddRelativeForce(desiredSpeed * motionDirection, ForceMode.Acceleration);
        else m_RigidBody.AddRelativeForce(desiredSpeed * motionDirection * m_RigidBody.drag, ForceMode.Acceleration);
        //Debug.Log("m_RigidBody.velocity: " + m_RigidBody.velocity + "m_RigidBody.velocity.mag: " + m_RigidBody.velocity.magnitude);
        m_RigidBody.velocity = Vector3.ClampMagnitude(m_RigidBody.velocity, m_MaxSpeed * knotsToMeters);

        return;

            

 

            Vector3 force = (motionDirection * m_RigidBody.mass * desiredSpeed);
            force = (m_RigidBody.drag * force) / (1 - 0.02f * m_RigidBody.drag);
            


            //m_RigidBody.AddRelativeForce(Vector3.forward * desiredSpeed, m_ForceMode);
            m_RigidBody.AddRelativeForce(force * m_ForceMultiplier, ForceMode.Force);

        

        //m_rigidbody.AddRelativeTorque(
        //    m_verticalInput * -m_accelerationTorqueFactor,
        //    m_horizontalInput * m_turningFactor * m_rigidbody.mass * m_rigidbody.drag,
        //    m_horizontalInput * -m_turningTorqueFactor
        //);

        //rotateMotors();
        //calculateAudio()
    }

    void addRotation(float a_HorizontalInput)
    {
        //m_TurningSpeed = a_HorizontalInput * m_RotationDirectionMulitplier;
        transform.Rotate(new Vector3(0, 1, 0), a_HorizontalInput * m_TurningSpeed);

        if (a_HorizontalInput != 0)
        {
            Vector3 torque = new Vector3(0f, m_TurningFactor, 0f);
            Vector3 torqueForce = (torque.normalized * m_RigidBody.mass * m_TurningFactor);
            m_RigidBody.AddRelativeTorque(a_HorizontalInput * torqueForce);

            //m_rigidbody. (m_motors[0].transform.position, m_horizontalInput * torqueForce);

            //Debug.Log("torque: " + torque.normalized + " - torqueForce: " + torqueForce);
        }
    }

    void StartSinking()
    {
        m_EntityIsSinking = true;
        m_CurrentHullPoints = -1;
        m_RigidBody.useGravity = true;
        m_RigidBody.isKinematic = false;

        m_HeightOfWater = SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(transform.position.x, transform.position.z);
        m_HeightOfLand = SimulatorSettings.getEnvironmentManager().GetHeightOfLandAtPoint(transform.position.x, transform.position.z);

        addSmoke();
    }

    public override void On_DEFAULT_POSUPDATE()
    {

    }

    public override void OnState_DETECTION()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_COMPLETE()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_LAUNCHING()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_EFFECTOR_MISSED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_ACTUATED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_CLASSIFIED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_DETECTED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_MINE_NEUTRALIZED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_N81DEMOAQUAD_ARRIVED_AT_SHIP()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_DEFAULT_POSUPDATE()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void OnState_OBJECT_DISABLED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        if(!m_EntityIsSinking && m_EntityInitialized)
        {
            if(m_ControlType == EntityControlType.NETWORK && SimulatorSettings.getAnimationManager().m_NetworkAllowedToSinkShips)
            {
                if (!m_EntityStartedSinking)
                {
                    //Instantiate(SimulatorSettings.getAnimationManager().getPrefabObject("Explosion"), transform.position, transform.rotation);

                    Debug.Log("Gameobject (" + gameObject.name + ") has started sinking due to getting an Object Disabled message.");
                    m_AcceptNewUpdates = false;
                    m_MovementEnabled = false;

                    //StartSinking();

                    //m_EntityStartedSinking = true;

                    m_CurrentHullPoints = -1;
                }
            }
        }
    }

    public override void OnState_SYSTEM_LAUNCHED()
    {
        Debug.Log("[Helo] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        if(m_USVLaunchBay)
        {
            if(m_ActiveSystem)
            {
                UnloadFromCurrentEntity(m_ActiveSystem);
            }
            
            
        }
        else LaunchSystem();
    }

    public override void OnState_SYSTEM_COMPLETE()
    {
        Debug.Log("[Helo] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        m_RetractionStarted = true;
    }

    public void LaunchSystem()
    {
        if (m_EntitySMMTTID == 102)
        {
            if (m_LaunchableSystems.Count > 0)
            {
                Debug.Log(m_EntityName + " is launching system.");

                Entity l_Entity = m_LaunchableSystems[0];

                l_Entity.m_RigidBody.isKinematic = false;
                l_Entity.m_RigidBody.useGravity = true;

                m_ActiveSensor = l_Entity as Sensor;
                m_ActiveSystem = l_Entity;

                m_ActiveSensor.m_Unreeling = true;

                m_ActiveSensor.transform.SetParent(null);

                //m_ActiveSensor.m_ScriptControllerTurningSpeed = m_ScriptControllerTurningSpeed;

                m_ActiveSensor.ExternalStart();

                m_ActiveSensor.m_IsFalling = true;
                if (m_ActiveSensor.m_UsingDelayedFollowScript) m_ActiveSensor.m_DelayedFollowScript.m_Active = true;
                m_LaunchedSystems.Add(m_LaunchableSystems[0]);
                m_LaunchableSystems.RemoveAt(0);

                if (m_SecondaryTetherPoint)
                {
                    Debug.Log("Setting cable point to: " + m_SecondaryTetherPoint.gameObject.name);
                    m_ActiveSensor.m_Tether.endPointTransform = m_SecondaryTetherPoint;
                }

                m_ActiveSensor.m_RigidBody.AddForce(-m_Transform.forward * m_LaunchBackForce);
                m_ActiveSensor.m_RigidBody.AddForce(-m_Transform.up * m_LaunchDownForce);

                m_PlatformDeployed = true;
                m_ActiveSensor.m_IsLoaded = false;
            }
        }
        else if (m_EntitySMMTTID == 103)
        {
            if(m_AttachedEntities.Count > 0)
            {
                if (typeof(Artillery).IsAssignableFrom(m_AttachedEntities[0].GetType()))
                {
                    SimulatorSettings.getEffectorLauncher().blindLaunch(m_AttachedEntities[0], 2302, 5);
                }
            }
        }
        else if (m_EntitySMMTTID == 104 || m_EntitySMMTTID == 106)
        {
            Debug.Log("m_LaunchableSystems" + m_LaunchableSystems.Count);

            if (m_ActiveSensor == null) Debug.Log("No sensor");
            else Debug.Log("Got sensor");

            if (m_LaunchableSystems.Count > 0 && (m_ActiveSensor==null))
            {
                Debug.Log(m_EntityName + " is launching system.");

                Entity l_Entity = m_LaunchableSystems[0];

                l_Entity.m_RigidBody.isKinematic = true;
                l_Entity.m_RigidBody.useGravity = false;

                m_ActiveSensor = l_Entity as Sensor;
                m_ActiveSystem = l_Entity;

                m_ActiveSensor.transform.SetParent(null);

                if(m_ActiveSensor.m_Tether) m_ActiveSensor.m_Tether.gameObject.SetActive(true);

                //m_ActiveSensor.m_ScriptControllerTurningSpeed = m_ScriptControllerTurningSpeed;
                m_ActiveSensor.m_Unreeling = true;
                m_ActiveSensor.ExternalStart();

                m_ActiveSensor.SetSensorsVisible(false);

                m_LaunchedSystems.Add(m_LaunchableSystems[0]);
                m_LaunchableSystems.RemoveAt(0);

                if (m_EntitySMMTTID == 104)
                {
                    if (m_SecondaryTether && m_SecondaryTetherPoint)
                    {
                        m_SecondaryTether.endPointTransform = m_SecondaryTetherPoint;
                    }
                }
                 

                if(m_EntitySMMTTID == 106)
                {
                    m_ActiveSensor.setState(EntityState.WAYPOINTS_START);

                    if (m_SecondaryTetherPoint)
                    {
                        Debug.Log("Setting cable point to: " + m_SecondaryTetherPoint.gameObject.name);
                        m_ActiveSensor.m_Tether.endPointTransform = m_SecondaryTetherPoint;
                    }
                }
                m_PlatformDeployed = true;
            }
        }
        //else if (m_Loadouts.Count > 0)
        //{
        //    Sensor l_Sensor = m_Loadouts[0].GetComponent<Sensor>();

        //    if (l_Sensor)
        //    {
        //        if (l_Sensor.m_EntitySMMTTID == 2103)
        //        {

        //        }
        //    }
        //}
    }

    void RetractSystem(GameObject a_Platform)
    {
        m_ActiveSystem.transform.position = Vector3.MoveTowards(m_ActiveSystem.transform.position, m_SystemLaunchPoint.position, Time.deltaTime * m_RetractionSpeed * m_CurrentSimSpeed);

        if (m_ActiveSystem.transform.position == m_SystemLaunchPoint.position)
        {
            Debug.Log("Finished retraction");
            m_Loadouts[m_CurrentLoadoutIndex].GetComponent<Entity>().AttachToEntity(this);
            m_ActiveSystem.m_RigidBody.useGravity = false;
            m_ActiveSystem.m_RigidBody.isKinematic = true;
            m_RetractionStarted = false;
            m_PlatformDeployed = false;
        }
    }

    public override void OnState_SYSTEM_TURNED_ON()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);
    }

    public override void Restore()
    {
        base.Restore();

        m_EntityIsSinking = false;
        m_EntityStartedSinking = false;
        m_EntitySunkToTheBottom = false;
        m_BuoyancyScript.enabled = true;
    }



    //void ReachedGPSWaypoint()
    //{
    //    Debug.Log("EntityName: " + m_EntityName + " arrived at Waypoint: " + m_GPSWaypoints[0]);

    //    m_GPSWaypoints.RemoveAt(0);
    //    m_DisplayWaypoints.RemoveAt(0);
    //}

    void UpdateWaypointVisualization()
    {
        //if (SimulatorSettings.getAnimationManager().m_WaypointTracksVisible)
        //{
        //    if (m_WaypointIndicator == null)
        //    {
        //        GameObject l_Object = new GameObject("WaypointIndicator");
        //        l_Object.transform.SetParent(m_ControlObjects.transform);
        //        int l_Layer = 0;
        //        l_Layer |= (1 << LayerMask.NameToLayer("TransparentFX"));
        //        l_Object.layer = l_Layer;
        //        m_ControlObjects.AddControlObject("WaypointIndicator", l_Object);

        //        m_WaypointIndicator = l_Object.AddComponent<LineRenderer>();
        //        //m_WaypointIndicator.material = m_LineMaterial;
        //    }

        //    if (m_LineToNextWaypoint == null)
        //    {
        //        GameObject l_Object = new GameObject("LineToNextWaypoint");
        //        l_Object.transform.SetParent(m_ControlObjects.transform);
        //        int l_Layer = 0;
        //        l_Layer |= (1 << LayerMask.NameToLayer("TransparentFX"));
        //        l_Object.layer = l_Layer;
        //        m_ControlObjects.AddControlObject("LineToNextWaypoint", l_Object);

        //        m_LineToNextWaypoint = l_Object.AddComponent<LineRenderer>();
        //        //m_LineToNextWaypoint.material = m_LineMaterial;
        //        m_LineToNextWaypoint.positionCount = 2;
        //    }

        //    m_LineToNextWaypoint.gameObject.SetActive(true);
        //    m_WaypointIndicator.gameObject.SetActive(true);

        //    if (m_GPSWaypoints.Count > 0)
        //    {
        //        m_WaypointIndicator.positionCount = m_GPSWaypoints.Count;

        //        m_LineToNextWaypoint.SetPosition(0, transform.position);

        //        for (int i = 0; i < m_GPSWaypoints.Count; i++)
        //        {
        //            Vector3 l_Vec;

        //            l_Vec = GPSEncoder.GPSToUCS(m_GPSWaypoints[i].Position.x, m_GPSWaypoints[i].Position.y);
        //            l_Vec.y = m_GPSWaypoints[i].Position.z;
        //            m_WaypointIndicator.SetPosition(i, l_Vec);

        //            if (i == 0)
        //            {
        //                m_LineToNextWaypoint.SetPosition(1, l_Vec);
        //            }

        //        }


        //    }
        //}
        //else
        //{
        //    if (m_WaypointIndicator)
        //    {
        //        m_WaypointIndicator.gameObject.SetActive(false);
        //    }
        //    if (m_LineToNextWaypoint)
        //    {
        //        m_LineToNextWaypoint.gameObject.SetActive(false);
        //    }
        //}
    }

    //void UpdateWaypointScript()
    //{
    //    if (m_WaypointsStarted)
    //    {
    //        if (m_GPSWaypoints.Count > 0)
    //        {
    //            if (m_GPSWaypoints[0].State == EntityState.UNKNOWN) // This means this is not a state update, but a position update or rotation update
    //            {
    //                m_DesiredSpeedInKnots = m_ScriptControllerForwardSpeed;

    //                //m_WaypointIndicator.gameObject.SetActive(true);

    //                Vector3 l_Destination = GPSEncoder.GPSToUCS(m_GPSWaypoints[0].Position.x, m_GPSWaypoints[0].Position.y);

    //                var heading = l_Destination - transform.position;

    //                var distance = GetDistanceIgnoringY(l_Destination, transform.position);

    //                var direction = heading / distance;

    //                m_DesiredHeading = Quaternion.LookRotation((heading).normalized).eulerAngles.y;

    //                if (distance < 1)
    //                {
    //                    ReachedGPSWaypoint();
    //                }
    //            }
    //            else
    //            {

    //                Debug.Log("EntityName: " + m_EntityName + " set its state to " + m_GPSWaypoints[0].State);

    //                setState(m_GPSWaypoints[0].State);

    //                ReachedGPSWaypoint();

    //                setState(EntityState.DEFAULT_POSUPDATE);
    //            }
    //        }
    //        else
    //        {
    //            m_DesiredSpeedInKnots = 0;
    //            m_DesiredHeading = transform.position.y;
    //        }
    //    }
    //    else
    //    {
    //        m_DesiredSpeedInKnots = 0;
    //        m_DesiredHeading = transform.position.y;
    //    }

    //}

    float GetDistanceIgnoringY(Vector3 a_Point1, Vector3 a_Point2)
    {
        float l_Ret = -1;

        float l_X = a_Point2.x - a_Point1.x;
        l_X = l_X * l_X;

        float l_Y = a_Point2.z - a_Point1.z;
        l_Y = l_Y * l_Y;


        l_Ret = Mathf.Sqrt(l_X + l_Y);

        return l_Ret;
    }

    void DeactivateLoadouts()
    {
        ActivateLoadout(-1);
    }

    public override void OnState_SENSORS_ACTIVATED()
    {
        Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + "[" + m_EntitySMMTTID + "]) Implementing state: " + m_EntityState as string);

        m_SensorsActive = true;

        if (m_EntitySMMTTID == 102)
        {
            return;
            if (!m_ActiveSystem) return;

            //  Debug.Log("Enabling System Sensors: " + m_ActiveSystem.name);
            m_ActiveSystem.m_SensorsActive = true;

            if (m_LaunchedSystems.Count > 0)
            {
                foreach (Entity l_Entity in m_LaunchedSystems)
                {
                    //Debug.Log("Sensor Entity: " + l_Entity.m_EntityName);

                    if (l_Entity.m_HasSensors)
                    {
                        //Debug.Log("Has sensors");
                        l_Entity.SetSensorsActive(true);
                    }
                }
            }
        }
        else if(m_EntitySMMTTID == 104)
        {
            Debug.Log("Enabling System Sensors: " + m_ActiveSystem.name);
            m_ActiveSystem.m_SensorsActive = true;

            Collider l_Collider;
            foreach(GameObject l_SObj in m_ActiveSystem.m_Sensors)
            {
                //l_Sensor = l_SObj.GetComponent<DetectionSensor>();
                l_SObj.gameObject.SetActive(true);

                l_Collider = l_SObj.GetComponent<Collider>();
                if (l_Collider)
                {
                    l_Collider.enabled = true;
                }
            }
        }
        else
        {
            if (m_LaunchedSystems.Count > 0)
            {
                foreach (Entity l_Entity in m_LaunchedSystems)
                {
                    Debug.Log("Sensor Entity: " + l_Entity.m_EntityName);

                    if (l_Entity.m_HasSensors)
                    {
                        Debug.Log("Has sensors");
                        l_Entity.SetSensorsActive(true);
                    }
                }
            }
        }
    }

    public override void OnState_SENSORS_DEACTIVATED()
    {
        //Debug.Log("[Boat] " + m_EntityName + "(" + m_EntityID + ") Implementing state: " + m_EntityState as string);

        m_SensorsActive = false;

        if (m_EntitySMMTTID == 104)
        {
            Debug.Log("Disabling System Sensors: " + m_ActiveSystem.name);
            m_ActiveSystem.m_SensorsActive = true;
        }

        if (m_LaunchedSystems.Count > 0)
        {
            foreach (Entity l_Entity in m_LaunchedSystems)
            {
                if (l_Entity.m_HasSensors)
                {
                    DetectionSensor l_DSensor;

                    foreach (GameObject l_Sensor in l_Entity.m_Sensors)
                    {
                        l_Sensor.SetActive(m_SensorsActive);

                        l_DSensor = l_Sensor.GetComponentInChildren<DetectionSensor>();

                        if(l_DSensor)
                        {
                            foreach (Entity l_TempEntity in l_DSensor.m_MinesOnSensor)
                            {
                                l_TempEntity.RestoreOriginalColor();
                            }

                            l_DSensor.m_MinesOnSensor.Clear();
                        }
                    }
                }
            }
        }
    }

    public override void ExecuteSpecialAction_1()
    {
        bool l_SpecialActionPerformed = false;
        Debug.Log("[Boat] Execute Special Action 1");

        if(m_Ramp != null)
        {
            m_Ramp.TriggerAnimation();
            l_SpecialActionPerformed = true;
        }

        if (m_EntitySMMTTID == 98)
        {
            if (m_Weapon) m_Weapon.Trigger();
            l_SpecialActionPerformed = true;
        }

        if(!l_SpecialActionPerformed)
        SimulatorSettings.getDirector().PlaySoundEffect(m_Transform, "BoatHorn");
    }

    public override void ExecuteSpecialAction_2()
    {
        Debug.Log("[Boat] Execute Special Action 2");

        if (SimulatorSettings.getActiveEntity().m_EntityID == m_EntityID)
        {
            if (m_PlatformDeployed)
            {
                Debug.Log("Attempting to start retraction");
                m_RetractionStarted = true;
            }
            else
            {
                LaunchSystem();
            }
        }
    }

    public override void ExecuteSpecialAction_3()
    {
        //Debug.Log("[Quad] Execute Special Action 3");

        if (m_EntitySMMTTID == 95)
        {
            m_Weapon.StartExtend();
        }       
    }

    public override void StopSpecialAction_3()
    {
        //Debug.Log("[Quad] Stop Special Action 3");

        if (m_EntitySMMTTID == 95)
        {
            m_Weapon.StopExtend();
        }
    }

    public override void ExecuteSpecialAction_4()
    {
        //Debug.Log("[Quad] Execute Special Action 4");

        if (m_EntitySMMTTID == 95)
        {
            m_Weapon.StartRetract();
        }
    }

    public override void StopSpecialAction_4()
    {
        //Debug.Log("[Quad] Stop Special Action 4");

        if (m_EntitySMMTTID == 95)
        {
            m_Weapon.StopRetract();
        }
    }

    public override void OnState_LOAD()
    {
        Debug.Log("[Boat] Execute Load");

        m_ParentEntity.LoadOntoCurrentEntity(this, m_ParentEntity);
    }

    public override void OnState_UNLOAD()
    {
        Debug.Log("[Boat] Execute Unload");

        m_ParentEntity.UnloadFromCurrentEntity(this);
    }

    IEnumerator DisableColliders(int a_Time)
    {
        m_ControlObjects.setCollidersEnabled(false);
        yield return new WaitForSeconds(a_Time);
        m_ControlObjects.setCollidersEnabled(true);
    }

    public override void LoadOntoCurrentEntity(Entity a_Child, Entity a_Parent)
    {
        if(m_LaunchBay)
        {
            SetMiddleWakeActive(false);

            m_EntityBeingLoaded = a_Child;
            m_EntityBeingLoaded.m_RigidBody.isKinematic = true;

            m_EntityBeingLoaded.StopWaypoints();

            m_WaitingForArrivalOfChild = false;

            m_LaunchBay.Update_AnchorPoints(m_EntityBeingLoaded);

            if (typeof(Surface).IsAssignableFrom(m_EntityBeingLoaded.GetType()))
            {
                Boat l_Boat = m_EntityBeingLoaded.GetComponent<Boat>();

                Debug.Log("Loading Type: Surface");
                m_EntityBeingLoaded.transform.SetParent(a_Parent.m_SurfaceVehicleAttachPoint);
                m_EntityBeingLoaded.transform.localPosition = Vector3.zero;
                m_EntityBeingLoaded.transform.localRotation = Quaternion.identity;

                if (l_Boat.m_Wake)
                {
                    //l_Boat.m_Wake.startLifetime
                    l_Boat.m_Wake.Stop();
                }

                FakeBuoyancy l_FakeB = l_Boat.gameObject.GetComponent<FakeBuoyancy>();
                if (l_FakeB)
                {
                    l_FakeB.enabled = false;
                }

                m_LaunchBay.TriggerLaunchAnimation();
            }

            m_LoadingInProgress = true;
        }
    }

    public void OpenDoors()
    {
        if(m_LaunchBay.m_State != LaunchBayController.LaunchBayState.OPEN)
        {
            Debug.Log(m_EntityName + " is opening doors.");

            SetMiddleWakeActive(false);

            if (m_LaunchBay)
            {
                m_LaunchBay.Update_AnchorPoints(null);
                m_WaitingForArrivalOfChild = true;
                m_LaunchBay.TriggerLaunchAnimation();

                m_LaunchBayOpen = true;
                m_LoadingInProgress = true;
                m_UnloadInProgress = false;
            }
        }
    }
    public override void UnloadFromCurrentEntity(Entity a_Child)
    {
        Debug.Log(m_EntityName + " is unloading child: " + a_Child.m_EntityName);

        SetMiddleWakeActive(false);

        if (m_LaunchBay)
        {

            m_EntityBeingLoaded = a_Child;
            m_EntityBeingLoaded.Pause(true);
            m_EntityBeingLoaded.m_RigidBody.isKinematic = true;

            m_LaunchBay.Update_AnchorPoints(m_EntityBeingLoaded);

            m_LaunchBay.TriggerLaunchAnimation();

            m_UnloadInProgress = true;
        }
        else if(m_USVLaunchBay)
        {
            m_USVLaunchBay.TriggerLaunchAnimation();
            m_UnloadInProgress = true;

            if(m_EntitySMMTTID == 106)
            {
                if (m_SecondaryTetherPoint)
                {
                    Debug.Log("Setting cable point to: " + m_SecondaryTetherPoint.gameObject.name);
                    m_ActiveSensor.m_Tether.endPointTransform = m_SecondaryTetherPoint;
                }
            }
        }
    }

    public override void ArrivedAtLocation(Vector3 a_Position)
    {
        //m_TempVec = a_Position;
        //m_TempVec.y = transform.position.y; //SimulatorSettings.getEnvironmentManager().GetHeightOfWaterAtPoint(m_TempVec);
        //transform.position = m_TempVec;

        currentGPSPosition = GPSEncoder.USCToGPS(a_Position);
        previousGPSPosition = currentGPSPosition;

        m_CurrentAltitude = a_Position.y;
    }

    public override void InternalApplyExternalPhysics()
    {
        //if (m_RigidBody.useGravity) m_RigidBody.useGravity = false;
        //if (m_RigidBody.isKinematic) m_RigidBody.isKinematic = true;

        //Debug.Log("InternalApplyExternalPhysics: " + m_CurrentXYZDestination);

        if(m_ControlType == EntityControlType.NETWORK)
        {
            transform.rotation = Quaternion.Euler(transform.rotation.x, m_CurrentSimUpdate.Rotation.y, transform.rotation.z);
        }
        
        m_CurrentXYZDestination.y = transform.position.y;
        SetPosition(m_CurrentXYZDestination);

        m_DesiredAltitude = m_CurrentXYZDestination.y;
        m_DesiredHeading = m_CurrentSimUpdate.Rotation.y;
    }

    public override void OnState_SWITCH_LOADOUT_1()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        ActivateLoadout(0);
    }

    public override void OnState_SWITCH_LOADOUT_2()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        ActivateLoadout(1);
    }

    public override void OnState_SWITCH_LOADOUT_3()
    {
        Debug.Log("[Entity] " + m_EntityName + "(" + m_EntityID + ") has no implemented function for state " + m_EntityState as string + ". Using default behavior.");

        ActivateLoadout(2);
    }

    public override void LaunchVehicle()
    {
        if (!m_UnloadInProgress) return;
        if (m_EntityBeingLoaded.m_EntitySMMTTID == 200)
        {
            UUV l_UUV = m_EntityBeingLoaded.m_AttachedEntities[0].GetComponent<UUV>();

            l_UUV.StartCoroutine(DisableColliders(5));

            l_UUV.DettachFromEntity(m_EntityBeingLoaded);
            l_UUV.m_IsLoaded = false;
            l_UUV.m_RigidBody.useGravity = true;
            l_UUV.m_RigidBody.isKinematic = false;

            if(m_WireToLauncher)
            {
                if (!l_UUV.m_TetherJoint)
                {
                    l_UUV.TetherToEntity(m_EntityBeingLoaded, m_EntityBeingLoaded.transform, false);
                    l_UUV.m_TetherJoint = l_UUV.gameObject.AddComponent<DistanceJoint3D>();
                    l_UUV.m_TetherJoint.DetermineDistanceOnStart = false;
                    l_UUV.m_TetherJoint.Distance = m_ReelDist;
                    l_UUV.m_TetherJoint.m_JointActive = true;
                    l_UUV.m_TetherJoint.m_Target = m_EntityBeingLoaded;
                    l_UUV.m_TetherJoint.m_AttachToEntityWhenInRange = true;
                    l_UUV.m_TetherJoint.m_Controller = l_UUV;
                    l_UUV.m_TetherJoint.ConnectedRigidbody = m_EntityBeingLoaded.transform;
                    l_UUV.m_TetherJoint.m_LerpMultiplier = m_ReelSpeed;
                    l_UUV.m_TetherJoint.enabled = false;
                    l_UUV.DelayedEnableJoint(5, true);
                    l_UUV.m_TetheredUUV = true;
                }
            }
        }
        else
        {
            m_EntityBeingLoaded.SetParent(null);
            m_EntityBeingLoaded.m_IsFalling = true;
        }

        m_EntityBeingLoaded.m_DesiredHeading = m_DesiredHeading;

        if (!m_IsLaunchSystem)
        {
            if (m_Loadouts.Contains(m_EntityBeingLoaded.gameObject)) m_Loadouts.Remove(m_EntityBeingLoaded.gameObject);
        }

        m_EntityBeingLoaded.m_IsLoaded = false;
    }

    public void SetWakeActive(bool a_Bool)
    {
        //if (m_WakeActive == a_Bool) return;
        //else
        //m_WakeActive = a_Bool;

        foreach (ParticleSystem l_Particle in m_WakeList)
        {
            if (m_WakeActive)
            {
                //Debug.Log(l_Particle.name + " is set active");
                //l_Particle.Play();
                //l_Particle.startLifetime = m_OriginalLifetime;
                l_Particle.enableEmission = true;
            }
            else
            {
                //Debug.Log(l_Particle.name + " is set inactive");
                //l_Particle.Stop();
                // l_Particle.startLifetime = 0;
                l_Particle.enableEmission = false;
            }
        }
    }

    public void SetMiddleWakeActive(bool a_Bool)
    {
        //if (m_WakeActive == a_Bool) return;
        //else
        //m_WakeActive = a_Bool;
        int i = 0;
        Debug.Log("Middle Wake set to " + a_Bool + " - Number of MiddleWake Objs " + m_WakeList.Count);
        foreach (ParticleSystem l_Particle in m_WakeList)
        {
            if (l_Particle.name.Contains("Middle"))
            {
                //l_Particle.enableEmission = a_Bool;
                //var l_Emission = l_Particle.emission;
                var l_Velocity = l_Particle.velocityOverLifetime;
                l_Velocity.enabled = !a_Bool;

                //if (a_Bool)
                //{
                //    //l_Emission.rateOverTimeMultiplier = m_WakeEmissionRateOverTimeList[i];
                //    //l_Emission.rateOverDistanceMultiplier = m_WakeEmissionRateOverDistanceList[i];
                //}
                //else
                //{
                //    //l_Emission.rateOverTimeMultiplier = 0;
                //    //l_Emission.rateOverDistanceMultiplier = 0;
                //}

                //Debug.Log(l_Particle.name + " is set to: " + a_Bool);
            }

            i++;
            
        }
    }

    public void UpdateWakeSpeed()
    {
        m_SunLightIntensity = SimulatorSettings.getEnvironmentManager().m_SunLightIntensity;

        if(m_SunLightIntensity >= .75) m_WakeColor.a =  1;
        else m_WakeColor.a = m_SunLightIntensity / m_Mod;


        foreach (ParticleSystem a_Particle in m_WakeList)
        {
            m_Main = a_Particle.main;
            m_Main.startColor = m_WakeColor;

            if(m_CurrentSimSpeed == 0) m_Main.simulationSpeed = m_CurrentSimSpeed;
            else m_Main.simulationSpeed = 1;

            //m_Main.startColor = SimulatorSettings.getEnvironmentManager().m_SunlightModifiedFog;
        }
    }

    public override void switchEntityControl(EntityControlType a_ControlType)
    {
        if (m_EntityID == 0) return;

        //if (a_ControlType == EntityControlType.PLAYER)
        //{
        //    if (m_ControlType == EntityControlType.NETWORK || m_ControlType == EntityControlType.SCRIPT) return;
        //}
        //else if (a_ControlType == EntityControlType.SCRIPT)
        //{
        //    if (m_ControlType == EntityControlType.NETWORK) return;
        //}

        switch (m_ControlType)
        {
            case EntityControlType.WAYPOINT:
                m_CurrentTargetSpeed = m_DesiredSpeed;
                break;
            case EntityControlType.SCRIPT:
                m_CurrentTargetSpeed = m_DesiredSpeed;
                break;
            case EntityControlType.NETWORK:
                m_CurrentTargetSpeed = m_DesiredSpeed;
                break;
            default:
                
                break;
        }
        
        m_DesiredSpeed = 0;
        m_DesiredSpeedInKnots = 0;

        m_ControlType = a_ControlType;
    }
}
