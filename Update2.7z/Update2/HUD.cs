﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUD : MonoBehaviour
{
    [Header("Script Information")]
    public bool m_Initialized = false;
    public bool m_MouseCrosshairMode;
    public bool m_UpdateTextColor = false;
    public bool m_TargetLatLongInitialized;
    public bool m_ActivateCameraScaling = false;
    public bool m_IsSelecting;
    public bool m_IsBoxSelecting;
    public bool m_TextBolded;

    [Header("Host Information")]
    public Entity m_HostController;
    public EntityType m_HostType;
    public Camera m_HostCamera;
    private Transform m_HostTransform;
    public Vector3 m_HostRotationXYZ;
    public Vector3 m_LocalHostRotationXYZ;
    
    [Header("Target Information")]
    public Entity m_TargetedEntity;

    private bool m_UseLocalRotation_HPR;
    private string t_Sign;
    
    public Color m_TextColor;
    public int m_TextSize;
    EntityControlType m_PreviousControlType;



    // Timer
    [Header("Timer Info")]
    public float updateFreq = 1.0f;

    private float m_TimerHours;
    private float m_TimerMinutes;
    private float m_TimerSeconds;

    public float m_ScaleMultiplier = 1;
    public float m_CalculatedScaleFactor = 0;
    public float m_DistanceFromCamera;

    // Selection Info
    [Header("Selection Info")]
    public Rect m_SelectionBox;
    public Vector3 m_InitialClick;
    public List<Entity> m_SelectedObjects;
    public List<Entity> m_SelectedObjectsRemoveList;

    // Screen Info
    [Header("Screen Info")]
    public float m_FrustrumHeight = 0;
    public float m_FrustrumWidth = 0;

    public float m_BorderThicknessInPixles = 0;

    public float m_OriginalWidth = 0;
    public float m_OriginalHeight = 0;

    public float m_WidthScaleFactor = 0;
    public float m_HeightScaleFactor = 0;

    public float m_OriginalBorderWidth = 0;
    public float m_OriginalBorderHeight = 0;

    float m_BorderWidthScaleFactor;
    float m_BorderHeightScaleFactor;

    public int m_NumberOfCameras = 1;
    public int m_NumberOfTargetDisplays = 1;

    public int m_IndexOfHUDCamera = 0;

    public float m_ScaleFactorDivisor = 1;

    public Vector2 m_ReferenceResolution;
    public RectTransform m_Border;



    //
    [Header("Google Info")]
    public double l_GoogleLat;
    //public double l_GoogleLon;
    //public string l_GoogleLatStr;
    //public string l_GoogleLonStr;
    //public string l_GoogleUrl;
    public bool m_GoogleRefresh_Active;
    public float m_GoogleRefresh_Timer;
    public float m_GoogleRefresh_TimeBetweenUpdates = 1;
    public int m_DMSLat_Degrees;
    public int m_DMSLat_Minutes;
    public float m_DMSLat_Seconds;

    public int m_DMSLon_Degrees;
    public int m_DMSLon_Minutes;
    public float m_DMSLon_Seconds;

    public string m_DMSLat_String;
    public string m_DMSLon_String;

    public float m_DECLat;
    public string m_DECLat_Dir;
    public string m_DECLat_String;
    public float m_DECLon;
    public string m_DECLon_Dir;
    public string m_DECLon_String;

    public int m_GoogleZoomLevel = 17;
    public string m_GoogleZoomLevelString;

    public string m_GoogleAddress;
    public string m_FinalQueryString;

    /////////////// Links    

    // Text Links
    [Header("Text Links")]
    public Font m_Font;

    public Text m_Elevation;
    public Text m_Range;

    public Text TopHeading;
    public Text ViewHeading;

    public Text ID;
    public Text Type;

    public Text Lat;
    public Text Lon;

    public Text Heading;
    public Text Speed;
    public Text MaxSpeed;
    public TMPro.TextMeshProUGUI Gear;

    public Text m_FOVText;

    public Text m_TargetedEntityText;
    public Text m_TargetLat;
    public Text m_TargetLon;

    public Text m_Pitch;
    public Text m_Roll;

    public Text m_Time;

    public Text[] m_ChildrenTexts;

    public Text m_GroupIDText;
    public Text m_ThrottleValueText;

    //

    public GameObject m_WaypointsPanelObj;
    public TMPro.TextMeshProUGUI m_WaypointsScenarioText;
    public TMPro.TextMeshProUGUI m_WaypointsPausePlayButtonText;

    public TMPro.TextMeshProUGUI m_ControlTypeText;

    public GameObject m_TargetedEntityGroup;
    public GameObject m_TargetedLatGroup;
    public GameObject m_TargetedLonGroup;
    public GameObject m_Crosshair;
    public GameObject m_StaticDisplayObject;

    public GameObject m_LoadingMessage;
    public GameObject m_MasterIconObj;
    public GameObject m_ThrottleObject;
    public GameObject m_NotificationPanelObj;

    public GameObject m_ControlDisabledObj;
    public Button m_ControlDisabledButton;
    public bool m_ControlDisabledIconEnabled;

    //

    public Image m_ControlIconImage;
    public Sprite m_ControllerIcon;
    public Sprite m_KeyboardIcon;

    public Sprite m_NSIActive;
    public Sprite m_NSIInactive;

    public Image m_NSIActiveIndicator;

    // HUD Links
    [Header("HUD Links")]
    public RectTransform m_CanvasTransform;
    public Canvas m_Canvas;
    public CanvasScaler m_CanvasScaler;
    public ViewSettings m_ViewSettings;

    public GameObject origin;
    public GameObject targetVehicle;

    public Transform m_TopScreenAnchor;
    public Transform m_TopLeftScreenAnchor;
    public Transform m_TopCenterScreenAnchor;
    public Transform m_TopRightScreenAnchor;

    public Transform m_BottomScreenAnchor;
    public Transform m_BottomLeftScreenAnchor;
    public Transform m_BottomCenterScreenAnchor;
    public Transform m_BottomRightScreenAnchor;

    Vector3 m_OriginalTLAnchorPosition;
    Vector3 m_OriginalTCAnchorPosition;
    Vector3 m_OriginalTRAnchorPosition;

    Vector3 m_OriginalBRAnchorPosition;
    Vector3 m_OriginalBCAnchorPosition;
    Vector3 m_OriginalBLAnchorPosition;

    //

    // Quaternion Comparisons

    Quaternion m_QuatForward = Quaternion.Euler(Vector3.forward);
    Quaternion m_QuatUp = Quaternion.Euler(Vector3.up);
    Quaternion m_QuatRight = Quaternion.Euler(Vector3.right);

    // Manager Links
    [Header("GameObject Links")]
    public UIManager m_UIManager;
    public Director m_CameraManager;
    public NetworkMonitor m_NetMonitor;
    public EntityList m_EntityList;
    public ConfigurationManager m_ConfigurationManager;

    // Temp Variables

    int m_IntTemp;
    float t_Heading;
    float t_Speed;
    float t_MaxSpeed;


    public bool ExternalStart()
    {
        m_Initialized = false;
        Initialize();
        return m_Initialized;
    }

    void Initialize()
    {
        if (targetVehicle == null)
        {
            targetVehicle = SimulatorSettings.getActiveEntity().gameObject;
        }

        if (m_CameraManager == null)
        {
            m_CameraManager = SimulatorSettings.getDirector();
        }

        if(m_NetMonitor == null)
        {
            m_NetMonitor = SimulatorSettings.getNetworkMonitor();
        }

        if(m_ConfigurationManager == null)
        {
            m_ConfigurationManager = SimulatorSettings.getConfigManager();
        }

        if (m_StaticDisplayObject == null)
        {
            m_StaticDisplayObject = transform.Find("StaticHUDObject").gameObject;
        }

        if (m_Border == null)
        {
            m_Border = transform.Find("ViewBorder").GetComponent<RectTransform>();
        }

        m_ViewSettings = SimulatorSettings.getDirector().m_ViewSettings;

        m_CanvasTransform = gameObject.GetComponent<RectTransform>();
        m_Canvas = gameObject.GetComponent<Canvas>();
        m_CanvasScaler = gameObject.GetComponent<CanvasScaler>();

        //m_ReferenceResolution = new Vector2(m_HostCamera.pixelWidth, m_HostCamera.pixelHeight);

        m_HostCamera = m_ViewSettings.m_MainCamera;

        if (m_WidthScaleFactor == 0)
        m_OriginalWidth = m_CanvasTransform.sizeDelta.x;

        if (m_HeightScaleFactor == 0)
        m_OriginalHeight = m_CanvasTransform.sizeDelta.y;

        if (m_BorderWidthScaleFactor == 0)
            m_OriginalBorderWidth = m_Border.sizeDelta.x;

        if (m_BorderHeightScaleFactor == 0)
            m_OriginalBorderHeight = m_Border.sizeDelta.y;

        m_Border.sizeDelta = new Vector2(m_OriginalWidth + m_BorderThicknessInPixles, m_OriginalHeight + m_BorderThicknessInPixles);

        m_ChildrenTexts = GetComponentsInChildren<Text>();

        updateTextColor();

        m_NumberOfCameras = m_CameraManager.m_NumberOfCameras;

        //SetAnchors();
        if (Application.isPlaying)
        {
            attachHUDToCamera(m_HostCamera);
            gameObject.SetActive(true);
        }
        if (!Application.isPlaying)
        {
            gameObject.SetActive(false);
        }

        changeTarget(targetVehicle);

        m_TargetedEntityGroup.SetActive(false);

        m_OriginalTLAnchorPosition = m_TopLeftScreenAnchor.position;
        m_OriginalTCAnchorPosition = m_TopCenterScreenAnchor.position;
        m_OriginalTRAnchorPosition = m_TopRightScreenAnchor.position;

        m_OriginalBLAnchorPosition = m_BottomLeftScreenAnchor.position;
        m_OriginalBCAnchorPosition = m_BottomCenterScreenAnchor.position;
        m_OriginalBRAnchorPosition = m_BottomRightScreenAnchor.position;

        m_TargetLatLongInitialized = false;

        m_SelectedObjects = new List<Entity>();
        m_SelectedObjectsRemoveList = new List<Entity>();

        updateTextBold();

        m_Initialized = true;
	}
	
    public void SetAnchors()
    {
        //Debug.Log("m_CanvasTransform.referenceResolution: " + m_CanvasTransform.rect);

        float l_XPadding = 5;
        float l_YPadding = 5;

        float l_TopY = (m_CanvasTransform.rect.height / 2);
        float l_BottomY = -(m_CanvasTransform.rect.height / 2);
        float l_LeftX = (-m_CanvasTransform.rect.width / 2);
        float l_RightX = m_CanvasTransform.rect.width / 2;

        Vector2 l_ChildSize = Vector2.zero;

        // Top Screen Anchor

        //l_ChildSize = GetChildSize(m_TopScreenAnchor);
        m_TopScreenAnchor.localPosition = new Vector3(0, l_TopY - (l_ChildSize.y / 2) - l_YPadding, 0);

        //l_ChildSize = GetChildSize(m_TopLeftScreenAnchor);
        m_TopLeftScreenAnchor.localPosition = new Vector3(l_LeftX + l_ChildSize.x + l_XPadding, 0, 0);

        m_TopCenterScreenAnchor.localPosition = new Vector3(0, 0, 0);

        //l_ChildSize = GetChildSize(m_TopRightScreenAnchor);
        m_TopRightScreenAnchor.localPosition = new Vector3(l_RightX - l_ChildSize.x - l_XPadding, 0, 0);

        // Bottom Screen Anchor

        //l_ChildSize = GetChildSize(m_BottomScreenAnchor);
        m_BottomScreenAnchor.localPosition = new Vector3(0, l_BottomY + (l_ChildSize.y / 2) + l_YPadding, 0);

        //l_ChildSize = GetChildSize(m_BottomLeftScreenAnchor);
        m_BottomLeftScreenAnchor.localPosition = new Vector3(l_LeftX + l_ChildSize.x + l_XPadding, 0, 0);

        m_BottomCenterScreenAnchor.localPosition = new Vector3(0, 0, 0);

        //l_ChildSize = GetChildSize(m_BottomRightScreenAnchor);
        m_BottomRightScreenAnchor.localPosition = new Vector3(l_RightX - l_ChildSize.x - l_XPadding, 0, 0);

    }

    public Vector2 GetChildSize(Transform l_Parent)
    {
        Vector2 l_Ret = Vector2.zero;

        foreach (Transform l_Child in l_Parent.transform)
        {
            RectTransform l_Rect = l_Child.GetComponent<RectTransform>();
            if (l_Rect != null)
            {
                if (l_Rect.rect.width > l_Ret.x)
                {
                    l_Ret.x = l_Rect.rect.width;
                }
                else if (l_Rect.rect.height > l_Ret.y)
                {
                    l_Ret.y = l_Rect.rect.height;
                }
            }
        }

        return l_Ret;
    }

	public void ExternalUpdate ()
    {
		if (m_Initialized)
        {
            if (m_UpdateTextColor)
            {
                updateTextColor();
                m_UpdateTextColor = false;
            }

            if(targetVehicle != SimulatorSettings.getActiveEntity().gameObject)
            {
                targetVehicle = SimulatorSettings.getActiveEntity().gameObject;
            }

            if (m_ViewSettings.m_TargetMode)
            {
                m_Crosshair.SetActive(true);
                showTargetLatLon(true);
            }
            else
            {
                m_Crosshair.SetActive(false);
                showTargetLatLon(false);
            }

            updateInformation();
            UpdateSelection();

            //if (m_CanvasScaler.referenceResolution != m_ReferenceResolution)
            //{
            //    Debug.Log("");
            //    Debug.Log("");
            //    Debug.Log("");
            //    Debug.Log("m_HUD.m_CanvasScaler.referenceResolution was " + m_CanvasScaler.referenceResolution);
            //    m_CanvasScaler.referenceResolution = m_ReferenceResolution;
            //    Debug.Log("m_HUD.m_CanvasScaler.referenceResolution was " + m_CanvasScaler.referenceResolution);
            //}

            if (m_ActivateCameraScaling && SimulatorSettings.getInitialized())
            {
                //scaleUIByCameraFrustrum();
            }

            switch (SimulatorSettings.getInputManager().m_JoystickInputMode)
            {
                case JoystickInputMode.KEYBOARD:
                    if (m_ControlIconImage.sprite != m_KeyboardIcon) m_ControlIconImage.sprite = m_KeyboardIcon;
                    break;
                case JoystickInputMode.NSI:
                    if (m_ControlIconImage.sprite != m_ControllerIcon) m_ControlIconImage.sprite = m_ControllerIcon;
                    break;
                default:
                    if (m_ControlIconImage.sprite != m_ControllerIcon) m_ControlIconImage.sprite = m_ControllerIcon;
                    break;
            }

            if(m_HostController.m_ControlType != EntityControlType.PLAYER)
            {
                ToggleControlDisabledIcon(true);
            }
            else
            {
                ToggleControlDisabledIcon(false);
            }

            if (m_MouseCrosshairMode)
            {
                m_Crosshair.transform.position = Input.mousePosition;

                if(Input.GetMouseButtonDown(0))
                {
                    RaycastHit hit;
                    Ray mouseRay = SimulatorSettings.getDirector().getMainCamera().ScreenPointToRay(Input.mousePosition);
                    Rigidbody rb;

                    if (Physics.Raycast(mouseRay, out hit, 600f))
                    {
                        //if (rb = hit.transform.GetComponent<Rigidbody>())
                        //{
                        //    dragging = true;
                        //    localHitPoint = rb.transform.InverseTransformPoint(hit.point);
                        //}
                        //else
                        //{
                        //    dragging = false;
                        //}
                    }
                }
            }

            if (SimulatorSettings.getMaster()) m_MasterIconObj.SetActive(true);
            else m_MasterIconObj.SetActive(false);

            CheckNetwork();

            if(m_GoogleRefresh_Active)
            {
                m_GoogleRefresh_Timer += Time.deltaTime;

                if(m_GoogleRefresh_Timer >= m_GoogleRefresh_TimeBetweenUpdates)
                {
                    LaunchGoogleMaps_LatLonCheck();
                    m_GoogleRefresh_Timer = 0;
                }
            }
        }

        if(m_ControlTypeText)
        {
            if(m_HostController.m_ControlType != m_PreviousControlType)
            {
                m_ControlTypeText.text = m_HostController.m_ControlType.ToString();
                m_PreviousControlType = m_HostController.m_ControlType;
            }
        }

        if(m_WaypointsPanelObj)
        {
            if (m_HostController.m_WaypointModule.m_NumberOfPositionWaypoints > 0)
            {
                if (!m_WaypointsPanelObj.activeInHierarchy) m_WaypointsPanelObj.SetActive(true);

                if (m_WaypointsScenarioText)
                {
                    m_WaypointsScenarioText.text = m_ConfigurationManager.m_ScenarioFileName;
                }

                if(m_WaypointsPausePlayButtonText)
                {
                    switch(m_HostController.m_ControlType)
                    {
                        case EntityControlType.PLAYER:
                            //Debug.Log("<color=red>Paused</color>");
                            WaypointPause();
                            break;
                        case EntityControlType.WAYPOINT:
                            //Debug.Log("<color=green>Playing</color>");
                            WaypointPlay();
                            break;
                        default:
                            //Debug.Log("<color=gray>None</color>");
                            WaypointPause();
                            break;
                    }
                    //if(m_HostController.m_WaypointModule.m_Playing)
                    //{
                    //    Debug.Log("<color=green>Playing</color>");
                    //    WaypointPlay();
                    //}
                    //else
                    //{
                    //    Debug.Log("<color=red>Paused</color>");
                    //    WaypointPause();
                    //}
                }
            }
            else
            {
                if (m_WaypointsPanelObj.activeInHierarchy) m_WaypointsPanelObj.SetActive(false);
            }
        }
	}

    public void WaypointPausePlayButton_OnPress()
    {
        switch (m_HostController.m_ControlType)
        {
            case EntityControlType.WAYPOINT:
                m_HostController.StopWaypoints();
                break;
            default:
                m_HostController.StartWaypoints();
                break;
        }
        //if (m_HostController.m_WaypointModule.m_Playing)
        //{
        //    m_HostController.StopWaypoints();
        //}
        //else
        //{
        //    m_HostController.StartWaypoints();
        //}
    }

    public void CheckNetwork()
    {
        if (m_NetMonitor.m_NetworkAgentActive)
        {
            if (m_NSIActiveIndicator.sprite == m_NSIInactive)
            {
                m_NSIActiveIndicator.sprite = m_NSIActive;
                m_GroupIDText.text = "N/A";
            }
        }
        else
        {
            if (m_NSIActiveIndicator.sprite == m_NSIActive)
            {
                m_NSIActiveIndicator.sprite = m_NSIInactive;
                m_GroupIDText.text = "N/A";
            }
        }
    }

    public void SelectObjects()
    {
        foreach (KeyValuePair<int, Entity> l_EntityPair in m_EntityList.m_Entities)
        {
            if (l_EntityPair.Value == null)
            {
                m_SelectedObjectsRemoveList.Add(l_EntityPair.Value);
                continue;
            }

            if (m_SelectedObjects.Contains(l_EntityPair.Value))
            {
                l_EntityPair.Value.m_IsSelected  = true;
            }
        }
    }

    public void SelectObjectAtPoint()
    {

    }

    public void SelectObjectsInRect()
    {

    }

    public void TempRectSelectObjects()
    {
        foreach (KeyValuePair<int, Entity> l_EntityPair in m_EntityList.m_Entities)
        {
            Vector3 projectedPosition = Camera.main.WorldToScreenPoint(l_EntityPair.Value.transform.position);
            projectedPosition.y = Screen.height - projectedPosition.y;

            if (m_SelectionBox.Contains(projectedPosition))
            {
                l_EntityPair.Value.m_IsSelected = true;
            }
        }
    }

    public void ClearSelectedObjects()
    {
        m_SelectedObjects.Clear();
    }

    public void UpdateSelection()
    {
        if (Input.GetMouseButtonDown(0)) {
                    if (!(Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)))
                    {
                        ClearSelectedObjects();
                    }
                    m_IsSelecting = true;
                    m_InitialClick = Input.mousePosition;
                }
                else if (Input.GetMouseButtonUp(0)) {
                    if (!(Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)))
                    {
                        ClearSelectedObjects();
                    }
                    SelectObjectAtPoint();
                    SelectObjectsInRect();
                    SelectObjects();
                    m_IsSelecting = false;
                    m_IsBoxSelecting = false;
                    m_InitialClick = -Vector3.one * 9999f;
                }
 
            if (m_IsSelecting && Input.GetMouseButton(0))
            {
                if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
                {
                    m_IsBoxSelecting = true;
                }
                m_SelectionBox.Set(m_InitialClick.x, Screen.height - m_InitialClick.y, Input.mousePosition.x - m_InitialClick.x, (Screen.height - Input.mousePosition.y) - (Screen.height - m_InitialClick.y));
                if (m_SelectionBox.width < 0)
                {
                    m_SelectionBox.x += m_SelectionBox.width;
                    m_SelectionBox.width *= -1f;
                }
                if (m_SelectionBox.height < 0)
                {
                    m_SelectionBox.y += m_SelectionBox.height;
                    m_SelectionBox.height *= -1f;
                }
                //TempRectSelectObjects();
            }
    }

    public void updateTextColor(Color a_Color)
    {
        m_TextColor = a_Color;

        updateTextColor();
    }

    public void updateTextColor()
    {
        foreach (Text l_ChildText in m_ChildrenTexts)
        {
            if (l_ChildText.gameObject.name == "FPS Text") continue;
            l_ChildText.color = m_TextColor;   
        }
            
    }

    public void updateTextSize(int a_TextSize)
    {
        m_TextSize = a_TextSize;

        updateTextSize();
    }

    public void updateTextSize()
    {
        foreach (Text l_ChildText in m_ChildrenTexts)
        {
            if (l_ChildText.gameObject.name == "FPS Text") continue;
            l_ChildText.fontSize = m_TextSize;
        }

    }

    public void updateTextBold(bool a_Bool)
    {
        m_TextBolded = a_Bool;

        updateTextBold();
    }

    public void updateTextBold()
    {
        foreach (Text l_ChildText in m_ChildrenTexts)
        {
            if (l_ChildText.gameObject.name == "FPS Text") continue;
            if(m_TextBolded)
            {
                l_ChildText.fontStyle = FontStyle.Bold;
            }
            else
            {
                l_ChildText.fontStyle = FontStyle.Normal;
            }
        }

    }

    public void scaleUIByCameraFrustrum()
    {
        //float m_CalculatedScaleFactor = Vector3.Distance(m_HostCamera.transform.position, m_CanvasTransform.position) * m_ScaleMultiplier;
        //m_CanvasTransform.localScale = new Vector3(m_CalculatedScaleFactor, m_CalculatedScaleFactor, 1);

        m_CanvasTransform.localPosition = new Vector3(0, 0, m_DistanceFromCamera);

        float l_VFOV = m_CameraManager.m_ViewSettings.calcVertivalFOV(m_CameraManager.m_ViewSettings.m_HorizontalFOV, m_CameraManager.m_ViewSettings.m_MainCamera.aspect);

        m_FrustrumHeight = 2.0f * m_DistanceFromCamera * Mathf.Tan(l_VFOV * 0.5f * Mathf.Deg2Rad);
        m_FrustrumWidth = m_FrustrumHeight * m_HostCamera.aspect;

        m_WidthScaleFactor = m_FrustrumWidth / m_OriginalWidth;
        m_HeightScaleFactor = m_FrustrumHeight / m_OriginalHeight;

        //Debug.Log("m_NumberOfCameras: " + m_NumberOfCameras + " m_DistanceFromCamera: " + m_DistanceFromCamera + " - l_VFOV: " + l_VFOV + " - m_HostCamera.aspect " + m_HostCamera.aspect);

        m_CanvasTransform.sizeDelta = new Vector2(m_FrustrumWidth * m_NumberOfCameras, m_FrustrumHeight);
        m_StaticDisplayObject.transform.localScale = new Vector3(m_WidthScaleFactor * m_NumberOfCameras, m_HeightScaleFactor, 1);

        //m_BorderWidthScaleFactor = (m_FrustrumWidth + m_BorderThicknessInPixles) / (m_OriginalBorderWidth);
        //m_BorderHeightScaleFactor = (m_FrustrumHeight + m_BorderThicknessInPixles) / (m_OriginalBorderHeight);

        //m_Border.transform.localScale = new Vector3(m_BorderWidthScaleFactor * m_NumberOfCameras, m_BorderHeightScaleFactor, 1);
    }

    public void attachHUDToCamera(Camera a_Camera)
    {
        if (a_Camera == null)
        {
            a_Camera = m_CameraManager.getMainCamera();
        }

        m_HostCamera = a_Camera;
        m_Canvas.worldCamera = m_HostCamera;
        m_Canvas.targetDisplay = m_HostCamera.targetDisplay;

        //transform.SetParent(m_HostCamera.transform);
        //transform.localPosition = new Vector3(0,0,0);
        //transform.localRotation = Quaternion.Euler(new Vector3 (0,0,0));

        //scaleUIByCameraFrustrum();
    }

    public void changeTarget(GameObject newTarget)
    {
        //Debug.Log("changeTarget( " + newTarget.name + " )");
        targetVehicle = newTarget;

        if (targetVehicle != null)
        {
            m_HostController = targetVehicle.GetComponent<Entity>();
            if (m_HostController != null)
            {
                updateInformation();
            }
        }
    }

    void updateInformation()
    {
        ID.text = m_HostController.getEntityID().ToString();
        Type.text = m_HostController.getEntitySMMTTID().ToString();

        m_HostType = Common.GetType(m_HostController);
        switch (m_HostType)
        {
            case EntityType.QUADCOPTER:
                m_HostTransform = m_HostController.m_ModelLoader.m_Model.gameObject.transform;
                m_UseLocalRotation_HPR = true;
                break;
            default:
                m_HostTransform = m_HostController.gameObject.transform;
                m_UseLocalRotation_HPR = false;
                break;
        }

        string heading = (Mathf.Round(m_HostController.getCurrentHeading() * 100f) / 100f).ToString();
        Heading.text = heading;
        TopHeading.text = heading;
        ViewHeading.text = (Mathf.Round((m_ViewSettings.transform.eulerAngles.y) * 100f) / 100f).ToString();
        m_Elevation.text = (Mathf.Round((m_HostController.transform.position.y) * 100f) / 100f).ToString() + " m";

        m_FOVText.text = ((m_ViewSettings.m_HorizontalFOV / m_ViewSettings.m_ZoomLevel) * m_ViewSettings.m_NumberOfCameras).ToString();

        t_Speed = m_HostController.getCurrentSpeed();
        t_MaxSpeed = m_HostController.getMaxSpeed();

        if (t_Speed >= 0)
        {
            if (t_Speed > t_MaxSpeed)
            {
                t_Speed = t_MaxSpeed;
            }
        }
        else
        {
            if (t_Speed < -t_MaxSpeed)
            {
                t_Speed = -t_MaxSpeed;
            }
        }

        Speed.text = FloatToString(t_Speed);
        Speed.text += " kn";

        MaxSpeed.text = FloatToString(t_MaxSpeed);
        MaxSpeed.text += " kn";

        setThrottleValue(m_HostController.m_LVerticalInput);

        if (Gear)
        {
            if (m_HostController.m_EntityGear == EntityGear.FORWARD) Gear.text = "F";
            else Gear.text = "R";
        }

        Vector2 latlon = m_HostController.getCurrentGPSPosition();
        Lat.text = latlon.x.ToString();
        Lon.text = latlon.y.ToString(); 

        m_HostRotationXYZ = m_HostTransform.rotation.eulerAngles;
        m_LocalHostRotationXYZ = m_HostTransform.localRotation.eulerAngles;

        Update_Pitch();
        Update_Roll();

        m_TimerHours = SimulatorSettings.getTimeManager().GetTimeOfDay();
        m_TimerMinutes = ((m_TimerHours) - (Mathf.Floor(m_TimerHours))) * 60.0f;
        m_TimerSeconds = ((m_TimerMinutes) - (Mathf.Floor(m_TimerMinutes))) * 60.0f;

        m_Time.text = Mathf.Floor(m_TimerHours).ToString("00") + ":" + Mathf.Floor(m_TimerMinutes).ToString("00") + ":" + Mathf.Floor(m_TimerSeconds).ToString("00");
    }

    public void Update_Pitch()
    {
        if (m_HostController.m_CurrentPitch <= 180) t_Sign = "-"; // Negative in Unity Terms
        else t_Sign = " "; // Positive in Unity Terms

        if (m_UseLocalRotation_HPR)
        {
            if (Mathf.Abs(m_HostTransform.localRotation.x) < 0.001) m_Pitch.text = " 0.0";
            else m_Pitch.text = t_Sign + Quaternion.Angle(m_QuatForward, m_HostTransform.localRotation).ToString("0.0");
        }
        else
        {
            if (Mathf.Abs(m_HostTransform.rotation.x) < 0.001) m_Pitch.text = " 0.0";
            else m_Pitch.text = t_Sign + Quaternion.Angle(m_QuatForward, m_HostTransform.rotation).ToString("0.0");
        }
    }

    public void Update_Roll()
    {
        if (m_HostController.m_CurrentRoll <= 180) t_Sign = "-"; // Negative in Unity Terms
        else t_Sign = " "; // Positive in Unity Terms

        if (m_UseLocalRotation_HPR)
        {
            if (Mathf.Abs(m_HostTransform.localRotation.z) < 0.001) m_Roll.text = " 0.0";
            else m_Roll.text = t_Sign + Quaternion.Angle(m_QuatRight, m_HostTransform.localRotation).ToString("0.0");
        }
        else
        {
            if (Mathf.Abs(m_HostTransform.rotation.z) < 0.001) m_Roll.text = " 0.0";
            else m_Roll.text = t_Sign + Quaternion.Angle(m_QuatRight, m_HostTransform.rotation).ToString("0.0");
        }
    }

    public string FloatToString(float a_Float)
    {
        float l_Float = a_Float;
        string l_Ret = "";

        if (Mathf.Abs(l_Float) > 0.1f)
        {
            if (Mathf.Abs(l_Float) < 10.0)
            {
                l_Float = Mathf.Round(l_Float * 100f) / 100f;
                l_Ret = "  " + l_Float.ToString();
            }
            else if (Mathf.Abs(l_Float) < 100.0)
            {
                l_Float = Mathf.Round(l_Float * 100f) / 100f;
                l_Ret = " " + l_Float.ToString();
            }
            else
            {
                l_Float = Mathf.Round(l_Float * 100f) / 100f;
                l_Ret = l_Float.ToString();
            }
        }
        else
        {
            l_Ret = "  0.00";
        }

        if (Mathf.Abs(l_Float % 1) <= (double.Epsilon * 100))
        {
            l_Ret += ".00";
        }

        return l_Ret;
    }

    public void setReferenceResolution(float a_Width, float a_Height)
    {
        m_ReferenceResolution = new Vector2(a_Width, a_Height);
        m_CanvasScaler.referenceResolution = m_ReferenceResolution;
    }

    public void setScreenMatchWidthOrHeight(float a_Match)
    {
        m_CanvasScaler.matchWidthOrHeight = a_Match;
    }

    public void setRange(float a_Range)
    {
        m_Range.text = m_Elevation.text = (Mathf.Round((a_Range) * 100f) / 100f).ToString() + " m";
    }

    public void setTargetEntity(Entity a_Entity)
    {
        if(a_Entity == null)
        {
            m_TargetedEntityGroup.SetActive(false);
            m_TargetedEntity = a_Entity;
            m_TargetedEntityText.text = "None";
        }
        else
        {
            m_TargetedEntityGroup.SetActive(true);

            m_TargetedEntity = a_Entity;

            m_TargetedEntityText.text = m_TargetedEntity.m_EntityName;
        }
        
    }

    public void showTargetLatLon(bool a_Bool)
    {
        if (a_Bool && m_TargetLatLongInitialized)
        {
            m_TargetedLatGroup.SetActive(a_Bool);
            m_TargetedLonGroup.SetActive(a_Bool);
        }
        else
        {
            m_TargetedLatGroup.SetActive(false);
            m_TargetedLonGroup.SetActive(false);
        }
    }

    public void setTargetLatLon(Vector2 a_LatLon)
    {
        setTargetLatLon(a_LatLon.x, a_LatLon.y);
    }

    public void setTargetLatLon(float a_Lat, float a_Lon)
    {
        m_TargetLat.text = a_Lat.ToString();
        m_TargetLon.text = a_Lon.ToString();

        m_TargetLatLongInitialized = true;
    }

    public void shiftHUDInward(float a_ShiftAmount)
    {
        if (m_TopLeftScreenAnchor) m_TopLeftScreenAnchor.position = new Vector3(m_OriginalTLAnchorPosition.x + a_ShiftAmount, m_OriginalTLAnchorPosition.y - a_ShiftAmount, m_OriginalTLAnchorPosition.z);
        if (m_TopCenterScreenAnchor) m_TopCenterScreenAnchor.position = new Vector3(m_OriginalTCAnchorPosition.x, m_OriginalTCAnchorPosition.y - a_ShiftAmount, m_OriginalTCAnchorPosition.z);
        if (m_TopRightScreenAnchor) m_TopRightScreenAnchor.position = new Vector3(m_OriginalTRAnchorPosition.x - a_ShiftAmount, m_OriginalTRAnchorPosition.y - a_ShiftAmount, m_OriginalTRAnchorPosition.z);

        if (m_BottomLeftScreenAnchor) m_BottomLeftScreenAnchor.position = new Vector3(m_OriginalBLAnchorPosition.x + a_ShiftAmount, m_OriginalBLAnchorPosition.y + a_ShiftAmount, m_OriginalBLAnchorPosition.z);
        if (m_BottomCenterScreenAnchor) m_BottomCenterScreenAnchor.position = new Vector3(m_OriginalBCAnchorPosition.x, m_OriginalBCAnchorPosition.y + a_ShiftAmount, m_OriginalBCAnchorPosition.z);
        if (m_BottomRightScreenAnchor) m_BottomRightScreenAnchor.position = new Vector3(m_OriginalBRAnchorPosition.x - a_ShiftAmount, m_OriginalBRAnchorPosition.y + a_ShiftAmount, m_OriginalBRAnchorPosition.z);

        m_CanvasScaler.scaleFactor = 1 - (a_ShiftAmount / m_ScaleFactorDivisor);
    }

    public void shiftLeftHUDInward(float a_ShiftAmount)
    {
        if (m_TopLeftScreenAnchor) m_TopLeftScreenAnchor.position = new Vector3(m_OriginalTLAnchorPosition.x + a_ShiftAmount, m_OriginalTLAnchorPosition.y - a_ShiftAmount, m_OriginalTLAnchorPosition.z);
       
        if (m_BottomLeftScreenAnchor) m_BottomLeftScreenAnchor.position = new Vector3(m_OriginalBLAnchorPosition.x + a_ShiftAmount, m_OriginalBLAnchorPosition.y + a_ShiftAmount, m_OriginalBLAnchorPosition.z);
    }

    public void shiftRightHUDInward(float a_ShiftAmount)
    {
        if (m_TopRightScreenAnchor) m_TopRightScreenAnchor.position = new Vector3(m_OriginalTRAnchorPosition.x - a_ShiftAmount, m_OriginalTRAnchorPosition.y - a_ShiftAmount, m_OriginalTRAnchorPosition.z);

        if (m_BottomRightScreenAnchor) m_BottomRightScreenAnchor.position = new Vector3(m_OriginalBRAnchorPosition.x - a_ShiftAmount, m_OriginalBRAnchorPosition.y + a_ShiftAmount, m_OriginalBRAnchorPosition.z);
    }

    public void shiftLeftHUDLeft(float a_ShiftAmount)
    {
        if (m_TopLeftScreenAnchor) m_TopLeftScreenAnchor.position = new Vector3(m_OriginalTLAnchorPosition.x + a_ShiftAmount, m_OriginalTLAnchorPosition.y, m_OriginalTLAnchorPosition.z);

        if (m_BottomLeftScreenAnchor) m_BottomLeftScreenAnchor.position = new Vector3(m_OriginalBLAnchorPosition.x + a_ShiftAmount, m_OriginalBLAnchorPosition.y, m_OriginalBLAnchorPosition.z);
    }

    public void shiftRightHUDRight(float a_ShiftAmount)
    {
        if (m_TopRightScreenAnchor) m_TopRightScreenAnchor.position = new Vector3(m_OriginalTRAnchorPosition.x - a_ShiftAmount, m_OriginalTRAnchorPosition.y, m_OriginalTRAnchorPosition.z);

        if (m_BottomRightScreenAnchor) m_BottomRightScreenAnchor.position = new Vector3(m_OriginalBRAnchorPosition.x - a_ShiftAmount, m_OriginalBRAnchorPosition.y, m_OriginalBRAnchorPosition.z);
    }

    public void shiftTopHUDInward(float a_ShiftAmount)
    {
        if (m_TopLeftScreenAnchor) m_TopLeftScreenAnchor.position = new Vector3(m_OriginalTLAnchorPosition.x + a_ShiftAmount, m_OriginalTLAnchorPosition.y - a_ShiftAmount, m_OriginalTLAnchorPosition.z);
        if (m_TopCenterScreenAnchor) m_TopCenterScreenAnchor.position = new Vector3(m_OriginalTCAnchorPosition.x, m_OriginalTCAnchorPosition.y - a_ShiftAmount, m_OriginalTCAnchorPosition.z);
        if (m_TopRightScreenAnchor) m_TopRightScreenAnchor.position = new Vector3(m_OriginalTRAnchorPosition.x - a_ShiftAmount, m_OriginalTRAnchorPosition.y - a_ShiftAmount, m_OriginalTRAnchorPosition.z);
    }

    public void shiftBottomHUDInward(float a_ShiftAmount)
    {
        if (m_BottomLeftScreenAnchor) m_BottomLeftScreenAnchor.position = new Vector3(m_OriginalBLAnchorPosition.x + a_ShiftAmount, m_OriginalBLAnchorPosition.y + a_ShiftAmount, m_OriginalBLAnchorPosition.z);
        if (m_BottomCenterScreenAnchor) m_BottomCenterScreenAnchor.position = new Vector3(m_OriginalBCAnchorPosition.x, m_OriginalBCAnchorPosition.y + a_ShiftAmount, m_OriginalBCAnchorPosition.z);
        if (m_BottomRightScreenAnchor) m_BottomRightScreenAnchor.position = new Vector3(m_OriginalBRAnchorPosition.x - a_ShiftAmount, m_OriginalBRAnchorPosition.y + a_ShiftAmount, m_OriginalBRAnchorPosition.z);
    }

    public void setHUDCanvasScalar(float a_ScaleFactor)
    {
        m_CanvasScaler.scaleFactor = a_ScaleFactor;
    }

    public void toggleMouseCrosshairMode()
    {
        toggleMouseCrosshairMode(!m_MouseCrosshairMode);
    }

    public void toggleMouseCrosshairMode(bool a_Bool)
    {
        m_MouseCrosshairMode = a_Bool;

        if(!m_MouseCrosshairMode)
        {
            m_Crosshair.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        }
    }

    public void toggleThrottleVisible(bool a_Bool)
    {
        m_ThrottleObject.SetActive(a_Bool);
    }

    public void setThrottleValue(float a_Val)
    {
        if(a_Val == 0)
        {
            m_ThrottleValueText.text = "0.0";
        }
        else
        {
            m_ThrottleValueText.text = FloatToString(a_Val);//a_Val.ToString();
        }
    }

    public void EnableAnchorUIObjects(bool a_Bool)
    {
        m_TopScreenAnchor.gameObject.SetActive(a_Bool);
        m_TopLeftScreenAnchor.gameObject.SetActive(a_Bool);
        m_TopCenterScreenAnchor.gameObject.SetActive(a_Bool);
        m_TopRightScreenAnchor.gameObject.SetActive(a_Bool);

        m_BottomScreenAnchor.gameObject.SetActive(a_Bool);
        m_BottomLeftScreenAnchor.gameObject.SetActive(a_Bool);
        m_BottomCenterScreenAnchor.gameObject.SetActive(a_Bool);
        m_BottomRightScreenAnchor.gameObject.SetActive(a_Bool);
    }

    //public System.Windows.Forms.WebBrowser m_WebBrowser;// = new System.Windows.Forms.WebBrowser();
    //public bool m_BrowserInitiated = false;

    public void LaunchGoogleMaps_LatLonCheck()
    {
        m_GoogleAddress = "https://www.google.com/maps/place/";

        m_DECLat = m_HostController.currentGPSPosition.x;
        m_DECLon = m_HostController.currentGPSPosition.y;

        if (m_DECLat >= 0) m_DECLat_Dir = "N";
        else m_DECLat_Dir = "S";

        if (m_DECLon >= 0) m_DECLat_Dir = "W";
        else m_DECLat_Dir = "E";

        // Convert Decimal Lat to Degrees Minutes Seconds
        m_DECLat *= 3600.0f;

        m_DMSLat_Seconds = Mathf.Round((float)m_DECLat);
        m_DMSLat_Degrees = (int)(m_DMSLat_Seconds / 3600f);
        m_DMSLat_Seconds = Mathf.Abs(m_DMSLat_Seconds % 3600);

        m_DMSLat_Minutes = (int)(m_DMSLat_Seconds / 60f);

        m_DMSLat_Seconds %= 60.0f;
        m_DMSLat_Degrees = Mathf.Abs(m_DMSLat_Degrees);

        // Convert Decimal Lon to Degrees Minutes Seconds
        m_DECLon *= 3600.0f;
        m_DMSLon_Seconds = (int)Mathf.Round((float)m_DECLon);
        m_DMSLon_Degrees = (int)(m_DMSLon_Seconds / 3600f);
        m_DMSLon_Seconds = Mathf.Abs(m_DMSLon_Seconds % 3600);
        m_DMSLon_Minutes = (int)(m_DMSLon_Seconds / 60f);

        m_DMSLon_Seconds %= 60;
        m_DMSLon_Degrees = Mathf.Abs(m_DMSLon_Degrees);

        // Fill Out the Google Maps URL
        m_DECLat_String = m_DECLat.ToString();
        m_DECLon_String = m_DECLon.ToString();

        m_DMSLat_String = m_DMSLat_Degrees + "%C2%B0" + m_DMSLat_Minutes + "'" + m_DMSLat_Seconds + "%22N";
        m_DMSLon_String = m_DMSLon_Degrees + "%C2%B0" + m_DMSLon_Minutes + "'" + m_DMSLon_Seconds + "%22W";

        m_GoogleZoomLevelString = m_GoogleZoomLevel.ToString() + "z/";

        m_FinalQueryString = m_GoogleAddress + m_DMSLat_String + "+" + m_DMSLon_String + "/" + m_DECLat_String + "," + m_DECLon_String + "," + m_GoogleZoomLevelString;

        Application.OpenURL(m_FinalQueryString);
    }

    /*
    
        
    public int m_DMSLat_Degrees;
    public int m_DMSLat_Minutes;
    public float m_DMSLat_Seconds;

    public int m_DMSLon_Degrees;
    public int m_DMSLon_Minutes;
    public float m_DMSLon_Seconds;

    public string m_DMSLat_String;
    public string m_DMSLon_String;

    public float m_DECLat;
    public string m_DECLat_String;
    public float m_DECLon;
    public string m_DECLon_String;

    public int m_GoogleZoomLevel = 17;
    public string m_GoogleZoomLevelString;

    public string m_GoogleAddress;
    public string m_FinalQueryString;

    //public System.Windows.Forms.WebBrowser m_WebBrowser;// = new System.Windows.Forms.WebBrowser();
    //public bool m_BrowserInitiated = false;

    public void LaunchGoogleMaps_LatLonCheck()
    {
        //if(!m_BrowserInitiated)
        //{
        //    Debug.Log("<color=blue>Browser was not initialized on function call. Init Started.</color>");

        //    m_WebBrowser = new System.Windows.Forms.WebBrowser();
        //    //m_WebBrowser.Url = new System.Uri("http://www.google.com");
        //    //m_BrowserInitiated = true;
        //}
        //else
        //{
        //    Debug.Log("<color=blue>Browser was initialized on function call. Continuing.</color>");
        //}

        //if(m_WebBrowser != null)
        //{
        //    Debug.Log("<color=green>Browser Created</color>");
        //}
        //else
        //{
        //    Debug.Log("<color=red>Browser Not Found</color>");
        //}

        l_GoogleLat = m_HostController.currentGPSPosition.x;
        l_GoogleLon = m_HostController.currentGPSPosition.y;

        l_GoogleLatStr = l_GoogleLat.ToString();
        l_GoogleLonStr = l_GoogleLon.ToString();

        l_GoogleUrl = "https://www.google.com/maps/@" + l_GoogleLatStr + "," + l_GoogleLonStr + ",16z";
        //System.Diagnostics.Process.Start(l_GoogleUrl);

        //double coord = 59.345235;
        //double coord = m_HostController.m_PreciseGPS.lat;
        m_DECLat = m_HostController.currentGPSPosition.x;
        m_DECLat *= 3600.0f;
        //int sec = (int)Mathf.Round((float)coord);
        m_DMSLat_Seconds = Mathf.Round((float)m_DECLat);
        m_DMSLat_Degrees = (int)(m_DMSLat_Seconds / 3600f);
        m_DMSLat_Seconds = Mathf.Abs(m_DMSLat_Seconds % 3600);
        //int min = sec / 60;
        m_DMSLat_Minutes = (int)(m_DMSLat_Seconds / 60f);

        //Debug.Log("<color=red>" + m_DMSLat_Seconds + "</color>");
        //Debug.Log("<color=red>" + (m_DMSLat_Seconds / 60) + "</color>");

        m_DMSLat_Seconds %= 60.0f;
        m_DMSLat_Degrees = Mathf.Abs(m_DMSLat_Degrees);

        //Debug.Log("Lat");
        //Debug.Log(m_DMSLat_Degrees + " " + m_DMSLat_Minutes + " " + m_DMSLat_Seconds + " ");

        // Lon

        m_DECLon = m_HostController.currentGPSPosition.y;
        m_DECLon *= 3600.0f;
        m_DMSLon_Seconds = (int)Mathf.Round((float)m_DECLon);
        m_DMSLon_Degrees = (int)(m_DMSLon_Seconds / 3600f);
        m_DMSLon_Seconds = Mathf.Abs(m_DMSLon_Seconds % 3600);
        m_DMSLon_Minutes = (int)(m_DMSLon_Seconds / 60f);

        //Debug.Log("<color=red>" + m_DMSLon_Seconds + "</color>");
        //Debug.Log("<color=red>" + (m_DMSLon_Seconds / 60) + "</color>");

        m_DMSLon_Seconds %= 60;
        m_DMSLon_Degrees = Mathf.Abs(m_DMSLon_Degrees);

        //Debug.Log("Lon");
        //Debug.Log(m_DMSLon_Degrees + " " + m_DMSLon_Minutes + " " + m_DMSLon_Seconds + " ");

        //System.Diagnostics.Process.Start("http://google.com");
        //System.Diagnostics.Process.Start("https://www.google.com/maps/@21.3511556,-157.9431727,16z");
        // https://www.google.com/maps/place/21%C2%B021'22.3%22N+157%C2%B056'39.5%22W/@21.3561802,-157.9464994,17z/

        m_GoogleAddress = "https://www.google.com/maps/place/";

        m_DECLat_String = m_DECLat.ToString();
        m_DECLon_String = m_DECLon.ToString();

        m_DMSLat_String = m_DMSLat_Degrees + "%C2%B0" + m_DMSLat_Minutes + "'" + m_DMSLat_Seconds + "%22N";// + " % " + m_DMSLon_Degrees;
        m_DMSLon_String = m_DMSLon_Degrees + "%C2%B0" + m_DMSLon_Minutes + "'" + m_DMSLon_Seconds + "%22W";

        m_GoogleZoomLevelString = m_GoogleZoomLevel.ToString() + "z/";

        m_FinalQueryString = m_GoogleAddress + m_DMSLat_String + "+" + m_DMSLon_String + "/" + m_DECLat_String + "," + m_DECLon_String + "," + m_GoogleZoomLevelString;

        Application.OpenURL(m_FinalQueryString);

        //System.Diagnostics.Process.Start(m_FinalQueryString);

        //if (m_WebBrowser != null)
        //{
        //    Debug.Log("<color=green>Browser Created</color>");
        //}
        //else
        //{
        //    Debug.Log("<color=red>Browser Not Found</color>");
        //}

        ////m_WebBrowser.Navigate(m_FinalQueryString);
        //m_WebBrowser.Navigate(m_FinalQueryString, false);
    }

    */

    public void LaunchGoogleMaps_LatLonCheck_ToggleRefresh()
    {
        if (m_GoogleRefresh_Active) LaunchGoogleMaps_LatLonCheck_StopRefresh();
        else LaunchGoogleMaps_LatLonCheck_StartRefresh();
    }

    public void LaunchGoogleMaps_LatLonCheck_StartRefresh()
    {
        m_GoogleRefresh_Active = true;
    }

    public void LaunchGoogleMaps_LatLonCheck_StopRefresh()
    {
        m_GoogleRefresh_Active = false;
        m_GoogleRefresh_Timer = 0;
    }

    public void RequestControlButton_OnPress()
    {
        Debug.Log("RequestControlButton_OnPress");
        m_CameraManager.RequestControl(m_HostController, EntityControlType.PLAYER, true);

        if(m_HostController.m_ControlType == EntityControlType.PLAYER)
        {
            ToggleControlDisabledIcon(false);
        }
    }

    public void ToggleControlDisabledIcon()
    {
        ToggleControlDisabledIcon(!m_ControlDisabledIconEnabled);
    }

    Color l_TransparentWhite = new Color(0,0,0,0);
    UnityEngine.EventSystems.BaseEventData l_Data;

    public void ToggleControlDisabledIcon(bool a_Bool)
    {
        if (m_ControlDisabledObj) 
        {
            if(a_Bool != m_ControlDisabledIconEnabled)
            {
                m_ControlDisabledIconEnabled = a_Bool;
                m_ControlDisabledObj.SetActive(m_ControlDisabledIconEnabled);

                if(!a_Bool)
                {
                    if(m_ControlDisabledButton)
                    {
                        m_ControlDisabledButton.OnDeselect(l_Data);
                    }

                    WaypointPause();
                }
            }
        }
    }

    void WaypointPlay()
    {
        m_WaypointsPausePlayButtonText.text = "||";
    }

    void WaypointPause()
    {
        m_WaypointsPausePlayButtonText.text = ">";
    }
}
