﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointModule : MonoBehaviour
{
    public Transform m_WaypointTarget;
    public WaypointModuleMode m_WaypointModuleMode;
    public int m_CurrentWaypointIndex;
    public Entity m_Controller;
    public EntityControlObjects m_ControlObjects;
    public List<SimUpdate> m_Waypoints = new List<SimUpdate>();
    public List<string> m_DisplayWaypoints = new List<string>();
    public LineRenderer m_WaypointIndicator;
    public LineRenderer m_LineToNextWaypoint;

    public Material m_NextWaypointMaterial;
    public Material m_WaypointsListMaterial;

    public bool m_BelowTarget;
    public bool m_BehindTarget;
    public float m_WaypointTimer;
    public float m_WaypointFramerate;

    public SimUpdate m_CurrentTargetUpdate;

    public int m_WaypointsCount;
    public int m_TotalNumberOfWaypoints;
    public int NumberOfStateWaypoints;
    public int m_NumberOfPositionWaypoints;

    public float m_ArrivedAtWaypointTolerance = 1f;
    public float m_SpeedAdjustedArrivedAtWaypointTolerance = 1f;
    public float m_ReturnToHostArrivedAtWaypointTolerance = 5f;
    public float m_LandingWaypointTolerance = 5f;

    public bool m_Playing;
    public bool m_Initialized;

    public bool m_DebugMode;
    public float m_DistanceFromTarget;
    public float m_PreviousDistanceFromTarget;

    public bool m_IsMovingFurtherAway;
    public bool m_Doppler_1;
    public bool m_Doppler_2;
    public bool m_Doppler_3;

    public float m_AmountToTurn;
    public float m_TimeUntilFinishedTurning;

    public float m_Speed;

    public SimUpdate m_ReturnToHostMessage = new SimUpdate();
    public bool m_ReturningToHost;
    public Transform m_HostTransform;
    public Transform m_ReturningTransform;
    Vector3 m_ReturnDest;

    public Vector3 m_CurrentTargetXYZPosition;
    public Vector3 m_PreviousTargetXYZPosition;
    public PrecisionGPS m_CurrentTargetLatLon;

    public bool m_Landing;
    public SimUpdate m_LandingAirVehicleMessage = new SimUpdate();
    public Vector3 m_LandingTarget;
    public float m_LandingTargetHeight;
    RaycastHit m_LandingHit;
    public float m_LandingSpeed = 0.5f;
    public float m_RisingSpeed = 1.0f;
    public Vector3 m_LandingLocalPos;
    public Vector3 m_TempTransformVec;

    public float m_PreviousDesiredSpeed;

    public bool m_ReacquireMilcosStarted;
    public bool m_IdentifyMilcosStarted;
    public bool m_ReacquireNeutralizeStarted;
    public bool m_NeutralizeStarted;
    public int m_CurrentMineIndex;
    public SimUpdate m_MineCheckMessage = new SimUpdate();
    public SimUpdate m_MineCheckMessage2 = new SimUpdate();
    public SimUpdate m_PauseMessage = new SimUpdate();
    public SimUpdate m_ReacquireMessage = new SimUpdate();
    public SimUpdate m_SetMineStateMessage = new SimUpdate();
    public SimUpdate m_SensorsFlickMessageOn = new SimUpdate();
    public SimUpdate m_SensorsFlickMessageOff = new SimUpdate();
    public SimUpdate m_SlowDownMessage = new SimUpdate();
    public SimUpdate m_SpeedUpMessage = new SimUpdate();

    public SimUpdate m_MineCheckMessage3 = new SimUpdate();
    public SimUpdate m_MineCheckMessage4 = new SimUpdate();
    public SimUpdate m_MineCheckMessage5 = new SimUpdate();
    public SimUpdate m_MineCheckMessage6 = new SimUpdate();
    public SimUpdate m_MineCheckMessage7 = new SimUpdate();
    public SimUpdate m_MineCheckMessage8 = new SimUpdate();
    public SimUpdate m_MineCheckMessage9 = new SimUpdate();
    public SimUpdate m_MineCheckMessage10 = new SimUpdate();
    public SimUpdate m_RotMessage = new SimUpdate();

    public float m_DistanceFromHost;
    public Vector3 m_ModelOffset;

    Sensor m_SensorInUse;

    public bool m_AttemptSmoothTurns = true;

    public Vector3 m_TargetHeading;
    public float m_DistanceFromTargetHeading;

    public float m_PositionStepSize;
    public float m_PositionSecondaryStepSize;
    public float m_DistanceToPointPreLerp;
    public float m_DistanceToPointPostLerp;
    public Vector3 m_PreviousPosition;

    public float m_RotationStepSize;
    public float m_RotationSecondaryStepSize;
    public float m_CurrentSimSpeed;
    public float m_AdjustedSimSpeed;
    public float m_AdjustedSimSpeedMod = 3;

    public float m_OriginalDesiredSpeed;
    public float m_OriginalDistance;
    public float m_OriginalEstToDest;
    public Vector3 m_OriginalPosition;

    public bool m_DroppingMineLine;
    public int m_MineInterval;
    public float m_MineLineTimer;
    public EntityState m_MineState;

    public Vector3 m_VisualizationVector;
    public Vector3 m_VisualizationPreviousLocation;

    public Vector3 m_PositionHeading;

    public bool m_DivingToDepth;
    public float m_TargetDepth;
    public float m_DepthDiff;

    public float m_EstTimeToDestination;
    public float m_OriginalEstTimeToDestination;
    public Vector3 m_PreviousDestination;

    public bool m_Circling;
    public Entity m_EntityToCircle;
    public float m_Angle;
    public Vector3 m_CirclingPosition;
    public Quaternion m_CirclingRotation;
    public float m_Radius;
    public float m_RotationSpeed;
    public bool m_OverrideColor;
    public Color m_Color;
    public PrecisionGPS m_TempGPS;
    public Vector3 m_TempVec3;

    public Vector3 m_TempRelativeVec3;
    public float m_TempRelativeFloat;

    public bool m_NextLineFound;

    public int m_ReacqWaypointIndex;
    public float m_ReacqHeight;

    public int PrevMineIndex;

    public int m_VolMinesFinished;
    public int m_NumberOfVolMines;
    public int m_NumberOfSurfaceMines;
    public int m_SurfaceMinesFinished;
    public int m_NumberOfBotMines;
    public int m_BotMinesFinished;

    public int m_NumberOfMinesToReacq;
    public int m_MinesFinished;

    public string m_CurrentMineType;

    public List<Entity> m_MineList = new List<Entity>();

    public float m_LandingDelay = 1;
    public float m_LandingTimer;

    public bool m_SingleMessage;
    public bool m_SingleMessageSent;
    public enum WaypointBehaviorMode
    {
        NONE = 0,
        SURFACE,
        AIR,
        SUB,
        CHARACTER
    }

    public WaypointBehaviorMode m_WaypointBehaviorMode;
    public UpdateType m_PreviousUpdateType;

    void Awake()
    {
        m_Initialized = false;
    }

    public void Initialize()
    {
        //Debug.Log("[WaypointModule] Initialize()");

        if (!m_ControlObjects)
        {
            m_ControlObjects = transform.parent.gameObject.GetComponent<EntityControlObjects>();
        }

        if (!m_Controller)
        {
            if (m_ControlObjects)
            {
                m_Controller = m_ControlObjects.m_Controller;
            }
        }

        if (!m_WaypointsListMaterial)
        {
            m_WaypointsListMaterial = Instantiate(SimulatorSettings.getAnimationManager().m_WaypointLineMaterial);
        }

        if (!m_WaypointTarget)
        {
            m_WaypointTarget = m_Controller.transform;
        }

        if (m_OverrideColor)
        {
            m_WaypointsListMaterial.color = m_Color;
        }

        if (typeof(Surface).IsAssignableFrom(m_Controller.GetType()))
        {
            m_WaypointBehaviorMode = WaypointBehaviorMode.SURFACE;
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.cyan;
        }
        else if (typeof(Air).IsAssignableFrom(m_Controller.GetType()))
        {
            m_WaypointBehaviorMode = WaypointBehaviorMode.AIR;
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.green;
        }
        else if (typeof(Submersible).IsAssignableFrom(m_Controller.GetType()))
        {
            m_WaypointBehaviorMode = WaypointBehaviorMode.SUB;
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.yellow;
        }
        else if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
        {
            m_WaypointBehaviorMode = WaypointBehaviorMode.SURFACE;
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.white;
        }
        else if (typeof(Character).IsAssignableFrom(m_Controller.GetType()))
        {
            m_WaypointBehaviorMode = WaypointBehaviorMode.CHARACTER;
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.blue;
            m_SingleMessage = true;
        }
        else
        {
            if (!m_OverrideColor) m_WaypointsListMaterial.color = Color.white;
        }

        if (m_WaypointIndicator == null)
        {
            Transform l_Transform = m_ControlObjects.transform.Find("WaypointIndicator");

            if (l_Transform)
            {
                m_WaypointIndicator = l_Transform.GetComponent<LineRenderer>();
            }
        }

        if (m_WaypointIndicator == null)
        {
            GameObject l_Object = new GameObject("WaypointIndicator");
            l_Object.transform.SetParent(m_ControlObjects.transform);
            int l_Layer = 0;
            l_Layer |= (1 << LayerMask.NameToLayer("TransparentFX"));
            l_Object.layer = l_Layer;
            m_WaypointIndicator = l_Object.AddComponent<LineRenderer>();
            m_ControlObjects.AddControlObject("WaypointIndicator", l_Object);
        }

        m_WaypointIndicator.transform.localPosition = Vector3.zero;
        m_WaypointIndicator.material = m_WaypointsListMaterial;
        m_WaypointIndicator.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;

        if (m_LineToNextWaypoint == null)
        {
            Transform l_Transform = m_ControlObjects.transform.Find("LineToNextWaypoint");

            if (l_Transform)
            {
                m_LineToNextWaypoint = l_Transform.GetComponent<LineRenderer>();
            }
        }

        if (m_LineToNextWaypoint == null)
        {
            GameObject l_Object = new GameObject("LineToNextWaypoint");
            l_Object.transform.SetParent(m_ControlObjects.transform);
            int l_Layer = 0;
            l_Layer |= (1 << LayerMask.NameToLayer("TransparentFX"));
            l_Object.layer = l_Layer;
            m_LineToNextWaypoint = l_Object.AddComponent<LineRenderer>();
            m_ControlObjects.AddControlObject("LineToNextWaypoint", l_Object);
        }

        if (m_Controller == SimulatorSettings.getDirector().m_MainCameraDrone)
        {
            Debug.Log("Waypoint Indicator disabled");
            m_WaypointIndicator.gameObject.SetActive(false);
            m_LineToNextWaypoint.gameObject.SetActive(false);
            m_Initialized = false;
            gameObject.SetActive(false);
            return;
        }

        m_LineToNextWaypoint.transform.localPosition = Vector3.zero;
        m_LineToNextWaypoint.material = m_WaypointsListMaterial;
        m_LineToNextWaypoint.positionCount = 2;
        m_LineToNextWaypoint.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;

        m_WaypointTimer = 0;
        m_CurrentWaypointIndex = 0;

        m_ModelOffset = new Vector3(0, m_Controller.m_ModelBounds.extents.y / 2, 0);

        m_RisingSpeed = m_Controller.m_MaxSpeed * 0.25f;
        //m_LandingSpeed = m_Controller.m_MaxSpeed * 0.25f;

        if (m_WaypointIndicator)
        {
            m_WaypointIndicator.enabled = true;
            m_WaypointIndicator.gameObject.SetActive(false);
        }
        if (m_LineToNextWaypoint)
        {
            m_LineToNextWaypoint.enabled = true;
            m_LineToNextWaypoint.gameObject.SetActive(false);
        }

        m_Initialized = true;
    }

    void Update()
    {
        if (m_Initialized)
        {
            m_WaypointFramerate = SimulatorSettings.getAnimationManager().m_CurrentFrameRate;
            m_CurrentSimSpeed = SimulatorSettings.getSimSpeed();

            if (m_Circling)
            {
                Circle();
                return;
            }

            if (m_Waypoints.Count > 0 && m_Playing)
            {
                UpdateWaypoints();
            }
            else if (m_Waypoints.Count == 0 && m_Playing)
            {
                m_Playing = false;
                if (m_Controller) m_Controller.switchEntityControl(EntityControlType.NONE);
            }

            UpdateVisualization();

        }
    }

    void PositionRotationUpdate(Vector3 a_TargetXYZPosition)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.POSITION;

        if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
        {
            if (a_TargetXYZPosition.y - m_Controller.transform.position.y > 0.1)
            {
                m_Controller.m_IsRising = true;
            }
            else m_Controller.m_IsRising = false;
        }


        if (m_ReturningToHost)
        {
            a_TargetXYZPosition = m_HostTransform.position;

            if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
            {
                a_TargetXYZPosition.y = m_WaypointTarget.position.y;
            }
            else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
            {
                //Debug.Log("Returning Entity is of Type: Surface");

                if (m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint)
                {
                    m_HostTransform = m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint.transform;
                }
                else if (m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint)
                {
                    m_HostTransform = m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint.transform;
                }
                else
                {
                    m_HostTransform = m_Controller.m_ParentEntity.transform;
                }

                m_ReturnDest = m_HostTransform.transform.position;
                m_ReturnDest.y = m_WaypointTarget.position.y;
            }

            m_CurrentTargetUpdate.Position = a_TargetXYZPosition;
            m_CurrentTargetUpdate.GPS = GPSEncoder.DUSCToGPS(a_TargetXYZPosition.x, a_TargetXYZPosition.y, a_TargetXYZPosition.z);
        }

        if (m_Landing)
        {
            //Debug.Log("Landing");

            if (m_Speed < m_Controller.m_DesiredSpeed) m_Speed += m_Controller.m_Acceleration * Time.deltaTime;
            else if (m_Speed > m_Controller.m_DesiredSpeed) m_Speed -= m_Controller.m_Acceleration * Time.deltaTime;

            a_TargetXYZPosition = m_HostTransform.position;


            //if(m_Controller.m_EntitySMMTTID == 1600)
            //{
            //    a_TargetXYZPosition.y += (m_Controller.m_ModelLoader.m_ModelBounds.extents.y / 2) - 0.5f;
            //}

            //else 
            a_TargetXYZPosition.y += m_ModelOffset.y;

            if (!CheckArrival(a_TargetXYZPosition))
            {
                //l_NewUpdate.Position = Vector3.MoveTowards(m_Controller.m_PreviousSimUpdate.Position, a_TargetXYZPosition, Time.deltaTime * (m_Speed * m_CurrentSimSpeed));
                //m_Controller.transform.localPosition = new Vector3(m_LandingLocalPos.x, transform.position.y, m_LandingLocalPos.z);

                //m_TempTransformVec = m_Controller.m_Transform.TransformPoint(m_LandingLocalPos);
                //m_Controller.m_PreviousSimUpdate.Position.x = m_TempTransformVec.x;
                //m_Controller.m_PreviousSimUpdate.Position.z = m_TempTransformVec.z;

                //l_NewUpdate.Position = m_TempTransformVec;
                //l_NewUpdate.Position.y = Mathf.Lerp(m_Controller.m_PreviousSimUpdate.Position.y, a_TargetXYZPosition.y, Time.deltaTime * (m_Speed * m_CurrentSimSpeed));

                l_NewUpdate.Position = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, a_TargetXYZPosition, Time.deltaTime * (m_Speed * m_CurrentSimSpeed), 0);
                l_NewUpdate.Position.y = Mathf.Lerp(m_Controller.m_Transform.position.y, a_TargetXYZPosition.y, Time.deltaTime * ((m_LandingSpeed / 2) * m_CurrentSimSpeed));
                m_Controller.m_Transform.rotation = Quaternion.RotateTowards(m_Controller.m_Transform.rotation, m_HostTransform.rotation, Time.deltaTime * (m_Speed * 2 * m_CurrentSimSpeed));
                l_NewUpdate.Rotation = m_Controller.m_Transform.rotation.eulerAngles;
                l_NewUpdate.State = m_CurrentTargetUpdate.State;
                l_NewUpdate.Value = m_CurrentTargetUpdate.Value;
                l_NewUpdate.Type = UpdateType.POSITION;
                l_NewUpdate.GPS = GPSEncoder.DUSCToGPS(l_NewUpdate.Position.x, l_NewUpdate.Position.y, l_NewUpdate.Position.z);
                //Debug.DrawLine(m_Controller.m_Transform.position, a_TargetXYZPosition, Color.red, 1);

                m_Controller.addPosition(l_NewUpdate);
                //if (m_Controller.m_EntityID == 12) Debug.Log("Adding Position 2: " + l_NewUpdate.Position + " Alt: " + l_NewUpdate.GPS.alt);

                m_Controller.setState(EntityState.DEFAULT_POSUPDATE);
                return;
            }
            else
            {
                m_Controller.m_RigidBody.isKinematic = false;
                m_Controller.m_RigidBody.useGravity = true;
                m_Controller.m_IsFalling = true;
            }
            //else
            //{
            //    ReachedGPSWaypoint(a_TargetXYZPosition);
            //}
        }

        if (m_Controller.m_IsRising)
        {
            if (!CheckArrival(a_TargetXYZPosition))
            {
                m_EstTimeToDestination = m_DistanceFromTarget / m_Speed;

                l_NewUpdate.Position = m_Controller.transform.position;
                l_NewUpdate.Position.y = Mathf.MoveTowards(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_RisingSpeed * m_CurrentSimSpeed));
                l_NewUpdate.Rotation = m_Controller.transform.rotation.eulerAngles;
                l_NewUpdate.GPS = GPSEncoder.DUSCToGPS(l_NewUpdate.Position.x, l_NewUpdate.Position.y, l_NewUpdate.Position.z);

                l_NewUpdate.State = m_CurrentTargetUpdate.State;
                l_NewUpdate.Value = m_CurrentTargetUpdate.Value;

                //if (m_Controller.m_EntityID == 12) Debug.Log("Waypoint: " + l_NewUpdate.Position);

                m_Controller.addPosition(l_NewUpdate);
                m_Controller.setState(EntityState.DEFAULT_POSUPDATE);
            }
        }
        else if (!CheckArrival(a_TargetXYZPosition))
        {
            if (m_DistanceFromTarget < (m_CurrentSimSpeed * 5) && m_CurrentTargetUpdate.Type == UpdateType.POSITION)
            {
                if ((m_PreviousDistanceFromTarget) < m_DistanceFromTarget)
                {
                    m_IsMovingFurtherAway = true;
                    m_Doppler_3 = false;
                    m_Doppler_2 = false;
                    m_Doppler_1 = false;

                    m_Controller.SetPosition(a_TargetXYZPosition);

                    ReachedGPSWaypoint(a_TargetXYZPosition);
                    if (m_Controller.m_EntityID == 12) Debug.Log("Setting arrival at: " + a_TargetXYZPosition);
                    m_PreviousDistanceFromTarget = 9999999999999999999;
                    return;

                    if (m_Doppler_3)
                    {
                        m_IsMovingFurtherAway = true;
                        m_Doppler_3 = false;
                        m_Doppler_2 = false;
                        m_Doppler_1 = false;

                        if (m_Controller.m_EntityID == 12) Debug.Log("Is moving further away");

                        ReachedGPSWaypoint(m_WaypointTarget.position);
                        m_PreviousDistanceFromTarget = 9999999999999999999;
                        return;
                    }
                    else if (m_Doppler_2)
                    {
                        m_Doppler_3 = true;
                    }
                    else if (m_Doppler_1)
                    {
                        //m_Doppler_2 = true;
                        m_IsMovingFurtherAway = true;
                        m_Doppler_3 = false;
                        m_Doppler_2 = false;
                        m_Doppler_1 = false;

                        if (m_Controller.m_EntityID == 12) Debug.Log("Is moving further away");

                        ReachedGPSWaypoint(m_WaypointTarget.position);
                        m_PreviousDistanceFromTarget = 9999999999999999999;
                        return;
                    }
                    else
                    {
                        m_Doppler_1 = true;
                    }
                    //ReachedGPSWaypoint(m_WaypointTarget.position);
                    //return;
                }
            }

            if (m_Speed < m_Controller.m_DesiredSpeed) m_Speed += m_Controller.m_Acceleration * Time.deltaTime;
            else if(m_Speed > m_Controller.m_DesiredSpeed) m_Speed -= m_Controller.m_Acceleration * Time.deltaTime;

            m_EstTimeToDestination = m_DistanceFromTarget / m_Speed;

            if (a_TargetXYZPosition != m_PreviousDestination)
            {
                m_OriginalEstTimeToDestination = m_EstTimeToDestination;
                m_PreviousDestination = a_TargetXYZPosition;
            }

            if (m_Controller.HasPreviousUpdate())
            {
                l_NewUpdate.Position = CalculatePosition(a_TargetXYZPosition);

                if(l_NewUpdate.Position == a_TargetXYZPosition)
                {
                    if (m_Controller.m_EntityID == 12) Debug.Log("Setting arrival at: " + a_TargetXYZPosition);
                    ReachedGPSWaypoint(a_TargetXYZPosition);
                    return;
                }
                else
                {
                    l_NewUpdate.Rotation = CalculateRotation(l_NewUpdate.Position);
                    l_NewUpdate.GPS = CalculateGPS(l_NewUpdate.Position);
                }
            }
            else
            {
                //Debug.Log("Update No Prev: " + m_CurrentTargetXYZPosition);
                l_NewUpdate.Position = Vector3.MoveTowards(m_Controller.m_Transform.position, a_TargetXYZPosition, Time.deltaTime * (m_Controller.m_MaxSpeed * 0.5f * Common.knotsToMeters * m_CurrentSimSpeed));

                if(m_WaypointBehaviorMode == WaypointBehaviorMode.CHARACTER)
                {
                    l_NewUpdate.Position = a_TargetXYZPosition;
                }

                Debug.DrawLine(l_NewUpdate.Position, l_NewUpdate.Position + (transform.up * 10), Color.blue, 5);

                m_PositionHeading = l_NewUpdate.Position - m_WaypointTarget.position;

                if (m_PositionHeading != Vector3.zero)
                {
                    l_NewUpdate.Rotation.y = Quaternion.LookRotation((m_PositionHeading).normalized).eulerAngles.y;
                }
            }

            l_NewUpdate.State = m_CurrentTargetUpdate.State;
            l_NewUpdate.Value = m_CurrentTargetUpdate.Value;

            //if (m_Controller.m_EntityID == 12) Debug.Log("Waypoint: " + l_NewUpdate.Position);

            if(m_SingleMessage && !m_SingleMessageSent)
            {
                m_Controller.addPosition(l_NewUpdate);
                m_Controller.setState(EntityState.DEFAULT_POSUPDATE);
                m_SingleMessageSent = true;
            }
            else
            {
                m_Controller.addPosition(l_NewUpdate);
                m_Controller.setState(EntityState.DEFAULT_POSUPDATE);
            }
        }
        else
        {
            //if (m_Controller.m_EntityID == 12) Debug.Log(m_Controller.m_EntityName + " arrived at waypoint: " + a_TargetXYZPosition);
            ReachedGPSWaypoint(a_TargetXYZPosition);
        }
    }

    void StateUpdate()
    {
        Debug.Log(m_Controller.m_EntityName + " got waypointstate " + m_CurrentTargetUpdate.State + " - " + m_CurrentTargetUpdate.Value);

        m_CurrentTargetUpdate.Position = m_WaypointTarget.position;
        //if(m_Controller.HasPreviousUpdate()) m_Controller.m_PreviousSimUpdate.Position = m_WaypointTarget.position;

        if (m_CurrentTargetUpdate.State == EntityState.SENSORS_ACTIVATED)
        {
            //Debug.Log("SENSORS_ACTIVATED - " + m_CurrentTargetUpdate.CMD);

            if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
            {
                // Debug.Log("Sensor type");

                Sensor l_Sensor = m_Controller.GetComponent<Sensor>();

                l_Sensor.SetSpecificSensorActive(m_CurrentTargetUpdate.CMD, true);
            }
            else if (typeof(Boat).IsAssignableFrom(m_Controller.GetType()))
            {
                //Debug.Log("Boat type");

                Boat l_Boat = m_Controller.GetComponent<Boat>();

                if (l_Boat.m_ActiveSystem)
                {
                    if (typeof(Sensor).IsAssignableFrom(l_Boat.m_ActiveSystem.GetType()))
                    {
                        Sensor l_Sensor = l_Boat.m_ActiveSystem.GetComponent<Sensor>();

                        l_Sensor.SetSpecificSensorActive(m_CurrentTargetUpdate.CMD, true);
                    }
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.SENSORS_DEACTIVATED)
        {
            //Debug.Log("SENSORS_DEACTIVATED - " + m_CurrentTargetUpdate.CMD);

            if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
            {
                //Debug.Log("Sensor type");

                Sensor l_Sensor = m_Controller.GetComponent<Sensor>();

                l_Sensor.SetSpecificSensorActive(m_CurrentTargetUpdate.CMD, false);
            }
            else if (typeof(Boat).IsAssignableFrom(m_Controller.GetType()))
            {
                //Debug.Log("Boat type");

                Boat l_Boat = m_Controller.GetComponent<Boat>();

                if (l_Boat.m_ActiveSystem)
                {
                    if (typeof(Sensor).IsAssignableFrom(l_Boat.m_ActiveSystem.GetType()))
                    {
                        Sensor l_Sensor = l_Boat.m_ActiveSystem.GetComponent<Sensor>();

                        l_Sensor.SetSpecificSensorActive(m_CurrentTargetUpdate.CMD, false);
                    }
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.RISE)
        {
            Rise(m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.PASS_WAYPOINTS)
        {
            m_Controller.setState(EntityState.PASS_WAYPOINTS);
            if (m_Waypoints.Count == 0) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.CIRCLE)
        {
            m_EntityToCircle = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);
            Debug.Log("Looking for ID: " + (int)m_CurrentTargetUpdate.Value);

            if (m_EntityToCircle)
            {
                Debug.Log("Starting to circle");
                m_Radius = Common.GetDistanceIgnoringY(m_Controller.transform.position, m_EntityToCircle.transform.position);

                m_CirclingPosition = new Vector3((m_EntityToCircle.transform.position.x + Mathf.Sin(m_Angle) * m_Radius), m_Controller.transform.position.y, ((m_EntityToCircle.transform.position.z + Mathf.Cos(m_Angle) * m_Radius)));

                m_CirclingRotation = Quaternion.LookRotation(m_CirclingPosition - m_Controller.transform.position, m_Controller.transform.up);

                m_Angle = Mathf.Atan2(m_Controller.transform.position.x - m_CirclingPosition.x, m_Controller.transform.position.z - m_CirclingPosition.z);

                //angle = atan2(y2 - y1, x2 - x1)
                Debug.Log(m_Angle);

                m_Circling = true;
            }
            else
            {
                Debug.Log("Failed to find target to circle");
                m_Circling = false;
            }

            //SimUpdate l_Update = new SimUpdate();
            //l_Update.GPS.lat = 0;
            //l_Update.GPS.lon = 0;
            //l_Update.GPS.alt = m_WaypointTarget.position.y;

            //l_Update.State = EntityState.UNKNOWN;
            //l_Update.Type = UpdateType.POSITION;
            //l_Update.Rotation.x = -500;
            //l_Update.Rotation.y = -500;
            //l_Update.Rotation.z = -500;

            //addWaypoint(l_Update, 0);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DEPTHMODE_DEPTH)
        {
            m_Controller.m_DesiredDepth = m_CurrentTargetUpdate.Value;
            m_DivingToDepth = true;
            Debug.Log("Setting Desired Depth to: " + m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.PAUSED)
        {
            m_Controller.m_TimeToPause = m_CurrentTargetUpdate.Value / m_CurrentSimSpeed;
            m_Controller.m_PausedTimer = 0;
            m_Controller.m_Paused = true;

            Helicopter l_Helo = m_Controller.GetComponent<Helicopter>();

            if (l_Helo) m_Speed = 0;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.TRUEPAUSED)
        {
            m_Controller.m_TimeToPause = m_CurrentTargetUpdate.Value;
            m_Controller.m_PausedTimer = 0;
            m_Controller.m_Paused = true;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.STARTED)
        {
            //Debug.Log("Attempting to start Entity: " + (int)m_CurrentTargetUpdate.Value);

            Entity l_Entity = SimulatorSettings.getEntityList().getEntityByXSIMID((int)m_CurrentTargetUpdate.Value);

            if (l_Entity)
            {
                if ((l_Entity.m_ControlObjects.HasControlObject("WaypointModule")) && (l_Entity.m_WaypointsStarted == false))
                {
                    l_Entity.StartWaypoints();
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.ATTACH)
        {
            Entity l_Parent = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);

            if (l_Parent)
            {
                m_Controller.m_ParentEntity = l_Parent;

                if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
                {

                    m_Controller.SetPosition(m_Controller.m_ParentEntity.m_AirVehicleAttachPoint.transform.position + m_ModelOffset);
                    m_Controller.SetParent(m_Controller.m_ParentEntity);
                    m_Controller.SetRotation(m_Controller.m_ParentEntity.transform.rotation);
                }
                else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
                {
                    if (m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint)
                    {
                        m_WaypointTarget.SetParent(m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint);
                    }
                    else if (m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint)
                    {
                        m_WaypointTarget.SetParent(m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint);
                    }

                    m_WaypointTarget.localPosition = Vector3.zero;
                    m_Controller.SetRotation(m_Controller.m_ParentEntity.transform.rotation);
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DETTACH)
        {
            m_Controller.SetParent(null);
        }

        // States that should not be passed to the entity

        else if (m_CurrentTargetUpdate.State == EntityState.SINGLERUN)
        {
            m_WaypointModuleMode = WaypointModuleMode.SINGLERUN;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.REPEAT)
        {
            m_WaypointModuleMode = WaypointModuleMode.REPEAT;
            removeWaypoint(m_CurrentWaypointIndex);
            return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.MOVE_TO_THREAT_OFFSET)
        {
            Debug.Log("MOVE_TO_THREAT_OFFSET");
            MoveToThreatOffset(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.MOVE_TO_THREAT)
        {
            Debug.Log("MOVE_TO_THREAT");
            MoveToThreat(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.FORWARD)
        {
            Forward(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.FORWARDLEFT)
        {
            ForwardLeft(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.FORWARDRIGHT)
        {
            ForwardRight(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.STRAIGHT)
        {
            Straight(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.LEFT)
        {
            Left(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.RIGHT)
        {
            Right(m_Controller.m_Target, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DELAYED_SENSORS_ACTIVATED)
        {
            m_Controller.DelayedApplyState(EntityState.SENSORS_ACTIVATED, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DELAYED_SENSORS_DEACTIVATED)
        {
            m_Controller.DelayedApplyState(EntityState.SENSORS_DEACTIVATED, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DELAYED_SYSTEM_LAUNCH)
        {
            m_Controller.DelayedApplyState(EntityState.SYSTEM_LAUNCHED, m_CurrentTargetUpdate.Value);
        }

        else if (m_CurrentTargetUpdate.State == EntityState.OPEN_BAY)
        {
            if (m_Controller.m_EntitySMMTTID == 95)
            {
                Boat l_Boat = m_Controller.GetComponent<Boat>();

                if (l_Boat)
                {
                    l_Boat.OpenDoors();
                }
            }
            else if (m_Controller.m_ParentEntity)
            {
                if (typeof(Boat).IsAssignableFrom(m_Controller.m_ParentEntity.GetType()))
                {
                    Boat l_Boat = m_Controller.m_ParentEntity.GetComponent<Boat>();

                    if (l_Boat)
                    {
                        l_Boat.OpenDoors();
                    }
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.HOLD)
        {
            Boat l_Boat = m_Controller.GetComponent<Boat>();

            if (l_Boat)
            {
                l_Boat.m_HoldBeforeLaunching = !l_Boat.m_HoldBeforeLaunching;
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.RETURN_TO_HOST)
        {
            //removeWaypoint(m_CurrentWaypointIndex);

            if (m_Controller.m_ParentEntity)
            {
                if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
                {
                    //Debug.Log("Returning Entity is of Type: Air");
                    m_HostTransform = m_Controller.m_ParentEntity.m_AirVehicleAttachPoint.transform;

                    m_ReturnDest = m_HostTransform.transform.position;
                    m_ReturnDest.y = m_WaypointTarget.position.y;
                }
                else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
                {
                    //Debug.Log("Returning Entity is of Type: Surface");

                    if (m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint)
                    {
                        m_HostTransform = m_Controller.m_ParentEntity.m_SurfaceVehicleLoadingPoint.transform;
                    }
                    else if (m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint)
                    {
                        m_HostTransform = m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint.transform;
                    }
                    else
                    {
                        m_HostTransform = m_Controller.m_ParentEntity.transform;
                    }

                    m_ReturnDest = m_HostTransform.transform.position;
                    m_ReturnDest.y = m_WaypointTarget.position.y;

                    //if(typeof(Boat).IsAssignableFrom(m_Controller.m_ParentEntity.GetType()))
                    //{
                    //    Boat l_Boat = m_Controller.m_ParentEntity.GetComponent<Boat>();

                    //    if(l_Boat)
                    //    {
                    //        l_Boat.OpenDoors();
                    //    }
                    //}
                }
                else
                {
                    //Debug.Log("Returning Entity is of Type: None?");
                    m_HostTransform = m_Controller.m_ParentEntity.m_SurfaceVehicleAttachPoint.transform;

                    m_ReturnDest = m_HostTransform.transform.position;
                    m_ReturnDest.y = m_HostTransform.position.y;
                }

                m_ReturningToHost = true;

                if (!CheckArrival(m_ReturnDest))
                {
                    m_ReturnToHostMessage.Type = UpdateType.POSITION;
                    m_ReturnToHostMessage.State = EntityState.UNKNOWN;

                    m_CurrentTargetLatLon = GPSEncoder.DUSCToGPS(m_ReturnDest.x, m_ReturnDest.y, m_ReturnDest.z);

                    m_ReturnToHostMessage.GPS.lat = m_CurrentTargetLatLon.lat;
                    m_ReturnToHostMessage.GPS.lon = m_CurrentTargetLatLon.lon;
                    m_ReturnToHostMessage.GPS.alt = m_ReturnDest.y + m_ModelOffset.y;

                    addWaypoint(m_ReturnToHostMessage, 0);

                    //l_NewUpdate.Type = UpdateType.STATE;
                    //l_NewUpdate.State = EntityState.RETURN_TO_HOST;

                    //addWaypoint(l_NewUpdate, m_CurrentWaypointIndex + 1);
                }
                else
                {
                    //Debug.Log("ARRIVED");
                    //removeWaypoint(m_CurrentWaypointIndex);
                    m_ReturningToHost = false;
                    ReachedGPSWaypoint(m_CurrentTargetUpdate.State);
                }


                return;
            }
        }


        else if (m_CurrentTargetUpdate.State == EntityState.LAND)
        {
            if (m_Controller.m_ParentEntity)
            {
                if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
                {
                    m_HostTransform = m_Controller.m_ParentEntity.m_AirVehicleAttachPoint.transform;

                    //m_PreviousDesiredSpeed = m_Controller.m_DesiredSpeed;
                    //m_Controller.m_DesiredSpeed = m_LandingSpeed;

                    m_Controller.transform.SetParent(m_HostTransform);

                    m_LandingLocalPos = m_Controller.transform.localPosition;

                    if (!m_Landing)
                    {
                        Physics.Raycast(m_Controller.transform.position, new Vector3(0, -10, 0), out m_LandingHit, 30, LayerMask.NameToLayer("Entities"));

                        if (m_LandingHit.collider)
                        {

                            m_LandingTargetHeight = m_LandingHit.point.y + m_ModelOffset.y;
                        }
                    }

                    m_LandingTarget = m_HostTransform.transform.position;
                    m_LandingTarget.y = m_LandingTargetHeight;

                    if (m_WaypointTarget.parent != m_HostTransform)
                    {
                        m_WaypointTarget.SetParent(m_HostTransform);
                        m_WaypointTarget.localPosition = new Vector3(0, m_WaypointTarget.position.y, 0);
                    }

                    if (!CheckArrival(m_LandingTarget))
                    {
                        m_LandingTimer += Time.deltaTime;
                        m_Landing = true;

                        m_LandingAirVehicleMessage.Type = UpdateType.POSITION;
                        m_LandingAirVehicleMessage.State = EntityState.UNKNOWN;

                        m_CurrentTargetLatLon = GPSEncoder.DUSCToGPS(m_LandingTarget.x, m_LandingTarget.y, m_LandingTarget.z);

                        m_LandingAirVehicleMessage.GPS.lat = m_CurrentTargetLatLon.lat;
                        m_LandingAirVehicleMessage.GPS.lon = m_CurrentTargetLatLon.lon;
                        m_LandingAirVehicleMessage.GPS.alt = m_LandingTarget.y;

                        addWaypoint(m_LandingAirVehicleMessage, 0);
                    }
                    else
                    {
                        Debug.Log("LANDED");
                        m_Landing = false;

                        Debug.Break();

                        m_LandingTimer = 0;

                        //m_LandingTarget = Vector3.zero;
                        //m_LandingTarget.y += m_LandingTargetHeight;

                        m_WaypointTarget.SetParent(m_Controller.m_ParentEntity.m_AirVehicleAttachPoint);
                        m_WaypointTarget.position = m_LandingHit.point + m_ModelOffset;

                        ReachedGPSWaypoint(m_CurrentTargetUpdate.State);

                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
                        {
                            Helicopter l_Helo = m_Controller.GetComponent<Helicopter>();

                            if (l_Helo) l_Helo.ClearTiltValues();
                        }
                    }

                    return;
                }
            }

        }

        else if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_NEARSURFACE_MILCOS)
        {
            if (ReacquireMILCOs("NEARSURFACE")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_VOLUME_MILCOS)
        {
            if (ReacquireMILCOs("VOLUME")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_BOTTOM_MILCOS)
        {
            if (ReacquireMILCOs("BOTTOM")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE)
        {
            Entity l_Entity = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);

            if (l_Entity)
            {
                l_Entity.setState(EntityState.MINE_REACQUIRED);
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.IDENTIFY)
        {
            Entity l_Entity = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);

            if (l_Entity)
            {
                l_Entity.setState(EntityState.MINE_IDENTIFIED);
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_NEUTRALIZE)
        {
            Entity l_Entity = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);

            if (l_Entity)
            {
                l_Entity.setState(EntityState.MINE_REACQUIRED_NEUTRALIZE);
            }
        }

        else if (!typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
        {
            if (m_CurrentTargetUpdate.State == EntityState.IDENTIFY_NEARSURFACE_MILCOS)
            {
                if (IdentifyMILCOs("NEARSURFACE")) return;
            }

            if (m_CurrentTargetUpdate.State == EntityState.IDENTIFY_VOLUME_MILCOS)
            {
                if (IdentifyMILCOs("VOLUME")) return;
            }

            if (m_CurrentTargetUpdate.State == EntityState.IDENTIFY_BOTTOM_MILCOS)
            {
                if (IdentifyMILCOs("BOTTOM")) return;
            }

            if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_NEARSURFACE_NEUTRALIZE)
            {
                if (Reacquire_Neutralize("NEARSURFACE")) return;
            }

            if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_VOLUME_NEUTRALIZE)
            {
                if (Reacquire_Neutralize("VOLUME")) return;
            }

            if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_BOTTOM_NEUTRALIZE)
            {
                if (Reacquire_Neutralize("BOTTOM")) return;
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.NEUTRALIZE_NEARSURFACE)
        {
            if (Neutralize("NEARSURFACE")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.NEUTRALIZE_VOLUME)
        {
            if (Neutralize("VOLUME")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.NEUTRALIZE_BOTTOM)
        {
            if (Neutralize("BOTTOM")) return;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.START_BOTTOM_MINELINE)
        {
            m_DroppingMineLine = true;
            m_MineInterval = (int)m_CurrentTargetUpdate.Value;
            m_MineLineTimer = 0;
            m_MineState = EntityState.DROP_BOTTOMMINE;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.START_SURFACE_MINELINE)
        {
            m_DroppingMineLine = true;
            m_MineInterval = (int)m_CurrentTargetUpdate.Value;
            m_MineLineTimer = 0;
            m_MineState = EntityState.DROP_SURFACEMINE;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.STOP_MINELINE)
        {
            m_DroppingMineLine = false;
        }

        else if (m_CurrentTargetUpdate.State == EntityState.SETPARENT)
        {
            if ((int)m_CurrentTargetUpdate.Value < 0)
            {
                m_Controller.SetParent(null);
            }
            else
            {
                Entity l_Parent = SimulatorSettings.getEntityList().getEntityByVIBEID((int)m_CurrentTargetUpdate.Value);

                if (l_Parent)
                {
                    m_Controller.SetParent(l_Parent);
                    m_Controller.m_RigidBody.isKinematic = true;
                }
            }
        }

        else if (m_CurrentTargetUpdate.State == EntityState.DELAYEDFOLLOW)
        {
            //Debug.Log("Delayed follow");

            if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
            {
                //Debug.Log("Type is sensor");
                Sensor l_Sensor = m_Controller.GetComponent<Sensor>();

                if (l_Sensor.m_DelayedFollowScript)
                {
                    Debug.Log("Delayed follow script found");
                    l_Sensor.m_UsingDelayedFollowScript = true;
                    l_Sensor.m_DelayedFollowScript.m_Parent = l_Sensor.m_ParentEntity.transform;
                    l_Sensor.m_DelayedFollowScript.m_SecondsToDelay = m_CurrentTargetUpdate.Value;
                    //l_Sensor.m_DelayedFollowScript.m_HeightOverride = l_Sensor.transform.position.y;
                    l_Sensor.m_DelayedFollowScript.m_HeightOverride = l_Sensor.m_FallToDepth;
                    l_Sensor.m_DelayedFollowScript.m_UseHeightOverride = true;

                    //l_Sensor.m_DelayedFollowScript.m_WeakLerp = false;
                    l_Sensor.m_DelayedFollowScript.m_Controller = m_Controller;
                    //l_Sensor.SetParent(null);
                    l_Sensor.m_DelayedFollowScript.m_Active = true;
                }
            }
        }

        

        //if (m_CurrentTargetUpdate.State == EntityState.REACQUIRE_NEUTRALIZE)
        //{
        //    if (!m_ReacquireNeutralizeStarted && SimulatorSettings.getEntityList().m_PossibleMines.Count > 0)
        //    {
        //        if (!m_IdentifyMilcosStarted && !m_ReacquireMilcosStarted)
        //        {
        //            m_CurrentMineIndex = 0;
        //            m_ReacquireNeutralizeStarted = true;
        //        }
        //    }
        //    else
        //    {

        //    }
        //}

        m_Controller.setState(m_CurrentTargetUpdate.State);

        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
        {
            removeWaypoint(m_CurrentWaypointIndex);
        }
        else
        {
            m_CurrentWaypointIndex++;
        }
    }

    void MoveToThreat(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            if(a_Distance < 0)
            {
                Vector3 l_Direction = Vector3.zero;
                l_Direction.x = m_WaypointTarget.position.x - a_Target.transform.position.x;
                l_Direction.y = 0;
                l_Direction.z = m_WaypointTarget.position.z - a_Target.transform.position.z;

                Vector3 l_OppositeDir = Vector3.Reflect(l_Direction, Vector3.up);
                Vector3 l_FarPoint = a_Target.transform.position + (Vector3.Reflect(l_Direction, Vector3.up) * a_Distance);
                l_FarPoint.y = m_ReacqHeight;
                Vector3 l_Vec = l_FarPoint;

                SimUpdate l_Update = new SimUpdate();
                Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

                Debug.DrawLine(m_Controller.transform.position, a_Target.transform.position, Color.red, 100);
                Debug.DrawLine(a_Target.transform.position, l_Vec, Color.blue, 100);

                Debug.Log("Moving to point " + a_Distance + " meters behind target " + a_Target.m_EntityName);

                l_Update.GPS.lat = l_GPS.x;
                l_Update.GPS.lon = l_GPS.y;
                l_Update.GPS.alt = m_ReacqHeight;

                l_Update.State = EntityState.UNKNOWN;
                l_Update.Rotation.x = -500;
                l_Update.Rotation.y = -500;
                l_Update.Rotation.z = -500;

                addWaypoint(l_Update, 1);
            }
            else
            {
                Vector3 l_Position = Vector3.zero;
                l_Position = a_Target.transform.position;
                l_Position.y = m_WaypointTarget.position.y;

                Vector3 l_Vec = Vector3.MoveTowards(l_Position, m_WaypointTarget.position, a_Distance);
                SimUpdate l_Update = new SimUpdate();
                Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

                Debug.DrawLine(l_Vec, l_Vec, Color.red, 100);
                //Debug.Log("Moving to point " + a_Distance + " meters from target " + a_Target.m_EntityName);

                l_Update.GPS.lat = l_GPS.x;
                l_Update.GPS.lon = l_GPS.y;
                l_Update.GPS.alt = m_WaypointTarget.position.y;

                l_Update.State = EntityState.UNKNOWN;
                l_Update.Rotation.x = -500;
                l_Update.Rotation.y = -500;
                l_Update.Rotation.z = -500;

                addWaypoint(l_Update, 1);
            }
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    void MoveToThreatOffset(Entity a_Target, float a_Distance)
    {
        
        if (a_Target)
        {
            Debug.Log("Has Target");

            if (a_Distance < 0)
            {
                Debug.Log("Negative Distance");
                Vector3 l_Direction = Vector3.zero;
                Vector3 l_PositionToCalcFrom;
                Vector3 l_Offset = (m_Controller.transform.forward * (a_Distance * 3));

                l_PositionToCalcFrom.x = m_WaypointTarget.position.x + l_Offset.x;
                l_PositionToCalcFrom.y = 0;
                l_PositionToCalcFrom.z = m_WaypointTarget.position.z + l_Offset.z;

                l_Direction.x = l_PositionToCalcFrom.x - a_Target.transform.position.x;
                l_Direction.y = 0;
                l_Direction.z = l_PositionToCalcFrom.z - a_Target.transform.position.z;

                Vector3 l_OppositeDir = Vector3.Reflect(l_Direction, Vector3.up);
                Vector3 l_FarPoint = a_Target.transform.position + (Vector3.Reflect(l_Direction, Vector3.up) * a_Distance);
                l_FarPoint.y = m_ReacqHeight;
                Vector3 l_Vec = l_FarPoint;

                SimUpdate l_Update = new SimUpdate();
                Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

                Debug.DrawLine(m_Controller.transform.position, a_Target.transform.position, Color.red, 100);
                Debug.DrawLine(a_Target.transform.position, l_Vec, Color.blue, 100);

                Debug.Log("Moving to point " + a_Distance + " meters behind target " + a_Target.m_EntityName);

                l_Update.GPS.lat = l_GPS.x;
                l_Update.GPS.lon = l_GPS.y;
                l_Update.GPS.alt = m_ReacqHeight;

                l_Update.State = EntityState.UNKNOWN;
                l_Update.Rotation.x = -500;
                l_Update.Rotation.y = -500;
                l_Update.Rotation.z = -500;

                addWaypoint(l_Update, 1);
            }
            else
            {
                Debug.Log("Positive Distance");

                Vector3 l_Position = Vector3.zero;
                l_Position = a_Target.transform.position;
                l_Position.y = m_WaypointTarget.position.y;

                Vector3 l_PositionToCalcFrom;
                Vector3 l_Offset = (m_Controller.transform.forward * (a_Distance * 9));

                l_PositionToCalcFrom.x = m_WaypointTarget.position.x + l_Offset.x;
                l_PositionToCalcFrom.y = m_WaypointTarget.position.y;
                l_PositionToCalcFrom.z = m_WaypointTarget.position.z + l_Offset.z;

                Vector3 l_Vec = Vector3.MoveTowards(l_Position, l_PositionToCalcFrom, a_Distance);
                SimUpdate l_Update = new SimUpdate();
                Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

                Debug.DrawLine(l_PositionToCalcFrom, l_Vec, Color.red, 100);
                //Debug.Log("Moving to point " + a_Distance + " meters from target " + a_Target.m_EntityName);

                l_Update.GPS.lat = l_GPS.x;
                l_Update.GPS.lon = l_GPS.y;
                l_Update.GPS.alt = m_WaypointTarget.position.y;

                l_Update.State = EntityState.UNKNOWN;
                l_Update.Rotation.x = -500;
                l_Update.Rotation.y = -500;
                l_Update.Rotation.z = -500;

                addWaypoint(l_Update, 1);
            }
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    void Forward(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            Debug.Log("Moving forward: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += m_Controller.transform.forward * a_Distance;

            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_TempGPS.alt;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    void ForwardLeft(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            Debug.Log("Moving forward left: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += (m_Controller.transform.forward * a_Distance) + (-m_Controller.transform.right * a_Distance);

            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            //Debug.Log("Forward Left: " + m_ReacqHeight);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_ReacqHeight;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    void ForwardRight(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            Debug.Log("Moving forward right: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += (m_Controller.transform.forward * a_Distance) + (m_Controller.transform.right * a_Distance);

            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            //Debug.Log("Forward Right: " + m_ReacqHeight);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_ReacqHeight;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    public void Straight(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            //Debug.Log("Straight: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += m_Controller.transform.forward * a_Distance;

            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            //Debug.Log("Straight: " + m_ReacqHeight);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_ReacqHeight;
            l_Update.Position = m_TempVec3;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    public void Left(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            //Debug.Log("Straight: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += (-m_Controller.transform.right * a_Distance);
            //(-m_Controller.transform.forward * (a_Distance / 4))
            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            //Debug.Log("Straight: " + m_ReacqHeight);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_ReacqHeight;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    public void Right(Entity a_Target, float a_Distance)
    {
        if (a_Target)
        {
            //Debug.Log("Straight: " + a_Distance);
            m_TempVec3 = m_Controller.transform.position;
            m_TempVec3 += (m_Controller.transform.right * a_Distance);
            // (-m_Controller.transform.forward * (a_Distance / 4))

            m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

            SimUpdate l_Update = new SimUpdate();
            //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

            //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

            //Debug.Log("Straight: " + m_ReacqHeight);

            l_Update.GPS.lat = m_TempGPS.lat;
            l_Update.GPS.lon = m_TempGPS.lon;
            l_Update.GPS.alt = m_ReacqHeight;

            l_Update.State = EntityState.DEFAULT_POSUPDATE;
            l_Update.Rotation.x = -500;
            l_Update.Rotation.y = -500;
            l_Update.Rotation.z = -500;

            addWaypoint(l_Update, 1);
        }
        else
        {
            Debug.Log("[Helo] Could not find a target mine.");
        }
    }

    public void Rise(float a_Distance)
    {
        Debug.Log("Rise: " + a_Distance);
        m_TempVec3 = m_Controller.transform.position;
        m_TempVec3 += m_Controller.transform.forward * (a_Distance / 4);
        m_TempVec3.y = a_Distance;
        // (-m_Controller.transform.forward * (a_Distance / 4))

        m_TempGPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);

        SimUpdate l_Update = new SimUpdate();
        //Vector2 l_GPS = GPSEncoder.USCToGPS(l_Vec);

        //Debug.DrawLine(l_Vec, l_Vec + new Vector3(0, 10, 0), Color.red, 100);

        //Debug.Log("Straight: " + m_ReacqHeight);

        l_Update.GPS.lat = m_TempGPS.lat;
        l_Update.GPS.lon = m_TempGPS.lon;
        l_Update.GPS.alt = m_TempVec3.y;

        l_Update.State = EntityState.DEFAULT_POSUPDATE;
        l_Update.Rotation.x = -500;
        l_Update.Rotation.y = -500;
        l_Update.Rotation.z = -500;

        addWaypoint(l_Update, 1);
    }

    public void Landed()
    {
        Debug.Log("LANDED");
        m_Landing = false;

        //Debug.Break();

        m_Controller.m_RigidBody.useGravity = true;
        m_Controller.m_RigidBody.isKinematic = false;

        m_LandingTarget = Vector3.zero;
        m_LandingTarget.y += m_LandingTargetHeight;

        m_WaypointTarget.SetParent(m_Controller.m_ParentEntity.m_AirVehicleAttachPoint);
        //m_WaypointTarget.localPosition = m_ModelOffset;
        m_WaypointTarget.localRotation = Quaternion.identity;

        if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
        {
            Helicopter l_Helo = m_Controller.GetComponent<Helicopter>();

            if (l_Helo) l_Helo.ClearTiltValues();
        }

        m_Speed = 0;
    }

    public void AddRQWaypoint_MoveToThreat(int a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.MOVE_TO_THREAT;
        l_NewUpdate.Value = a_Val;
        l_NewUpdate.GPS.lat = m_Controller.currentGPSPosition.x;
        l_NewUpdate.GPS.lon = m_Controller.currentGPSPosition.y;
        l_NewUpdate.GPS.alt = m_ReacqHeight;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_MoveToThreat_Offset(int a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.MOVE_TO_THREAT_OFFSET;
        l_NewUpdate.Value = a_Val;
        l_NewUpdate.GPS.lat = m_Controller.currentGPSPosition.x;
        l_NewUpdate.GPS.lon = m_Controller.currentGPSPosition.y;
        l_NewUpdate.GPS.alt = m_ReacqHeight;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_SensorsActive(bool a_Bool)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;

        if(a_Bool) l_NewUpdate.State = EntityState.SENSORS_ACTIVATED;
        else l_NewUpdate.State = EntityState.SENSORS_DEACTIVATED;

        l_NewUpdate.CMD = "ALL";

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_SpecificSensorsActive(bool a_Bool, string a_Name)
    {
        //Debug.Log("AddRQWaypoint_SpecificSensorsActive - Name: (" + a_Name + ") - (" + a_Bool + ")");

        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;

        if (a_Bool) l_NewUpdate.State = EntityState.SENSORS_ACTIVATED;
        else l_NewUpdate.State = EntityState.SENSORS_DEACTIVATED;

        l_NewUpdate.CMD = a_Name;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_Straight(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.STRAIGHT;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_TurnForwardLeft(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.FORWARDLEFT;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_TurnForwardRight(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.FORWARDRIGHT;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_TurnLeft(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.LEFT;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_TurnRight(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.STATE;
        l_NewUpdate.State = EntityState.RIGHT;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void AddRQWaypoint_SetSpeed(float a_Val)
    {
        SimUpdate l_NewUpdate = new SimUpdate();
        l_NewUpdate.Type = UpdateType.SPEED;
        l_NewUpdate.Value = a_Val;

        addWaypoint(l_NewUpdate, m_ReacqWaypointIndex);
        m_ReacqWaypointIndex++;
    }

    public void ReacquireWaypoints_Surface_To_Vol()
    {
        Debug.Log("ReacquireWaypoints_Surface_To_Vol");

        // First Pass

        AddRQWaypoint_MoveToThreat(40);
        AddRQWaypoint_SpecificSensorsActive(true, "Gap");
        AddRQWaypoint_SpecificSensorsActive(true, "Bow");
        AddRQWaypoint_Straight(240);

        // Finish

        AddRQWaypoint_SensorsActive(false);
    }

    public void ReacquireWaypoints_Surface_To_Bot()
    {
        Debug.Log("ReacquireWaypoints_Surface_To_Bot");

        // First Pass

        AddRQWaypoint_MoveToThreat(0);
        AddRQWaypoint_SpecificSensorsActive(true, "EOID");
        AddRQWaypoint_Straight(160);

        // Turn 1

        AddRQWaypoint_SensorsActive(false);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_TurnForwardRight(60); 
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_Straight(320);
        AddRQWaypoint_TurnForwardRight(60);

        // Second Pass

        AddRQWaypoint_MoveToThreat(0);
        AddRQWaypoint_SpecificSensorsActive(true, "EOID");
        AddRQWaypoint_Straight(160);

        // Turn 2

        AddRQWaypoint_SensorsActive(false);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_TurnForwardRight(60);
        AddRQWaypoint_Straight(320);
        AddRQWaypoint_TurnForwardRight(60);

        // Third Pass

        AddRQWaypoint_MoveToThreat(0);
        AddRQWaypoint_SpecificSensorsActive(true, "EOID");
        AddRQWaypoint_Straight(160);

        // Finish

        AddRQWaypoint_SensorsActive(false);
    }

    public void ReacquireWaypoints_Air_To_NearSurface()
    {
        Debug.Log("ReacquireWaypoints_Air_To_NearSurface");

        // First Pass

        AddRQWaypoint_MoveToThreat(80);
        AddRQWaypoint_Straight(200);

        // Turn 1

        AddRQWaypoint_TurnLeft(300);

        // Second Pass

        AddRQWaypoint_MoveToThreat_Offset(80);
        AddRQWaypoint_Straight(200);

        // Turn 2

        AddRQWaypoint_TurnRight(300);

        // Third Pass

        AddRQWaypoint_MoveToThreat_Offset(80);
        AddRQWaypoint_Straight(300);

        // Turn 3

        //AddRQWaypoint_TurnForwardLeft(120);

        //// Fourth Pass

        //AddRQWaypoint_MoveToThreat(20);
        //AddRQWaypoint_Straight(40);

        //// Turn 4

        //AddRQWaypoint_TurnForwardLeft(120);

        //// Fifth Pass

        //AddRQWaypoint_MoveToThreat(20);
        //AddRQWaypoint_Straight(40);

        // Finish

        AddRQWaypoint_SensorsActive(false);
    }

    //public void ReacquireWaypoints_Air()
    //{
    //    // First Pass

    //    AddRQWaypoint_MoveToThreat(20);
    //    //AddRQWaypoint_SensorsActive(true);
    //    //AddRQWaypoint_MoveToThreat(-3);
    //    AddRQWaypoint_Straight(40);

    //    // Turn 1

    //    //AddRQWaypoint_SensorsActive(false);
    //    AddRQWaypoint_TurnForwardLeft(120);

    //    // Second Pass

    //    AddRQWaypoint_MoveToThreat(20);
    //    //AddRQWaypoint_SensorsActive(true);
    //    //AddRQWaypoint_MoveToThreat(-3);
    //    AddRQWaypoint_Straight(40);

    //    // Turn 2

    //    //AddRQWaypoint_SensorsActive(false);
    //    AddRQWaypoint_TurnForwardLeft(120);

    //    // Third Pass

    //    AddRQWaypoint_MoveToThreat(20);
    //    //AddRQWaypoint_SensorsActive(true);
    //    //AddRQWaypoint_MoveToThreat(-3);
    //    AddRQWaypoint_Straight(40);

    //    // Turn 3

    //    // AddRQWaypoint_SensorsActive(false);
    //    AddRQWaypoint_TurnForwardLeft(120);

    //    // Fourth Pass

    //    AddRQWaypoint_MoveToThreat(20);
    //    //AddRQWaypoint_SensorsActive(true);
    //    //AddRQWaypoint_MoveToThreat(-3);
    //    AddRQWaypoint_Straight(40);

    //    // Turn 4

    //    //AddRQWaypoint_SensorsActive(false);
    //    AddRQWaypoint_TurnForwardLeft(120);

    //    // Fifth Pass

    //    AddRQWaypoint_MoveToThreat(20);
    //    //AddRQWaypoint_SensorsActive(true);
    //    //AddRQWaypoint_MoveToThreat(-3);
    //    AddRQWaypoint_Straight(40);

    //    // Finish

    //    AddRQWaypoint_SensorsActive(false);
    //}

    bool ReacquireMILCOs(string a_MineType)
    {
        if (SimulatorSettings.getEntityList().m_PossibleMines.Count > 0)
        {
            if (!m_ReacquireMilcosStarted)
            {
                Debug.Log("<color=red>Starting reacquire - " + a_MineType + " </color>");
                if (!m_IdentifyMilcosStarted && !m_ReacquireNeutralizeStarted)
                {
                    m_CurrentMineIndex = 0;

                    m_NumberOfMinesToReacq = 0;
                    m_MineList.Clear();

                    for (int i = 0; i < SimulatorSettings.getEntityList().m_PossibleMines.Count; i++)
                    {
                        if (SimulatorSettings.getEntityList().m_PossibleMines[i].m_EntityType.Contains(a_MineType))
                        {
                            m_MineList.Add(SimulatorSettings.getEntityList().m_PossibleMines[i]);
                            m_NumberOfMinesToReacq++;
                        }
                    }

                    Debug.Log("Reacquiring ("+ m_NumberOfMinesToReacq + ") " + a_MineType + " Mines");

                    //m_CurrentMineIndex = m_MineList[m_CurrentMineIndex];

                    if (m_NumberOfMinesToReacq == 0)
                    {
                        Debug.Log("No " + a_MineType + " mines found in possible mines list");

                        Debug.Log("Ending reacquire");
                        m_ReacquireMilcosStarted = false;

                        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
                        {
                            removeWaypoint(m_CurrentWaypointIndex);
                        }
                        else
                        {
                            m_CurrentWaypointIndex++;
                        }
                        return true;
                    }

                    m_Controller.m_Target = m_MineList[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    m_OriginalDesiredSpeed = m_Controller.m_DesiredSpeed;

                    m_ReacqWaypointIndex = m_CurrentWaypointIndex;
                    
                    m_ReacqHeight = m_WaypointTarget.transform.position.y;
//                    Debug.Log("Reacq Height: " + m_ReacqHeight);

                    if(a_MineType == "NEARSURFACE")
                    {
                        Debug.Log("NEARSURFACE");
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
                        {
                            m_CurrentMineType = "NEARSURFACE";
                            //Debug.Log("AIR");
                            ReacquireWaypoints_Air_To_NearSurface();
                        }
                    }
                    else if (a_MineType == "VOLUME")
                    {
                        Debug.Log("VOLUME");
                        m_CurrentMineType = "VOLUME";
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
                        {
                            //Debug.Log("SURFACE");
                            ReacquireWaypoints_Surface_To_Vol();
                        }
                    }
                    else if (a_MineType == "BOTTOM")
                    {
                        Debug.Log("BOTTOM");
                        m_CurrentMineType = "BOTTOM";
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
                        {
                            //Debug.Log("SURFACE");
                            ReacquireWaypoints_Surface_To_Bot();
                        }
                    }


                    m_MinesFinished++;

                    if (m_MinesFinished >= m_NumberOfMinesToReacq)
                    {
                        Debug.Log("<color=red>Ending reacquire - End of list</color>");
                        //m_ReacquireMilcosStarted = false;

                        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
                        {
                            //removeWaypoint(m_CurrentWaypointIndex);
                            removeStateWaypointOfType(m_CurrentWaypointIndex, m_CurrentMineType);
                        }
                        else
                        {
                            m_CurrentWaypointIndex++;
                        }

                        //return false;
                    }
                    else
                    {
                        m_ReacquireMilcosStarted = true;
                    }

                    return true;
                }
            }
            else
            {
                Debug.Log("<color=red>Continuing reacquire - " + a_MineType + " </color>");
                PrevMineIndex = m_CurrentMineIndex;
                m_CurrentMineIndex++;
                //m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                Debug.Log("Reacquiring (" + m_NumberOfMinesToReacq + ") " + a_MineType + " Mines");

                //if (m_CurrentMineIndex == PrevMineIndex)
                //{
                //    m_CurrentMineIndex = -1;
                //}

                if(m_NumberOfMinesToReacq >= m_CurrentMineIndex)
                {
                    Debug.Log("Reached the end");
                    m_CurrentMineIndex = -1;
                }

                if (m_CurrentMineIndex != -1)
                {
                    m_Controller.m_Target = m_MineList[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    if (a_MineType == "NEARSURFACE")
                    {
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR) ReacquireWaypoints_Air_To_NearSurface();
                    }
                    else if (a_MineType == "VOLUME")
                    {
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE) ReacquireWaypoints_Surface_To_Vol();
                    }
                    else if (a_MineType == "BOTTOM")
                    {
                        if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE) ReacquireWaypoints_Surface_To_Bot();
                    }

                    return true;
                }
                else
                {
                    Debug.Log("Ending reacquire");
                    m_ReacquireMilcosStarted = false;
                }   
            }
        }

        return false;
    }

    bool IdentifyMILCOs(string a_MineType)
    {
        if (SimulatorSettings.getEntityList().m_PossibleMines.Count > 0)
        {
            if (!m_IdentifyMilcosStarted)
            {
                Debug.Log("Starting identify");
                if (!m_IdentifyMilcosStarted && !m_ReacquireNeutralizeStarted)
                {
                    m_CurrentMineIndex = 0;

                    m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                    if (m_CurrentMineIndex == -1)
                    {
                        Debug.Log("No " + a_MineType + " mines found in possible mines list");

                        Debug.Log("Ending identify");
                        m_IdentifyMilcosStarted = false;

                        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
                        {
                            removeWaypoint(m_CurrentWaypointIndex);
                        }
                        else
                        {
                            m_CurrentWaypointIndex++;
                        }
                        return true;
                    }

                    m_Controller.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    //if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
                    //{
                    //    m_ReacquireMessage.Type = UpdateType.STATE;
                    //    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    //    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    //    addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex);
                    //}

                    m_MineCheckMessage.Type = UpdateType.STATE;
                    m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    m_MineCheckMessage.Value = 10;
                    m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                    m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                    m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                    m_Controller.addWaypoint(m_MineCheckMessage, m_CurrentWaypointIndex);

                    m_SensorsFlickMessageOn.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOn.State = EntityState.SENSORS_ACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOn, m_CurrentWaypointIndex + 1);

                    m_PauseMessage.Type = UpdateType.STATE;
                    m_PauseMessage.State = EntityState.PAUSED;
                    m_PauseMessage.Value = 5;

                    m_Controller.addWaypoint(m_PauseMessage, m_CurrentWaypointIndex + 2);

                    m_ReacquireMessage.Type = UpdateType.STATE;
                    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    m_Controller.addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex + 3);

                    m_SensorsFlickMessageOff.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOff.State = EntityState.SENSORS_DEACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOff, m_CurrentWaypointIndex + 4);

                    m_IdentifyMilcosStarted = true;
                    return true;
                }
            }
            else
            {
                Debug.Log("Continuing identify");
                m_CurrentMineIndex++;
                m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                if (m_CurrentMineIndex != -1)
                {
                    m_Controller.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    m_MineCheckMessage.Type = UpdateType.STATE;
                    m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    m_MineCheckMessage.Value = 10;
                    m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                    m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                    m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                    m_Controller.addWaypoint(m_MineCheckMessage, m_CurrentWaypointIndex);

                    m_SensorsFlickMessageOn.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOn.State = EntityState.SENSORS_ACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOn, m_CurrentWaypointIndex + 1);

                    m_PauseMessage.Type = UpdateType.STATE;
                    m_PauseMessage.State = EntityState.PAUSED;
                    m_PauseMessage.Value = 5;

                    m_Controller.addWaypoint(m_PauseMessage, m_CurrentWaypointIndex + 2);

                    m_ReacquireMessage.Type = UpdateType.STATE;
                    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    m_Controller.addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex + 3);

                    m_SensorsFlickMessageOff.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOff.State = EntityState.SENSORS_DEACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOff, m_CurrentWaypointIndex + 4);

                    return true;
                }
                else
                {
                    Debug.Log("Ending identify");
                    m_IdentifyMilcosStarted = false;
                }
            }
        }

        return false;
    }

    bool Reacquire_Neutralize(string a_MineType)
    {
        if (SimulatorSettings.getEntityList().m_PossibleMines.Count > 0)
        {
            if (!m_ReacquireNeutralizeStarted)
            {
                Debug.Log("Starting reacquire/neutralize");
                if (!m_ReacquireMilcosStarted && !m_IdentifyMilcosStarted)
                {
                    m_CurrentMineIndex = 0;

                    m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                    if (m_CurrentMineIndex == -1)
                    {
                        Debug.Log("No " + a_MineType + " mines found in possible mines list");

                        Debug.Log("Ending reacquire/neutralize");
                        m_IdentifyMilcosStarted = false;

                        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
                        {
                            removeWaypoint(m_CurrentWaypointIndex);
                        }
                        else
                        {
                            m_CurrentWaypointIndex++;
                        }
                        return true;
                    }

                    m_Controller.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    //if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
                    //{
                    //    m_ReacquireMessage.Type = UpdateType.STATE;
                    //    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    //    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    //    addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex);
                    //}

                    m_MineCheckMessage.Type = UpdateType.STATE;
                    m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    m_MineCheckMessage.Value = 10;
                    m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                    m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                    m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                    m_Controller.addWaypoint(m_MineCheckMessage, m_CurrentWaypointIndex);

                    m_SensorsFlickMessageOn.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOn.State = EntityState.SENSORS_ACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOn, m_CurrentWaypointIndex + 1);

                    m_PauseMessage.Type = UpdateType.STATE;
                    m_PauseMessage.State = EntityState.PAUSED;
                    m_PauseMessage.Value = 5;

                    m_Controller.addWaypoint(m_PauseMessage, m_CurrentWaypointIndex + 2);

                    m_ReacquireMessage.Type = UpdateType.STATE;
                    m_ReacquireMessage.State = EntityState.REACQUIRE_NEUTRALIZE;
                    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    m_Controller.addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex + 3);

                    m_SensorsFlickMessageOff.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOff.State = EntityState.SENSORS_DEACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOff, m_CurrentWaypointIndex + 4);

                    m_MineCheckMessage.Type = UpdateType.STATE;
                    m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    m_MineCheckMessage.Value = 0;
                    m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                    m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                    m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                    m_IdentifyMilcosStarted = true;
                    return true;
                }
            }
            else
            {
                Debug.Log("Continuing reacquire/neutralize");
                m_CurrentMineIndex++;
                m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                if (m_CurrentMineIndex != -1)
                {
                    m_Controller.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    m_MineCheckMessage.Type = UpdateType.STATE;
                    m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    m_MineCheckMessage.Value = 10;
                    m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                    m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                    m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                    m_Controller.addWaypoint(m_MineCheckMessage, m_CurrentWaypointIndex);

                    m_SensorsFlickMessageOn.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOn.State = EntityState.SENSORS_ACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOn, m_CurrentWaypointIndex + 1);

                    m_PauseMessage.Type = UpdateType.STATE;
                    m_PauseMessage.State = EntityState.PAUSED;
                    m_PauseMessage.Value = 5;

                    m_Controller.addWaypoint(m_PauseMessage, m_CurrentWaypointIndex + 2);

                    m_ReacquireMessage.Type = UpdateType.STATE;
                    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    m_Controller.addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex + 3);

                    m_SensorsFlickMessageOff.Type = UpdateType.STATE;
                    m_SensorsFlickMessageOff.State = EntityState.SENSORS_DEACTIVATED;

                    m_Controller.addWaypoint(m_SensorsFlickMessageOff, m_CurrentWaypointIndex + 4);

                    return true;
                }
                else
                {
                    Debug.Log("Ending reacquire/neutralize");
                    m_IdentifyMilcosStarted = false;
                }
            }
        }

        return false;
    }

    int GetMinesRemaining(string a_Type)
    {
        int l_Ret = 0;

        if (a_Type.Contains("NEARSURFACE"))
        {
            l_Ret = SimulatorSettings.getEntityList().m_NumPossibleNearSurfaceMines;
        }

        if (a_Type.Contains("VOLUME"))
        {
            l_Ret = SimulatorSettings.getEntityList().m_NumPossibleVolumeMines;
        }

        if (a_Type.Contains("BOTTOM"))
        {
            l_Ret = SimulatorSettings.getEntityList().m_NumPossibleBottomMines;
        }

        if (a_Type.Contains("SURF"))
        {
            l_Ret = SimulatorSettings.getEntityList().m_NumPossibleSurfMines;
        }

        if (a_Type.Contains("BURIED"))
        {
            l_Ret = SimulatorSettings.getEntityList().m_NumPossibleBuriedMines;
        }

        return l_Ret;
    }

    bool Neutralize(string a_MineType)
    {
        if (GetMinesRemaining(a_MineType) > 0)
        {
            if (!m_NeutralizeStarted)
            {
                Debug.Log("Starting neutralize");
                if (!m_ReacquireMilcosStarted && !m_IdentifyMilcosStarted && !m_ReacquireNeutralizeStarted)
                {
                    m_CurrentMineIndex = 0;

                    m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                    if (m_CurrentMineIndex == -1)
                    {
                        Debug.Log("No " + a_MineType + " mines found in possible mines list");

                        Debug.Log("Ending neutralize");
                        m_IdentifyMilcosStarted = false;

                        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
                        {
                            removeWaypoint(m_CurrentWaypointIndex);
                        }
                        else
                        {
                            m_CurrentWaypointIndex++;
                        }
                        return true;
                    }

                    m_Controller.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                    Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                    //if (typeof(Sensor).IsAssignableFrom(m_Controller.GetType()))
                    //{
                    //    m_ReacquireMessage.Type = UpdateType.STATE;
                    //    m_ReacquireMessage.State = EntityState.IDENTIFY;
                    //    m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    //    addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex);
                    //}

                    if (m_Controller.m_EntitySMMTTID == 5002)
                    {
                        m_SensorInUse = m_Controller.GetComponent<Sensor>();

                        if (m_SensorInUse != null)
                        {
                            if (m_SensorInUse.m_CurrentActiveLaunchable == null)
                            {
                                m_SensorInUse.ExecuteSpecialAction_1();
                            }

                        }
                    }

                    if (m_SensorInUse.m_CurrentActiveLaunchable != null)
                    {
                        m_SensorInUse.m_CurrentActiveLaunchable.m_Target = m_Controller.m_Target;

                        m_MineCheckMessage.Type = UpdateType.STATE;
                        m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                        m_MineCheckMessage.Value = 0;
                        m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                        m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                        m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                        m_SensorInUse.m_CurrentActiveLaunchable.addWaypoint(m_MineCheckMessage, m_SensorInUse.m_CurrentActiveLaunchable.m_WaypointModule.m_CurrentWaypointIndex);

                        m_SensorInUse.StartWaypoints();
                    }
                    else Debug.Log("Didn't create launchable in time");

                    //m_MineCheckMessage.Type = UpdateType.STATE;
                    //m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    //m_MineCheckMessage.Value = 10;
                    //m_MineCheckMessage.Position.x = m_Controller.currentGPSPosition.x;
                    //m_MineCheckMessage.Position.y = m_Controller.currentGPSPosition.y;
                    //m_MineCheckMessage.Position.z = m_WaypointTarget.position.y;

                    //m_Controller.addWaypoint(m_MineCheckMessage, m_CurrentWaypointIndex);

                    //m_SensorsFlickMessage.Type = UpdateType.STATE;
                    //m_SensorsFlickMessage.State = EntityState.SENSORS_ACTIVATED;

                    //m_Controller.addWaypoint(m_SensorsFlickMessage, m_CurrentWaypointIndex + 1);

                    //m_PauseMessage.Type = UpdateType.STATE;
                    //m_PauseMessage.State = EntityState.PAUSED;
                    //m_PauseMessage.Value = 5;

                    //m_Controller.addWaypoint(m_PauseMessage, m_CurrentWaypointIndex + 2);

                    //m_ReacquireMessage.Type = UpdateType.STATE;
                    //m_ReacquireMessage.State = EntityState.REACQUIRE_NEUTRALIZE;
                    //m_ReacquireMessage.Value = m_Controller.m_Target.m_EntityID;

                    //m_Controller.addWaypoint(m_ReacquireMessage, m_CurrentWaypointIndex + 3);

                    //m_SensorsFlickMessage.Type = UpdateType.STATE;
                    //m_SensorsFlickMessage.State = EntityState.SENSORS_DEACTIVATED;

                    //m_Controller.addWaypoint(m_SensorsFlickMessage, m_CurrentWaypointIndex + 4);

                    //m_MineCheckMessage.Type = UpdateType.STATE;
                    //m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                    //m_MineCheckMessage.Value = 0;
                    //m_MineCheckMessage.Position.x = m_Controller.currentGPSPosition.x;
                    //m_MineCheckMessage.Position.y = m_Controller.currentGPSPosition.y;
                    //m_MineCheckMessage.Position.z = m_WaypointTarget.position.y;

                    m_NeutralizeStarted = true;
                    return true;
                }
            }
            else
            {
                if (m_SensorInUse.m_CurrentActiveLaunchable == null)
                {
                    if (m_Controller.m_EntitySMMTTID == 5002)
                    {
                        m_SensorInUse = m_Controller.GetComponent<Sensor>();

                        if (m_SensorInUse != null)
                        {
                            if (m_SensorInUse.m_CurrentActiveLaunchable == null)
                            {
                                m_SensorInUse.ExecuteSpecialAction_1();
                            }

                        }
                    }

                    Debug.Log("Continuing neutralize");
                    m_CurrentMineIndex++;
                    m_CurrentMineIndex = IndexOfNextMineOfType(m_CurrentMineIndex, a_MineType);

                    if (m_CurrentMineIndex != -1)
                    {
                        m_SensorInUse.m_CurrentActiveLaunchable.m_Target = SimulatorSettings.getEntityList().m_PossibleMines[m_CurrentMineIndex];

                        Debug.Log("Target Mine is: " + m_Controller.m_Target.m_EntityID + "(" + m_Controller.m_Target.m_EntityType + ")");

                        if (m_SensorInUse.m_CurrentActiveLaunchable != null)
                        {
                            m_SensorInUse.m_CurrentActiveLaunchable.m_Target = m_Controller.m_Target;

                            m_MineCheckMessage.Type = UpdateType.STATE;
                            m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                            m_MineCheckMessage.Value = 0;
                            m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                            m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                            m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                            m_SensorInUse.m_CurrentActiveLaunchable.addWaypoint(m_MineCheckMessage, m_SensorInUse.m_CurrentActiveLaunchable.m_WaypointModule.m_CurrentWaypointIndex);

                            m_SensorInUse.StartWaypoints();
                        }
                        else Debug.Log("Didn't create launchable in time");

                        if (m_SensorInUse.m_CurrentActiveLaunchable != null)
                        {
                            m_MineCheckMessage.Type = UpdateType.STATE;
                            m_MineCheckMessage.State = EntityState.MOVE_TO_THREAT;
                            m_MineCheckMessage.Value = 0;
                            m_MineCheckMessage.GPS.lat = m_Controller.currentGPSPosition.x;
                            m_MineCheckMessage.GPS.lon = m_Controller.currentGPSPosition.y;
                            m_MineCheckMessage.GPS.alt = m_WaypointTarget.position.y;

                            m_SensorInUse.m_CurrentActiveLaunchable.addWaypoint(m_MineCheckMessage, m_SensorInUse.m_CurrentActiveLaunchable.m_WaypointModule.m_CurrentWaypointIndex);

                            m_SensorInUse.StartWaypoints();
                        }

                        return true;
                    }
                    else
                    {
                        Debug.Log("Ending neutralize");
                        m_NeutralizeStarted = false;
                    }
                }
            }
        }

        return false;
    }

    int IndexOfNextMineOfType(int a_StartIndex, string a_MineType)
    {
        int l_Ret = -1;

        for (int i = a_StartIndex; i < SimulatorSettings.getEntityList().m_PossibleMines.Count; i++)
        {
            if (SimulatorSettings.getEntityList().m_PossibleMines[i].m_EntityType.Contains(a_MineType))
            {
                l_Ret = i;
                break;
            }
        }

        return l_Ret;
    }

    void UpdateWaypoints()
    {
        if (m_CurrentWaypointIndex >= m_TotalNumberOfWaypoints) m_CurrentWaypointIndex = 0;

        m_CurrentTargetUpdate = m_Waypoints[m_CurrentWaypointIndex];

        if (m_CurrentTargetUpdate == null)
        {
            removeWaypoint(m_CurrentWaypointIndex);
            return;
        }
        m_PreviousUpdateType = m_CurrentTargetUpdate.Type;
        m_WaypointsCount = m_Waypoints.Count;

        if (m_Controller.m_WaypointsStarted && !m_Controller.m_Paused)
        {
            //if (m_Controller.m_UseExternalPhysics != true) m_Controller.m_UseExternalPhysics = true;

            if (m_CurrentTargetUpdate.Type == UpdateType.POSITION)
            {
                m_CurrentTargetXYZPosition = GPSEncoder.DGPSToUCS(m_CurrentTargetUpdate.GPS.lat, m_CurrentTargetUpdate.GPS.lon);

                //Debug.Log("Lat: " + m_CurrentTargetUpdate.GPS.lat + " - Lon: " + m_CurrentTargetUpdate.GPS.lon + " Target XYZ: " + m_CurrentTargetXYZPosition + " Origin is: " + SimulatorSettings.getGPSPanel().m_OriginPoint.x.ToString("F8") + " " + SimulatorSettings.getGPSPanel().m_OriginPoint.y.ToString("F8"));

                if (m_Controller.m_DepthMode == Entity.DepthMode.DEPTH)
                {
                    if (m_DivingToDepth)
                    {
                        m_TargetDepth = m_Controller.m_TargetHeight + m_Controller.m_DesiredDepth;
                        m_DepthDiff = Mathf.Abs(m_TargetDepth - m_Controller.transform.position.y);
                        if (m_DepthDiff < 1)
                        {
                            m_DivingToDepth = false;
                        }
                        else
                        {
                            m_CurrentTargetXYZPosition.y = m_Controller.m_TargetHeight + m_Controller.m_DesiredDepth;
                            m_CurrentTargetXYZPosition.y = Mathf.Lerp(transform.position.y, (float)m_CurrentTargetXYZPosition.y, Time.deltaTime * m_Speed);
                        }
                    }
                    else
                    {
                        m_CurrentTargetXYZPosition.y = m_Controller.transform.position.y;
                    }
                }
                else
                {
                    m_CurrentTargetXYZPosition.y = (float)m_CurrentTargetUpdate.GPS.alt;
                }

                //Debug.Log("m_CurrentTargetXYZPosition.y: " + m_CurrentTargetXYZPosition.y);

                //if(m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)


                m_Controller.SetPreviousUpdateAlt(transform.position.y);
                m_CurrentTargetUpdate.GPS.alt = m_CurrentTargetXYZPosition.y;
            }

            if (SimulatorSettings.getMaster())
            {
                if (m_CurrentTargetUpdate.Type == UpdateType.POSITION) // Position Update
                {
                    PositionRotationUpdate(m_CurrentTargetXYZPosition);
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.STATE) // State Update
                {
                    StateUpdate();
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.ROTATION) // Rot Update
                {
                    PositionRotationUpdate(m_CurrentTargetXYZPosition);
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.SPEED) // Speed Update
                {
                    //Debug.Log("Set speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
                    m_Controller.m_DesiredSpeed = m_CurrentTargetUpdate.Value;
                    if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
                    else removeWaypoint(0);
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.TURNSPEED) // Turn Speed Update
                {
                    //Debug.Log("Set Turn speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
                    m_Controller.m_ScriptControllerTurningSpeed = m_CurrentTargetUpdate.Value;
                    if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
                    else removeWaypoint(0);
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.OVERRIDESPEED) // Turn Speed Update
                {
                    //Debug.Log("Set Override speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
                    m_Speed = m_CurrentTargetUpdate.Value;
                    if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
                    else removeWaypoint(0);
                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.LOCAL)
                {

                }
                else if (m_CurrentTargetUpdate.Type == UpdateType.CMD)
                {
                    Debug.Log("CMD Message: " + m_CurrentTargetUpdate.CMD + " " + m_CurrentTargetUpdate.Value);

                    CMD.ExecuteCommand(m_CurrentTargetUpdate.CMD);

                    if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
                    else removeWaypoint(0);
                }
            }
            else
            {
                if (CheckArrival(m_CurrentTargetXYZPosition))
                {
                    ReachedGPSWaypoint(m_CurrentTargetXYZPosition);
                }
            }

            if (m_DroppingMineLine)
            {
                m_MineLineTimer += Time.deltaTime;

                if (m_MineLineTimer > m_MineInterval)
                {
                    m_MineLineTimer = 0;
                    m_Controller.setState(m_MineState);
                }
            }

            m_PreviousTargetXYZPosition = m_CurrentTargetXYZPosition;
        }

        //Debug.Log(m_CurrentWaypointIndex);

        if(m_Waypoints[m_CurrentWaypointIndex].Type == UpdateType.POSITION)
        {
            if(m_PreviousUpdateType != UpdateType.POSITION)
            {
                Debug.Log(m_Controller.m_EntityName + " - State: " + m_Waypoints[m_CurrentWaypointIndex].Type + " - Would loop here");
                UpdateWaypoints();
            }
            else
            {
                //Debug.Log(m_Controller.m_EntityName + " - State: " + m_Waypoints[m_CurrentWaypointIndex].Type + " - Would not loop here");
            }
        }

        //if (m_Waypoints[m_CurrentWaypointIndex].Type != UpdateType.POSITION)
        //{
        //    Debug.Log(m_Controller.m_EntityName + " - State: " + m_Waypoints[m_CurrentWaypointIndex].Type + " - Would loop here");
        //    //UpdateWaypoints()
        //}
        //else
        //{
        //    Debug.Log(m_Controller.m_EntityName + " - State: " + m_Waypoints[m_CurrentWaypointIndex].Type + " - Would not loop here");
        //}
    }

    void ExecuteNonPositionUpdate()
    {
        if (m_CurrentTargetUpdate.Type == UpdateType.STATE) // State Update
        {
            StateUpdate();
        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.ROTATION) // Rot Update
        {
            PositionRotationUpdate(m_CurrentTargetXYZPosition);
        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.SPEED) // Speed Update
        {
            //Debug.Log("Set speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
            m_Controller.m_DesiredSpeed = m_CurrentTargetUpdate.Value;
            if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
            else removeWaypoint(0);
        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.TURNSPEED) // Turn Speed Update
        {
            //Debug.Log("Set Turn speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
            m_Controller.m_ScriptControllerTurningSpeed = m_CurrentTargetUpdate.Value;
            if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
            else removeWaypoint(0);
        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.OVERRIDESPEED) // Turn Speed Update
        {
            //Debug.Log("Set Override speed for " + m_Controller.m_EntityID + " to " + m_CurrentTargetUpdate.Value);
            m_Speed = m_CurrentTargetUpdate.Value;
            if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
            else removeWaypoint(0);
        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.LOCAL)
        {

        }
        else if (m_CurrentTargetUpdate.Type == UpdateType.CMD)
        {
            Debug.Log("CMD Message: " + m_CurrentTargetUpdate.CMD);

            Debug.Log("CMD Has Value: " + m_CurrentTargetUpdate.Value);
            CMD.ExecuteCommand(m_CurrentTargetUpdate.CMD);



            //if (CMD.HasCommand(m_CurrentTargetUpdate.CMD))
            //{
            //    Debug.Log("CMD Has Command");

            //    if (m_CurrentTargetUpdate.Value == -1)
            //    {
            //        Debug.Log("CMD Has No Value");
            //        CMD.ExecuteCommand(m_CurrentTargetUpdate.CMD);
            //    }
            //    else
            //    {
            //        Debug.Log("CMD Has Value: " + m_CurrentTargetUpdate.Value);
            //        string l_CMD = m_CurrentTargetUpdate.CMD + " " + (int)m_CurrentTargetUpdate.Value;
            //        Debug.Log("CMD Final String: " + l_CMD);
            //        CMD.ExecuteCommand(l_CMD);
            //    }
            //}

            if (m_WaypointModuleMode == WaypointModuleMode.REPEAT) m_CurrentWaypointIndex++;
            else removeWaypoint(0);
        }
    }

    void Circle()
    {
        m_Angle += Time.deltaTime * m_RotationSpeed * m_CurrentSimSpeed;

        if (m_Angle > (2 * Mathf.PI))
        {
            Debug.Log("Ending circle");
            m_Angle -= (2 * Mathf.PI);
            //m_Angle = 0;
            //m_Controller.m_ControlType = EntityControlType.NETWORK;
            //m_Circling = false;
        }
        else
        {
            m_Controller.m_RigidBody.isKinematic = true;
            m_Controller.m_ControlType = EntityControlType.NONE;
            m_CirclingPosition = new Vector3((m_EntityToCircle.transform.position.x + Mathf.Sin(m_Angle) * m_Radius), m_Controller.transform.position.y, ((m_EntityToCircle.transform.position.z + Mathf.Cos(m_Angle) * m_Radius)));

            m_CirclingRotation = Quaternion.LookRotation(m_CirclingPosition - m_Controller.transform.position, m_Controller.transform.up);

            m_Controller.SetRotation(m_CirclingRotation);
            m_Controller.SetPosition(m_CirclingPosition);
        }
    }

    void UpdateVisualization()
    {
        if (SimulatorSettings.getAnimationManager().m_WaypointTracksVisible)
        {
            if (m_Waypoints.Count > 0)
            {
                if (m_LineToNextWaypoint.startWidth != SimulatorSettings.getAnimationManager().m_IndicatorLineWidth * 2)
                {
                    m_LineToNextWaypoint.startWidth = SimulatorSettings.getAnimationManager().m_IndicatorLineWidth * 2;
                    m_LineToNextWaypoint.endWidth = SimulatorSettings.getAnimationManager().m_IndicatorLineWidth * 2;
                }

                if (m_WaypointIndicator.startWidth != SimulatorSettings.getAnimationManager().m_IndicatorLineWidth)
                {
                    m_WaypointIndicator.startWidth = SimulatorSettings.getAnimationManager().m_IndicatorLineWidth;
                    m_WaypointIndicator.endWidth = SimulatorSettings.getAnimationManager().m_IndicatorLineWidth;
                }

                m_LineToNextWaypoint.gameObject.SetActive(true);
                m_WaypointIndicator.gameObject.SetActive(true);

                m_WaypointIndicator.positionCount = m_Waypoints.Count;

                m_LineToNextWaypoint.SetPosition(0, m_WaypointTarget.position);

                m_NextLineFound = false;

                for (int i = 0; i < m_Waypoints.Count; i++)
                {
                    if (m_Waypoints[i].Type != UpdateType.POSITION)
                    {
                        if (m_VisualizationPreviousLocation != Vector3.zero)
                        {
                            m_VisualizationVector = m_VisualizationPreviousLocation;
                        }
                        else
                        {
                            m_VisualizationVector = m_WaypointTarget.position;
                        }

                        m_VisualizationVector.y = 5;
                    }
                    else
                    {
                        m_VisualizationVector = GPSEncoder.DGPSToUCS(m_Waypoints[i].GPS.lat, m_Waypoints[i].GPS.lon);
                        m_VisualizationPreviousLocation = m_VisualizationVector;

                        if (!m_NextLineFound)
                        {
                            m_VisualizationVector = GPSEncoder.DGPSToUCS(m_CurrentTargetUpdate.GPS.lat, m_CurrentTargetUpdate.GPS.lon); //GPSEncoder.DGPSToUCS(m_Waypoints[i].GPS.lat, m_Waypoints[i].GPS.lon);

                            if (m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)
                            {
                                m_VisualizationVector.y = m_Controller.transform.position.y;
                            }
                            else
                            {
                                m_VisualizationVector.y = (float)m_Waypoints[i].GPS.alt;
                            }

                            m_NextLineFound = true;

                            m_LineToNextWaypoint.SetPosition(1, m_VisualizationVector);
                        }
                    }

                    if (m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)
                    {
                        m_VisualizationVector.y = m_Controller.transform.position.y;
                    }
                    else
                    {
                        m_VisualizationVector.y = (float)m_Waypoints[i].GPS.alt;
                    }

                    m_WaypointIndicator.SetPosition(i, m_VisualizationVector);//GPSEncoder.DGPSToUCS(m_Waypoints[i].GPS.lat, m_Waypoints[i].GPS.lon));

                }


            }

        }
        else
        {
            if (m_WaypointIndicator)
            {
                m_WaypointIndicator.gameObject.SetActive(false);
            }
            if (m_LineToNextWaypoint)
            {
                m_LineToNextWaypoint.gameObject.SetActive(false);
            }
        }
    }

    bool CheckArrival(Vector3 a_TargetPosition)
    {
        bool l_Ret = false;

        if (m_PreviousDistanceFromTarget == m_DistanceFromTarget) m_PreviousDistanceFromTarget = 9999999999;
        else m_PreviousDistanceFromTarget = m_DistanceFromTarget;

        if (m_CurrentSimSpeed == 1)
        {
            m_SpeedAdjustedArrivedAtWaypointTolerance = m_ArrivedAtWaypointTolerance;

            if (!m_ReturningToHost)
            {
                //m_SpeedAdjustedArrivedAtWaypointTolerance = 1;
                m_SpeedAdjustedArrivedAtWaypointTolerance = m_ArrivedAtWaypointTolerance;
            }
            else
            {
                m_SpeedAdjustedArrivedAtWaypointTolerance = m_ReturnToHostArrivedAtWaypointTolerance;
            }
        }
        else
        {
            if (!m_ReturningToHost)
            {
                m_SpeedAdjustedArrivedAtWaypointTolerance = m_ArrivedAtWaypointTolerance * (m_CurrentSimSpeed / 2);
            }
            else
            {
                m_SpeedAdjustedArrivedAtWaypointTolerance = m_ReturnToHostArrivedAtWaypointTolerance + (m_CurrentSimSpeed / 2);
            }
        }

        if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
        {
            //Debug.Log(m_Controller.m_EntityName + " is descended from SURFACE");
            m_DistanceFromTarget = Common.GetDistanceIgnoringY(m_WaypointTarget.position, a_TargetPosition);

            if (m_DistanceFromTarget < m_SpeedAdjustedArrivedAtWaypointTolerance)
            {
                //ReachedGPSWaypoint(a_TargetPosition);
                l_Ret = true;
            }
        }
        else if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
        {
            //Debug.Log(m_Controller.m_EntityName + " is descended from AIR");
            m_DistanceFromTarget = Vector3.Distance(m_WaypointTarget.position, a_TargetPosition);

            if(m_Landing)
            {
                m_Controller.m_RigidBody.isKinematic = false;
                m_Controller.m_RigidBody.useGravity = true;

                if (m_DistanceFromTarget < m_LandingWaypointTolerance)
                {
                    //ReachedGPSWaypoint(a_TargetPosition);
                    l_Ret = true;
                }
            }
            else
            {
                m_Controller.m_RigidBody.isKinematic = true;
                m_Controller.m_RigidBody.useGravity = false;

                if (m_DistanceFromTarget < m_SpeedAdjustedArrivedAtWaypointTolerance)
                {
                    //ReachedGPSWaypoint(a_TargetPosition);
                    l_Ret = true;
                }
            }
        }
        else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)
        {
            //Debug.Log(m_Controller.m_EntityName + " is descended from AIR");
            //m_DistanceFromTarget = Common.GetDistanceIgnoringY(m_WaypointTarget.position, a_TargetPosition);
            m_DistanceFromTarget = Vector3.Distance(m_WaypointTarget.position, a_TargetPosition);

            if (m_DistanceFromTarget < m_SpeedAdjustedArrivedAtWaypointTolerance)
            {
                //ReachedGPSWaypoint(a_TargetPosition);
                l_Ret = true;
            }
        }
        else if (m_WaypointBehaviorMode == WaypointBehaviorMode.CHARACTER)
        {
            //Debug.Log(m_Controller.m_EntityName + " is descended from AIR");
            //m_DistanceFromTarget = Common.GetDistanceIgnoringY(m_WaypointTarget.position, a_TargetPosition);
            m_DistanceFromTarget = Common.GetDistanceIgnoringY(m_WaypointTarget.position, a_TargetPosition);

            if (m_DistanceFromTarget < m_SpeedAdjustedArrivedAtWaypointTolerance)
            {
                //ReachedGPSWaypoint(a_TargetPosition);
                l_Ret = true;
            }
        }

        return l_Ret;
    }

    void ReachedGPSWaypoint(Vector3 a_TargetPosition)
    {
        //Debug.Log("EntityName: " + m_Controller.m_EntityName + " arrived at Waypoint: " + m_CurrentTargetUpdate.GPS.lat + " - " + m_CurrentTargetUpdate.GPS.lon + " - " + m_CurrentTargetUpdate.GPS.alt);

        //SimUpdate l_NewUpdate = new SimUpdate();
        //l_NewUpdate.Type = UpdateType.POSITION;
        //l_NewUpdate.GPS = m_CurrentTargetUpdate.GPS;
        //l_NewUpdate.Position = m_Controller.transform.position;
        //l_NewUpdate.Rotation = m_Controller.transform.rotation.eulerAngles;

        //m_Controller.m_CurrentSimUpdate = l_NewUpdate;
        //m_Controller.addPosition(l_NewUpdate);

        //m_WaypointTarget.position = a_TargetPosition;

        //if (m_Controller.m_EntityID == 12) Debug.Log("ReachedGPSWaypoint " + a_TargetPosition + " at: " + Time.timeSinceLevelLoad);

        ReachedGPSWaypoint();
    }

    void ReachedGPSWaypoint(EntityState a_State)
    {
        Debug.Log("EntityName: " + m_Controller.m_EntityName + " arrived at State Waypoint: " + a_State);

        ReachedGPSWaypoint();
    }

    void ReachedGPSWaypoint()
    {
        m_Controller.ArrivedAtLocation(transform.position);

        m_Doppler_3 = false;
        m_Doppler_2 = false;
        m_Doppler_1 = false;
        m_IsMovingFurtherAway = false;

        //m_Controller.SetPreviousUpdate(m_CurrentTargetUpdate);

        if (m_WaypointModuleMode == WaypointModuleMode.SINGLERUN)
        {
            removeWaypoint(m_CurrentWaypointIndex);

            if (m_Waypoints.Count > 0)
            {
                if (m_CurrentWaypointIndex > m_Waypoints.Count)
                {
                    //Debug.Log("Num Waypoints: " + m_Waypoints.Count + " - Current Index: " + m_CurrentWaypointIndex);
                    m_CurrentWaypointIndex = m_Waypoints.Count;
                }
                else if (m_Waypoints[m_CurrentWaypointIndex].Type == UpdateType.STATE)
                {
                    if (m_Waypoints[m_CurrentWaypointIndex].State == EntityState.LAND)
                    {
                        if (m_Landing)
                        {
                            removeWaypoint(m_CurrentWaypointIndex);
                            Landed();
                        }
                    }
                }
            }
        }
        else
        {
            m_CurrentWaypointIndex++;

            if (m_Waypoints.Count > 0)
            {
                if (m_CurrentWaypointIndex == m_Waypoints.Count)
                {
                    m_CurrentWaypointIndex = 0;
                }

                if (m_Waypoints[m_CurrentWaypointIndex].Type == UpdateType.STATE)
                {
                    if (m_Waypoints[m_CurrentWaypointIndex].State == EntityState.LAND)
                    {
                        if (m_Landing)
                        {
                            m_CurrentWaypointIndex++;
                            Landed();
                        }
                    }
                }
            }
        }

        if (m_WaypointIndicator)
        {

            if (m_WaypointIndicator.positionCount > 1)
            {
                //m_WaypointIndicator.SetPosition(1, m_WaypointTarget.position);
            }

            m_WaypointIndicator.gameObject.SetActive(false);
        }

        if (m_Waypoints.Count == 0)
        {
            m_Controller.m_EntityState = EntityState.DEFAULT_POSUPDATE;
            m_Controller.m_ControlType = EntityControlType.NONE;
        }

        m_PreviousDistanceFromTarget = 99999999999;
    }

    public void addWaypoint(SimUpdate a_WaypointUpdate)
    {
        if (!m_Controller.m_EntityInitialized) Debug.Log("Attempted to add waypoint before waymod was initialized");
        m_Waypoints.Add(a_WaypointUpdate);
        m_TotalNumberOfWaypoints++;

        if (a_WaypointUpdate.Type == UpdateType.POSITION)
        {
            m_NumberOfPositionWaypoints++;
            m_DisplayWaypoints.Add(m_Controller.m_EntityID + " " + a_WaypointUpdate.GPS.lat + " " + a_WaypointUpdate.GPS.lon + " " + a_WaypointUpdate.GPS.alt + " " + a_WaypointUpdate.Type);

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding Waypoint - Lat: " + a_WaypointUpdate.GPS.lat + " Lon: " + a_WaypointUpdate.GPS.lon + " Ele: " + a_WaypointUpdate.GPS.alt);
        }
        else if (a_WaypointUpdate.Type == UpdateType.STATE)
        {
            NumberOfStateWaypoints++;
            m_DisplayWaypoints.Add(m_Controller.m_EntityID + " STATE " + a_WaypointUpdate.State);

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding State Waypoint - State: " + a_WaypointUpdate.State);
        }
        else if (a_WaypointUpdate.Type == UpdateType.SPEED)
        {
            NumberOfStateWaypoints++;

            m_DisplayWaypoints.Add(m_Controller.m_EntityID + " SPEED: " + a_WaypointUpdate.Value.ToString());

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding State Waypoint - State: " + a_WaypointUpdate.State);
        }
        else if (a_WaypointUpdate.Type == UpdateType.CMD)
        {
            NumberOfStateWaypoints++;

            m_DisplayWaypoints.Add(m_Controller.m_EntityID + " CMD " + a_WaypointUpdate.CMD);

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding CMD Waypoint - CMD: " + a_WaypointUpdate.CMD);
        }
    }

    public void addWaypoint(SimUpdate a_WaypointUpdate, int a_Position)
    {
        m_Waypoints.Insert(a_Position, a_WaypointUpdate);
        m_TotalNumberOfWaypoints++;

        if (a_WaypointUpdate.Type == UpdateType.POSITION)
        {
            m_NumberOfPositionWaypoints++;
            m_DisplayWaypoints.Insert(a_Position, m_Controller.m_EntityID + " " + a_WaypointUpdate.GPS.lat + " " + a_WaypointUpdate.GPS.lon + " " + a_WaypointUpdate.GPS.alt + " " + a_WaypointUpdate.State);

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding Waypoint - Lat: " + a_WaypointUpdate.GPS.lat + " Lon: " + a_WaypointUpdate.GPS.lon + " Ele: " + a_WaypointUpdate.GPS.alt + " at Index: " + a_Position);
        }
        else if (a_WaypointUpdate.Type == UpdateType.STATE)
        {
            NumberOfStateWaypoints++;
            m_DisplayWaypoints.Insert(a_Position, m_Controller.m_EntityID + " STATE " + a_WaypointUpdate.State);

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding State Waypoint - State: " + a_WaypointUpdate.State + " at Index: " + a_Position);
        }
        else if (a_WaypointUpdate.Type == UpdateType.SPEED)
        {
            NumberOfStateWaypoints++;

            m_DisplayWaypoints.Insert(a_Position, m_Controller.m_EntityID + " SPEED: " + a_WaypointUpdate.Value.ToString());

            //Debug.Log("ID: " + m_Controller.m_EntityID + " Adding Speed Waypoint - State: " + a_WaypointUpdate.State + " at Index: " + a_Position);
        }
    }

    public void removeStateWaypointOfType(int a_IndexToStart, string a_Name)
    {
        SimUpdate l_Update;

        Debug.Log("removeStateWaypointOfType - Index: " + a_IndexToStart + " - Name: " + a_Name);

        if (m_Waypoints.Count > a_IndexToStart)
        {
            for (int i = a_IndexToStart; i < m_Waypoints.Count; i++)
            {
                l_Update = m_Waypoints[i];

                if(l_Update.Type == UpdateType.STATE)
                {
                    if(l_Update.State.ToString().Contains(a_Name))
                    {
                        removeWaypoint(i);
                        return;
                    }
                }
            }
        }
    }

    public void removeWaypoint(int a_Index)
    {
        if (m_Waypoints.Count == 0) return;

        if (m_Waypoints[a_Index].Type == UpdateType.STATE)
        {
            //Debug.Log("removeWaypoint (" + a_Index + "): STATE " + m_Waypoints[a_Index].State);
        }
        else
        {
            //Debug.Log("removeWaypoint (" + a_Index + "): POS " + m_Waypoints[a_Index].GPS.lat + " " + m_Waypoints[a_Index].GPS.lon + " " + m_Waypoints[a_Index].GPS.alt);
        }

        if (m_Waypoints[a_Index].State == EntityState.UNKNOWN) m_NumberOfPositionWaypoints--;
        else NumberOfStateWaypoints--;
        m_TotalNumberOfWaypoints--;

        if (m_Waypoints.Count > a_Index) m_Waypoints.RemoveAt(a_Index);
        if (m_DisplayWaypoints.Count > a_Index) m_DisplayWaypoints.RemoveAt(a_Index);

        if (a_Index == m_CurrentWaypointIndex)
        {
            if (m_CurrentWaypointIndex < m_Waypoints.Count)
            {
                m_CurrentTargetUpdate = m_Waypoints[m_CurrentWaypointIndex];
            }

        }
    }

    public SimUpdate GetWaypoint(int a_Index)
    {
        if (a_Index < m_Waypoints.Count) return m_Waypoints[a_Index];
        else return null;
    }

    public void ClearWaypoints()
    {
        m_Waypoints.Clear();
        m_DisplayWaypoints.Clear();
        m_NumberOfPositionWaypoints = 0;
        m_TotalNumberOfWaypoints = 0;
        m_CurrentWaypointIndex = 0;
    }

    public Vector3 GetRelativePositionToThis(Vector3 a_TargetXYZPosition)
    {
        m_TempRelativeVec3 = transform.InverseTransformPoint(a_TargetXYZPosition);

        return m_TempRelativeVec3;
    }

    public Vector3 GetRelativePositionBetweenPoints(Vector3 a_TargetXYZPosition, Vector3 a_NewXYZPosition)
    {
        transform.position = a_NewXYZPosition;

        m_TempRelativeVec3 = transform.InverseTransformPoint(a_TargetXYZPosition);

        transform.localPosition = Vector3.zero;

        return m_TempRelativeVec3;
    }

    public Vector3 CalculateRotation(Vector3 a_TargetXYZPosition)
    {
        m_TempVec3 = Vector3.zero;

        CalculateRotation_Heading();

        if(m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)
        {
            CalculateRotation_Pitch();
        }

        return m_TempVec3;
    }

    void CalculateRotation_Heading()
    {
        m_PositionHeading = m_CurrentTargetXYZPosition - m_Controller.transform.position;

        if (m_PositionHeading != Vector3.zero)
        {
            m_TargetHeading = Quaternion.LookRotation((m_PositionHeading).normalized).eulerAngles;

            m_DistanceFromTargetHeading = Mathf.Abs(m_TargetHeading.y - m_Controller.transform.rotation.eulerAngles.y);

            if (m_DistanceFromTargetHeading > .01)
            {
                m_TempVec3.x = m_TargetHeading.x;
                m_TempVec3.z = m_TargetHeading.z;

                m_DistanceFromTargetHeading = Mathf.Abs(m_TargetHeading.y - m_Controller.transform.rotation.eulerAngles.y);

                if (m_CurrentSimSpeed > 5)
                {
                    //m_AdjustedSimSpeed = (m_CurrentSimSpeed * m_AdjustedSimSpeedMod);
                    m_RotationSecondaryStepSize = (Time.deltaTime * (m_CurrentSimSpeed * m_Controller.m_ScriptControllerTurningSpeed));
                    m_RotationStepSize = (Time.deltaTime * (m_CurrentSimSpeed * 3 * (m_DistanceFromTargetHeading / (m_OriginalEstTimeToDestination * 0.5f))));

                    m_RotationStepSize = m_RotationSecondaryStepSize;
                    //l_NewUpdate.Rotation.y = m_TargetHeading.y;
                    m_TempVec3.y = Quaternion.RotateTowards(m_WaypointTarget.rotation, Quaternion.Euler(m_TargetHeading), m_RotationStepSize).eulerAngles.y;

                    //if (m_Controller.m_EntityID == 12) Debug.Log("Target Heading: " + m_TargetHeading.y);
                }
                else
                {
                    m_RotationSecondaryStepSize = (Time.deltaTime * (m_CurrentSimSpeed * m_Controller.m_ScriptControllerTurningSpeed));
                    m_RotationStepSize = (Time.deltaTime * (m_CurrentSimSpeed * (m_DistanceFromTargetHeading / (m_OriginalEstTimeToDestination * 0.5f))));

                    m_RotationStepSize = m_RotationSecondaryStepSize;
                    m_TempVec3.y = Quaternion.RotateTowards(m_WaypointTarget.rotation, Quaternion.Euler(m_TargetHeading), m_RotationStepSize).eulerAngles.y;
                }

                //Debug.Log(m_Controller.m_EntityID + "  - m_Controller.m_ScriptControllerTurningSpeed: " + m_Controller.m_ScriptControllerTurningSpeed + " - m_RotationStepSize: " + m_RotationStepSize);

                //if(m_RotationStepSize < m_RotationSecondaryStepSize)
                //{
                //    m_RotationStepSize = m_RotationSecondaryStepSize;
                //}

                //Debug.Log("m_TargetHeading: " + m_TargetHeading + " - m_Controller.transform.rotation.eulerAngles.y: " + m_Controller.transform.rotation.eulerAngles.y + " - Distance from target heading: " + m_DistanceFromTargetHeading + " - Est Time to Dest: " + m_EstTimeToDestination + " - m_PositionHeading: " + m_PositionHeading);


                if (m_DistanceFromTargetHeading < .01)
                {
                    m_TempVec3.x = m_TargetHeading.x;
                    m_TempVec3.y = m_TargetHeading.y;
                    m_TempVec3.z = m_TargetHeading.z;
                }
            }
            else
            {
                m_TempVec3.x = m_TargetHeading.x;
                m_TempVec3.y = m_TargetHeading.y;
                m_TempVec3.z = m_TargetHeading.z;
            }
        }
    }

    void CalculateRotation_Pitch()
    {
        m_PositionHeading = m_CurrentTargetXYZPosition - m_Controller.transform.position;

        if (m_PositionHeading != Vector3.zero)
        {
            m_TargetHeading = Quaternion.LookRotation((m_PositionHeading).normalized).eulerAngles;

            m_DistanceFromTargetHeading = Mathf.Abs(m_TargetHeading.x - m_Controller.transform.rotation.eulerAngles.x);

            if (m_DistanceFromTargetHeading > .01)
            {
                //m_TempVec3.x = m_TargetHeading.x;
                //m_TempVec3.z = m_TargetHeading.z;

                m_DistanceFromTargetHeading = Mathf.Abs(m_TargetHeading.x - m_Controller.transform.rotation.eulerAngles.x);

                if (m_CurrentSimSpeed > 5)
                {
                    //m_AdjustedSimSpeed = (m_CurrentSimSpeed * m_AdjustedSimSpeedMod);
                    m_RotationSecondaryStepSize = (Time.deltaTime * (m_CurrentSimSpeed * m_Controller.m_ScriptControllerTurningSpeed));
                    m_RotationStepSize = (Time.deltaTime * (m_CurrentSimSpeed * 3 * (m_DistanceFromTargetHeading / (m_OriginalEstTimeToDestination * 0.5f))));

                    m_RotationStepSize = m_RotationSecondaryStepSize;
                    //l_NewUpdate.Rotation.x = m_TargetHeading.x;
                    m_TempVec3.x = Quaternion.RotateTowards(m_WaypointTarget.rotation, Quaternion.Euler(m_TargetHeading), m_RotationStepSize).eulerAngles.x;

                    //if (m_Controller.m_EntityID == 12) Debug.Log("Target Heading: " + m_TargetHeading.x);
                }
                else
                {
                    m_RotationSecondaryStepSize = (Time.deltaTime * (m_CurrentSimSpeed * m_Controller.m_ScriptControllerTurningSpeed));
                    m_RotationStepSize = (Time.deltaTime * (m_CurrentSimSpeed * (m_DistanceFromTargetHeading / (m_OriginalEstTimeToDestination * 0.5f))));

                    m_RotationStepSize = m_RotationSecondaryStepSize;
                    m_TempVec3.x = Quaternion.RotateTowards(m_WaypointTarget.rotation, Quaternion.Euler(m_TargetHeading), m_RotationStepSize).eulerAngles.x;
                }

                //Debug.Log(m_Controller.m_EntityID + "  - m_Controller.m_ScriptControllerTurningSpeed: " + m_Controller.m_ScriptControllerTurningSpeed + " - m_RotationStepSize: " + m_RotationStepSize);

                //if(m_RotationStepSize < m_RotationSecondaryStepSize)
                //{
                //    m_RotationStepSize = m_RotationSecondaryStepSize;
                //}

                //Debug.Log("m_TargetHeading: " + m_TargetHeading + " - m_Controller.transform.rotation.eulerAngles.x: " + m_Controller.transform.rotation.eulerAngles.x + " - Distance from target heading: " + m_DistanceFromTargetHeading + " - Est Time to Dest: " + m_EstTimeToDestination + " - m_PositionHeading: " + m_PositionHeading);


                //if (m_DistanceFromTargetHeading < .01)
                //{
                //    m_TempVec3.x = m_TargetHeading.x;
                //    m_TempVec3.y = m_TargetHeading.y;
                //    m_TempVec3.z = m_TargetHeading.z;
                //}
            }
            else
            {
                //m_TempVec3.x = m_TargetHeading.x;
                //m_TempVec3.y = m_TargetHeading.y;
                //m_TempVec3.z = m_TargetHeading.z;
            }
        }
    }

    public Vector3 CalculatePosition(Vector3 a_TargetXYZPosition)
    {
        m_TempVec3 = Vector3.zero;

        if (m_Controller.QueryPreviousUpdateType(UpdateType.POSITION))
        {
            //Debug.Log("Update Prev Pos - Current: " + m_CurrentTargetXYZPosition + " - Previous: " + m_Controller.m_PreviousSimUpdate.Position + " - Previous GPS: " + m_Controller.m_PreviousSimUpdate.GPS.lat + " " + m_Controller.m_PreviousSimUpdate.GPS.lon);
            //if (m_CurrentTargetXYZPosition != m_PreviousTargetXYZPosition)
            //{
            //    Debug.Log("Setting Step Sizes - Distance from Target: " + m_DistanceFromTarget + " - Est Time to Dest: " + m_EstTimeToDestination);
            //    m_OriginalDistance = m_DistanceFromTarget;
            //    m_OriginalEstToDest = m_EstTimeToDestination;
            //}

            //m_PositionSecondaryStepSize = (Time.deltaTime * (m_CurrentSimSpeed * m_Controller.m_ScriptControllerTurningSpeed));
            //m_PositionStepSize = Time.deltaTime * (m_Controller.m_MaxSpeed * m_CurrentSimSpeed); //(Time.deltaTime * m_CurrentSimSpeed * (m_OriginalDistance / m_OriginalEstToDest));
            //m_PositionStepSize = m_OriginalDistance / m_DistanceFromTarget;
            //if (m_PositionStepSize < m_PositionSecondaryStepSize) m_PositionStepSize = m_PositionSecondaryStepSize;

            //if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
            //{
            //    Debug.Log("Step Size (" + m_PositionStepSize + ") = Original Distance (" + m_OriginalDistance + ") / Current Distance(" + m_DistanceFromTarget + ")");
            //    l_NewUpdate.Position = Vector3.MoveTowards(m_Controller.transform.position, a_TargetXYZPosition, Time.deltaTime * (m_Controller.m_MaxSpeed * Common.knotsToMeters * m_CurrentSimSpeed));
            //}
            //else
            //{
            //    l_NewUpdate.Position = m_WaypointTarget.position + (m_WaypointTarget.forward * Time.deltaTime * m_Speed * m_CurrentSimSpeed);

            //}

            m_PositionStepSize = Time.deltaTime * (m_Speed * m_CurrentSimSpeed);

            if (m_WaypointBehaviorMode == WaypointBehaviorMode.AIR)
            {
                //Debug.Log("AIR UPDATE - POS " + m_Controller.m_Transform.position + " TARGETXYZ " + m_CurrentTargetXYZPosition + " - STEPSIZE: " + m_PositionStepSize);
                //l_NewUpdate.Position = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, m_CurrentTargetXYZPosition, m_PositionStepSize, 0);

                //m_DistanceToPointPreLerp = Common.GetDistanceIgnoringY(m_Controller.transform.position, m_WaypointTarget.position);

                //m_DistanceToPointPostLerp = Common.GetDistanceIgnoringY(l_NewUpdate.Position, m_WaypointTarget.position);

                //m_DistanceToPointPostLerp = Common.GetDistanceIgnoringY(l_NewUpdate.Position, m_WaypointTarget.position);

                //Debug.Log(" Local Target: " + m_Controller.transform.InverseTransformPoint(a_TargetXYZPosition) + " - World Target: " + m_Controller.transform.InverseTransformPoint(a_TargetXYZPosition));

                m_DistanceToPointPreLerp = GetRelativePositionToThis(a_TargetXYZPosition).magnitude;

                m_TempVec3 = m_Controller.transform.position + (m_Controller.transform.forward * m_PositionStepSize);
                m_TempVec3.y = Mathf.Lerp(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_LandingSpeed * m_CurrentSimSpeed));

                //Debug.DrawLine(m_Controller.transform.position, m_TempVec3, Color.red, 30);
                //Debug.DrawRay(m_Controller.transform.position, m_Controller.transform.forward * 15, Color.blue, 30);

                m_DistanceToPointPostLerp = GetRelativePositionBetweenPoints(a_TargetXYZPosition, m_TempVec3).magnitude;

                /*
                if (m_DistanceFromTarget < (m_CurrentSimSpeed * 5) && m_CurrentTargetUpdate.Type == UpdateType.POSITION)
                {
                    if (m_DistanceToPointPreLerp < m_DistanceToPointPostLerp)
                    {
                        if (m_Controller.m_EntityID == 12)
                        {
                            Debug.Log("Overshot correction - Pre: " + m_DistanceToPointPreLerp + " - Post: " + m_DistanceToPointPostLerp);
                        }
                        m_TempVec3.x = a_TargetXYZPosition.x;
                        m_TempVec3.z = a_TargetXYZPosition.z;

                        //Debug.DrawRay(m_Controller.m_Transform.position, m_Controller.m_Transform.up * 15, Color.red, 30);
                        //Debug.DrawRay(m_TempVec3, m_Controller.m_Transform.up * 15, Color.green, 30);
                        //return;

                        m_Controller.SetPosition(a_TargetXYZPosition);
                    }
                }
                */

                if (m_Controller.m_IsFalling) m_Controller.m_IsFalling = false;
            }
            else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SURFACE)
            {
                //Debug.Log("AIR UPDATE - POS " + m_Controller.m_Transform.position + " TARGETXYZ " + m_CurrentTargetXYZPosition + " - STEPSIZE: " + m_PositionStepSize);
                //m_TempVec3 = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, m_CurrentTargetXYZPosition, m_PositionStepSize, 0);
                m_TempVec3 = m_Controller.transform.position + (m_Controller.transform.forward * Time.deltaTime * m_Speed * m_CurrentSimSpeed);
                m_TempVec3.y = Mathf.Lerp(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_LandingSpeed * m_CurrentSimSpeed));
            }
            else if (m_WaypointBehaviorMode == WaypointBehaviorMode.SUB)
            {
                //Debug.Log("AIR UPDATE - POS " + m_Controller.m_Transform.position + " TARGETXYZ " + m_CurrentTargetXYZPosition + " - STEPSIZE: " + m_PositionStepSize);
                //m_TempVec3 = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, m_CurrentTargetXYZPosition, m_PositionStepSize, 0);
                m_TempVec3 = m_Controller.transform.position + (m_Controller.transform.forward * Time.deltaTime * m_Speed * m_CurrentSimSpeed);
                m_TempVec3.y = Mathf.Lerp(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_LandingSpeed * m_CurrentSimSpeed));
            }
            else
            {
                m_TempVec3 = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, m_CurrentTargetXYZPosition, Time.deltaTime * (m_Speed * m_CurrentSimSpeed), 0);
                m_TempVec3.y = Mathf.Lerp(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_LandingSpeed * m_CurrentSimSpeed));
            }

            //m_TempVec3.y = Mathf.Lerp(m_Controller.transform.position.y, a_TargetXYZPosition.y, 1 - m_PositionStepSize);
            //m_TempVec3.y = Mathf.MoveTowards(m_Controller.m_PreviousSimUpdate.Position.y, a_TargetXYZPosition.y, m_PositionStepSize); //Time.deltaTime * (m_Speed * m_CurrentSimSpeed));

            //l_NewUpdate.GPS = GPSEncoder.DUSCToGPS(m_TempVec3.x, m_TempVec3.y, m_TempVec3.z);
        }
        else
        {
            //Debug.Log("Update Prev State: " + m_CurrentTargetXYZPosition);

            m_TempVec3 = Common.MoveTowardsIgnoringY(m_Controller.m_Transform.position, m_CurrentTargetXYZPosition, Time.deltaTime * (m_Speed * m_CurrentSimSpeed), 0);
            m_TempVec3.y = Mathf.Lerp(m_Controller.m_Transform.position.y, m_CurrentTargetXYZPosition.y, Time.deltaTime * (m_LandingSpeed * m_CurrentSimSpeed));
            //l_NewUpdate.GPS = GPSEncoder.DUSCToGPS(l_NewUpdate.Position.x, l_NewUpdate.Position.y, l_NewUpdate.Position.z);
        }

        return m_TempVec3;
    }

    PrecisionGPS CalculateGPS(Vector3 a_XYZPosition)
    {
        m_TempGPS = GPSEncoder.DUSCToGPS(a_XYZPosition.x, a_XYZPosition.y, a_XYZPosition.z);

        return m_TempGPS;
    }
}
